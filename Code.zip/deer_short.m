function [ HOLD ] = deer_short(t, HOLD, PARAM )
% set up distances and dipolar frequencies
    HOLD.r =  PARAM.delta_R:PARAM.delta_R:PARAM.R_max;
    w = 326.977e+09./(HOLD.r.^3);
    w = transpose(w);
% determine matrix of Fresnel integrals
% this matrix is independent of the probability distribution
    a = 3*bsxfun(@times,w,abs(t));
    q = sqrt(2*a/pi);
    [cs,ss] = FCS_CS2(q);
    cs = cs./q;
    ss = ss./q;
    ineq0 = find(q == 0.0);
    cs(ineq0) = 0;
    ss(ineq0) = 0;
    HOLD.kernel = cs.*cos(w*abs(t)) + ss.*sin(w*abs(t));
return
