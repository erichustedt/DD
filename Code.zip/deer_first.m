function [ DATA, PARAM, HOLD, PARAM0 ]= deer_first( DATA, PARAM )
    PARAM0 = PARAM;
    TIME = DATA.deer_t0 - 1.e-09*PARAM.time_shift;
    HOLD.TIME0 = TIME;
    HOLD = deer_back(TIME,HOLD,PARAM);
    HOLD = deer_short(TIME,HOLD,PARAM);
    HOLD = deer_prob(HOLD,PARAM);
    rexp = 10^PARAM.lambda;
    y = (1. - PARAM.depth*(1.-HOLD.v)).* ...
        HOLD.bv.*exp(-abs((rexp*TIME)).^(PARAM.dimension/3.));
    it0 = find(TIME == 0);
    y(it0) = 1.;
    DATA.yfit = PARAM.scale*y;
return;
