function killExcel
%% Check to see if there is an existing EXCEL process
%   warning off;
[~,b] = system('tasklist');
warning on;
%% If there are existing Excel processes kill them all
if verLessThan('matlab','9.1')    
    try
        system('taskkill /F /IM EXCEL.EXE');
    catch
    end
else
    % contains was introduced in R2016B
    if contains(b,'EXCEL.EXE')
        b = Close_Excel_GUI();
        if strcmp(b,'Yes')
            try
                system('taskkill /F /IM EXCEL.EXE');
            catch
            end 
        end
    end
end
%%
return 