% 11/08/2012
% for DD
% EJH
% 01/12/2018 removed kexp
function [PARAM, DISTRIBUTION] = copy_param(PARAM, ANS, nparam, namelengths)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
kr = 0;
ks = 0;
kb = 0;
kl = 0;
ka = 0;
for k = 1:nparam  
  
  if strncmpi(ANS.names(k),'r0_',3)
    kr = kr + 1; 
    PARAM.r0(kr) = ANS.values(k);
    DISTRIBUTION.(char(ANS.names(k)))= ...
      [k kr 1 ANS.fixed(k) ANS.experiment(k) ANS.links(k)];
    
  elseif strncmpi(ANS.names(k),'width',5)
    ks = ks + 1; PARAM.width(ks)= ANS.values(k);
    DISTRIBUTION.(char(ANS.names(k)))= ...
      [k ks 2 ANS.fixed(k) ANS.experiment(k) ANS.links(k)];
  
  elseif strncmpi(ANS.names(k),'beta',4)
    kb = kb + 1; PARAM.beta(kb) = ANS.values(k);
    DISTRIBUTION.(char(ANS.names(k)))= ...
      [k kb 3 ANS.fixed(k) ANS.experiment(k) ANS.links(k)];
          
  elseif strncmpi(ANS.names(k),'zeta',4)
    kl = kl + 1; PARAM.zeta(kl) = ANS.values(k);
    DISTRIBUTION.(char(ANS.names(k)))= ...
      [k kl 4 ANS.fixed(k) ANS.experiment(k) ANS.links(k)];
        
  elseif strncmpi(ANS.names(k),'amp_',4)
    ka = ka + 1; PARAM.amp(ka) = ANS.values(k);
    DISTRIBUTION.(char(ANS.names(k)))= ...
      [k ka 5 ANS.fixed(k) ANS.experiment(k) ANS.links(k)];
  
  else PARAM.(char(ANS.names(k))) =  ANS.values(k);
    
  end
end
end

