% --- February 15th 2018
function [ handles, exitflag, endreason ] =  ...
  FITroutines_DD( chisquaredhandle, functionhandle, handles )
%% Initialize
figure(handles.figureA);  % bring figure to top
handles.chisquared = 0;
extra = struct('HOLD',handles.HOLD,'PARAM0',handles.PARAM0);
% delete line that corresponds to background
handles.axes3.Children(4).delete;
%% Generate inital fit to the data based on starting parameters
%  initial parameters for Marquardt-Levenberg algorithm;
%  calculate derivates
handles = functionhandle(handles.FLOAT.float, extra);
handles = determine_chi2(handles);
%
nfloat = handles.FLOAT.nfloat;
% check to see if certain NLLSq routines are being used
temp = handles.OPTIONS.IP.logical.interiorpoint ...
      | handles.OPTIONS.GS.logical.globalsearch ...
      | handles.OPTIONS.PS.logical.particleswarm;
if handles.OPTIONS.LM.logical.LM
  [handles,exitflag,endreason] = MLroutine_DD(functionhandle,handles);
elseif temp
  floatvalues = handles.FLOAT.float;
  floatnames = handles.FLOAT.floatnames;
  % Copy lower and upper limits
  ll = zeros(1,nfloat);
  ul = zeros(1,nfloat);
  for j = 1:nfloat
    ll(j) = handles.ANS.lowerlimit( handles.FLOAT.floatparindex(1,j) );
    ul(j) = handles.ANS.upperlimit( handles.FLOAT.floatparindex(1,j) );
  end 
  fmc_options = optimoptions('fmincon','Display','none');

  % in Matlab 2015b and earlier verisions these options have different
  % names, MaxIter MaxFunEvals TolX TolFun. - 4/26/2018 EJH
  if verLessThan('matlab','9.0')
      fmc_options.MaxIter = handles.OPTIONS.IP.numeric.MaxIterations;
      fmc_options.MaxFunEvals = ...
          handles.OPTIONS.IP.numeric.MaxFunctionEvaluations;
      % TolX terminates if change in parameter values is small
      fmc_options.TolX = handles.OPTIONS.IP.numeric.StepTolerance;
      fmc_options.TolFun = 0.;
  else
      fmc_options.MaxIterations = handles.OPTIONS.IP.numeric.MaxIterations;
      fmc_options.MaxFunctionEvaluations = ...
          handles.OPTIONS.IP.numeric.MaxFunctionEvaluations;
      % StepTolerance terminates if change in parameter values is small
      fmc_options.StepTolerance = handles.OPTIONS.IP.numeric.StepTolerance;
      fmc_options.ObjectiveLimit = 0.;
  end
  if(handles.OPTIONS.OUTPUT.logical.plotintermediate)
    fmc_options = optimoptions(fmc_options,'OutputFcn', ...
      @(x,optimValues,state)FMC_Plot_Iterates(x,optimValues,state, ...
      handles,functionhandle));
  end
  if handles.OPTIONS.IP.logical.interiorpoint
    % This is section for interiorpoint routine
    A = [];
    Aeq = [];
    b = [];
    beq = [];
    nonlcon = [];
    [floatvalues,~,exitflag,output] = fmincon(chisquaredhandle, ...
      floatvalues,A,b,Aeq,beq,ll,ul, ...
      nonlcon,fmc_options);
%     disp(exitflag);
    [ TESTV, chisqtest, ~, handles.PARAM0, handles.HOLD] ...
      = compare_DD( functionhandle, floatvalues, handles);
    [handles] = update_ML_DD(handles,chisqtest,TESTV,floatvalues);
    endreason = 'Interior Point Algorithm Finished';
    handles.iter = output.iterations; 
  elseif handles.OPTIONS.GS.logical.globalsearch
    % This is section for Global Search routine 
    % problem  is a problem structure contains the local options used  
    % by the Interior-Point algorithm within Global Search
    problem = createOptimProblem('fmincon', ...
      'objective',chisquaredhandle,'x0',(ll + ul)/2,'lb',ll,'ub',ul);
    problem.options.MaxFunctionEvaluations = ...
      handles.OPTIONS.GS.numeric.MaxFunctionEvaluations;
    problem.options.MaxIterations = ...
      handles.OPTIONS.GS.numeric.MaxIterations;
    %   StepTolerance terminates if change in parameter values is small
    problem.options.StepTolerance = ...
      handles.OPTIONS.GS.numeric.StepTolerance;
    problem.options.ObjectiveLimit = 0.; 
    % valuesearch is a solver object containing the options used by the 
    % Global Search algorithm
    valuesearch = GlobalSearch;
    valuesearch.Display = 'iter';
    valuesearch.StartPointsToRun = 'bounds';
    valuesearch.FunctionTolerance = 1.e-04;
    valuesearch.XTolerance = 1.e-03;
    valuesearch.NumTrialPoints = handles.OPTIONS.GS.numeric.NumTrialPoints;
    % larger NumStageOnePoints -- faster run -- should be less than
    % NumTrialPoints
    valuesearch.NumStageOnePoints = ...
        handles.OPTIONS.GS.numeric.NumStageOnePoints;
    valuesearch.MaxTime = handles.OPTIONS.GS.numeric.MaxTime;
    if(handles.OPTIONS.OUTPUT.logical.plotintermediate)
      valuesearch.PlotFcn = @gsplotbestf;
    end
    [floatvalues,~,exitflag,output] = run(valuesearch,problem);
    [ TESTV, chisqtest, ~, handles.PARAM0, handles.HOLD] ...
      = compare_DD( functionhandle, floatvalues, handles);
    [handles] = update_ML_DD(handles,chisqtest,TESTV,floatvalues);
    endreason = 'Global Search Finished';
    handles.iter = output.funcCount;
  elseif handles.OPTIONS.PS.logical.particleswarm
    % This is section for Particle Swarm routine   
    options = optimoptions('particleswarm','HybridFcn', ...
      {@fmincon,fmc_options});
    options = optimoptions(options,'Display','iter');
    options = optimoptions(options,'SocialAdjustmentWeight', ...
      handles.OPTIONS.PS.numeric.SocialAdjustmentWeight);
    options = optimoptions(options,'SelfAdjustmentWeight', ...
      handles.OPTIONS.PS.numeric.SelfAdjustmentWeight);
    nswarm = nfloat*handles.OPTIONS.PS.numeric.SwarmSizeFactor;
    options = optimoptions(options,'SwarmSize',nswarm);
    options = optimoptions(options,'FunctionTolerance', ...
      handles.OPTIONS.PS.numeric.FunctionTolerance);
    options = optimoptions(options,'MinNeighborsFraction', ...
      handles.OPTIONS.PS.numeric.MinNeighborsFraction);
    options = optimoptions(options,'ObjectiveLimit',0.);
    if handles.OPTIONS.PS.logical.SetInitialSwarmMatrix
      iswarm = zeros(nswarm,nfloat);
      iswarm(1,:) = floatvalues;
      for k = 1:nswarm
        for l = 1:nfloat
          if strcmp(floatnames(l),'depth')
            iswarm(k,l) = floatvalues(l) + 0.05*randn;
          elseif strcmp(floatnames(l),'lambda')
            iswarm(k,l) = floatvalues(l) + 0.2*randn;
          elseif strcmp(floatnames(l),'scale')
            iswarm(k,l) = floatvalues(l) + 0.02*randn;
          elseif strcmp(floatnames(l),'concentration')
            iswarm(k,l) = floatvalues(l) + 100.*randn;
          elseif strcmp(floatnames(l),'rho')
            iswarm(k,l) = 15 + rand*(ul(l)-15);
          elseif strncmp(floatnames(l),'r0',2)
            iswarm(k,l) = floatvalues(l) + 5*randn;
          else
            iswarm(k,l) = ll(l) + (ul(l)-ll(l))*rand;
          end
          if iswarm(k,l) < ll(l) || iswarm(k,l) > ul(l)
            iswarm(k,l) = floatvalues(l);
          end
        end
      end
      options = optimoptions(options,'InitialSwarmMatrix',iswarm);
    end
    options = optimoptions(options,'HybridFcn',@fmincon);
    if(handles.OPTIONS.OUTPUT.logical.plotintermediate)
      options = optimoptions(options,'PlotFcn',@pswplotbestf);
    end
    [floatvalues,~,exitflag,output] = particleswarm(chisquaredhandle, ...
      nfloat,ll,ul,options);
    [ TESTV, chisqtest, ~, handles.PARAM0, handles.HOLD] ...
      = compare_DD( functionhandle, floatvalues, handles);
    [handles] = update_ML_DD(handles,chisqtest,TESTV,floatvalues);
    endreason = 'Particle Swarm Finished';
    handles.iter = output.iterations;
  end 
% This is section for Simplex routine
elseif handles.OPTIONS.SP.logical.fminsearch
  floatvalues = handles.FLOAT.float;
  options = optimset('TolFun',handles.OPTIONS.SP.numeric.TolFun, ...
    'TolX',handles.OPTIONS.SP.numeric.TolX, ...
    'MaxFunEvals',handles.OPTIONS.SP.numeric.MaxFunEvals);
  [floatvalues,~,exitflag,output] = fminsearch(chisquaredhandle, ...
    floatvalues,options);
  [ TESTV, chisqtest, ~, handles.PARAM0, handles.HOLD] ...
    = compare_DD( functionhandle, floatvalues, handles);
  [handles] = update_ML_DD(handles,chisqtest,TESTV,floatvalues);
  endreason = 'Simplex Finished';
  handles.iter = output.iterations;
else
  endreason = 'No Fitting Routine Chosen';
end
%
for j = 1:nfloat
  handles.ANS.values(handles.FLOAT.floatparindex(1,j)) = ...
    handles.FLOAT.float(j);
end
%
for n = 1:handles.FLOAT.nlinked
  handles.ANS.values(handles.FLOAT.linkedindex(n)) = ...
    handles.ANS.values(handles.FLOAT.linkedtoindex(1,n));
end
%
clear residuals gradient curvature;
return
end

function stop = FMC_Plot_Iterates(x,optimValues,state,handles, ...
  functionhandle)
extra = struct('HOLD',handles.HOLD,'PARAM0',handles.PARAM0);
TEMP_h =  functionhandle(x,extra);
handles.axes3.Children(4).YData = TEMP_h.DATA.yfit;
% axis(handles.axes3,[handles.DATA.deer_t0(1)*2 ...
%   handles.DATA.deer_t0(handles.DATA.nfit)*1.05 ...
%   0.95*handles.DATA.deer_r(handles.DATA.nfit) ...
%   1.05]); 
q = strcat('$\chi_{\nu}^2 = ', ...
  num2str(optimValues.fval), ...
  '\;\;iter.= ',num2str(optimValues.iteration),'$');
handles.axes3.Children(3).String = q; 
handles.hax.Children.YData = TEMP_h.HOLD.p; 
pause(0.00001);
stop = false;
end