% 11/09/2012
% EJH
% 01/05/2015 modified by EJH
% TEMP_h is a temporary copy of handles that is returned by
% "functionhandle" - i.e. "deercalc". The info in TEMP_h that is needed
% should be copied to handles.
function [ TESTV, chisqtest, difference, PARAM0, HOLD] = ...
  compare_DD( functionhandle, test, handles)
%
extra = struct('HOLD',handles.HOLD,'PARAM0',handles.PARAM0);
TEMP_h =  functionhandle(test,extra);
extra.PARAM0 = TEMP_h.PARAM0;
extra.HOLD = TEMP_h.HOLD;
%
TEMP_h = determine_chi2(TEMP_h);
TESTV.yfit = TEMP_h.DATA.yfit;
TESTV.chisquared = TEMP_h.DATA.chisquared;
TESTV.HOLD = TEMP_h.HOLD;
chisqtest = TEMP_h.DATA.totalchisquared;
difference = chisqtest - handles.DATA.totalchisquared ;
clear TEMP_h;
PARAM0 = extra.PARAM0;
HOLD = extra.HOLD;
clear extra;
return;
