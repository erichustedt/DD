function [deer_r,deer_i,rnoise,par,xfit,yfit,ytemp]= zero_deer(x,y,z,rnoise)
% xtest = abs(x(1));
% xfit = x(x<=xtest);
% nfit = size(xfit,2);
% yfit = y(1:nfit);
[~,imax] = max(y);
nfit = 2*imax;
if x(nfit) < 100.e-09
 xfit = x(x<100e-09);
 nfit = length(xfit);
end
xfit = x(1:nfit);
yfit = y(1:nfit);
disp('IN ZERO_DEER');
% save('gaussian.dat','xfit', 'yfit', '-ASCII')
aa = max(yfit);
fprintf('  %s %f \n', 'initial scale factor= ', aa);
xfit = xfit*1.e09;
yfit = yfit/aa;
par0(1) = 1/2;
par0(2) = xfit(imax);
par0(3) = 100;
par0(4) = 1/2;
%
options = optimset('Display','off','TolFun',1e-8,'Tolx',1e-8);
[par,~,exitflag,output] = fminsearch(@(par)differfun1(par,xfit,yfit),par0,options);
%
ytemp = par(1)*exp( (-1*(xfit - par(2)).^2)/(2*par(3)*par(3))) + par(4) ;
fprintf(' \n %s %i ', ' exitflag for fitting Gaussian to early time data= ', exitflag);
fprintf(' \n %s \n ', ' ');
disp(output);
fprintf(' %s ', 'Gaussian parameters for zero time fitting= ');
disp(par);
bb = par(1) + par(4);
% disp({aa bb});
deer_r = y/aa/bb;
deer_i = z/aa/bb;
rnoise = rnoise/aa/bb;
return
%
function F = differfun1(par,xfit,yfit)
    G  = gaussianfun(par,xfit);
    F= sum((yfit - G).^2);
return;
%
function G = gaussianfun(par,xfit)
   G = par(1)*exp( (-1*(xfit - par(2)).^2)/(2*par(3)*par(3))) + par(4) ;
return;




