function [ handles ] = set_exponential( handles )
% 08/12/2015 - EJH
% Function to activate use of Exponential background
% lambda
de = handles.ANS.values(5);
co = handles.ANS.values(9);
la = log10(co*de/1.0e-03);
if co > 0
    handles.ANS.values(6) = la;
    set(handles.lambda_edit,'String',num2str(handles.ANS.values(6)));
end 
handles.ANS.fixed(6) = 0;
set(handles.lambda_checkbox,'Value',~handles.ANS.fixed(6));
%
handles.ANS.values(7) = 3;
set(handles.d_edit,'String',num2str(handles.ANS.values(7)));
handles.ANS.fixed(7) = 1;
set(handles.d_checkbox,'Value',~handles.ANS.fixed(7));
%
handles.ANS.values(8) = 0;
set(handles.b_depth_edit,'String',num2str(handles.ANS.values(8)));
handles.ANS.fixed(8) = 1;
set(handles.b_depth_checkbox,'Value',~handles.ANS.fixed(8));
handles.ANS.links(8) = 5;
set(handles.link_depth_checkbox,'Value',1);
%
handles.ANS.values(9) = 0;
set(handles.concentration_edit,'String',num2str(handles.ANS.values(9)));
handles.ANS.fixed(9) = 1;
set(handles.concentration_checkbox,'Value',~handles.ANS.fixed(9));
%
handles.ANS.values(10) = 0;
set(handles.rho_edit,'String',num2str(handles.ANS.values(10)));
handles.ANS.fixed(10) = 1;
set(handles.rho_checkbox,'Value',~handles.ANS.fixed(10));
end

