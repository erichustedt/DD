function [handles] = save_statistics_function(handles)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
shape = ' ';
if handles.PARAM.shape == 1
  shape = 'Gaussian'; end
if handles.PARAM.shape == 5
  shape = 'Rice'; end
if handles.PARAM.shape == 8
  shape = 'GND'; end
if handles.PARAM.shape == 9
  shape = 'Skewed'; end
if handles.PARAM.shape == 10
  shape = 'GSND'; end
%
back = ' ';
if get(handles.exponential_checkbox,'Value')
  back = 'exponential'; end
if get(handles.calculated_checkbox,'Value')
  back = 'calculated'; end
%
chis = sum(handles.DATA.residuals.*handles.DATA.residuals)/ ...
    (handles.DATA.rnoise^2);
%
save_data = {handles.DATA.name handles.DATA.rnoise handles.PARAM.ng ...
    shape back handles.DATA.ssr handles.DATA.nfit handles.FLOAT.nfloat ...
    handles.ndegreefreedom handles.DATA.totalchisquared ...
    handles.mode_number handles.DATA.AICc handles.DATA.BIC};
%
try
    handles.save_statistics = vertcat(handles.save_statistics,save_data);
catch
    disp(size(handles.save_statistics));
    disp(size(save_data));
    disp(save_data);
end
clear save_data;
end

