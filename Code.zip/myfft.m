function [w,f]= myfft(t,s)
    npts = 1024;
    temp = linspace(0,16*max(t),npts);
    y = interp1(t,s,temp,'spline',0.);
    dt = temp(2) - temp(1);
    dw = 1/(npts*dt);
    wi = -1*npts*dw/2;
    wf = abs(wi) - dw;
    w = wi:dw:wf;
    f = fftshift(fft(y));
    p = npts/4;
    f = real(f);
    q = sum(f(1:p))/p;
    f = f - q;
%     r = trapz(f);
%     f = f/r;
return;