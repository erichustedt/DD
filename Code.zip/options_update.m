function options_update(~,~,dynamicObject,dynamic_handles,dynamic_temp)
% 06/02/2015 This function copies the OPTIONS field of one structure to
% another
dynamic_handles.OPTIONS = dynamic_temp.OPTIONS;
% Update handles structure - THIS IS NECESSARY
guidata(dynamicObject,dynamic_handles);
