function [] = minimize_Desktop()
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
Desktop = com.mathworks.mde.desk.MLDesktop.getInstance();
JavaFrame = Desktop.getMainFrame();
JavaFrame.setMinimized(true);
end

