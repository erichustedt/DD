function [ handles ] = plot_raw_data( handles )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
%% Delete previous figures
try delete(handles.figureA);handles=rmfield(handles,'figureA');catch;end
try ...
  delete(handles.figureCBa);handles=rmfield(handles,'figureCBa');catch;end
try ...
  delete(handles.figureCBb);handles=rmfield(handles,'figureCBb');catch;end
try ...
  delete(handles.figureCBc);handles=rmfield(handles,'figureCBc');catch;end
try
  for ic = 1:handles.CI.nconf
    try delete(handles.figure2(ic));catch;end
  end
  handles = rmfield(handles,'figure2');
end
%%
set(handles.message_text,'String','DATA Spectrum Read', ...
  'BackgroundColor',[1.000 0.969 0.922]);
[ handles ] = DD_figure(handles);
set(handles.phase_text,'String',num2str(0));
set(handles.time_shift_text,'String',num2str(0));
handles.axes2 = axes( 'Parent', handles.figureA, 'Position', ...
  [0.075 0.40 0.175 0.50]);
%   Create multiple lines using matrix input to plot
xplot = 1.e6*handles.DATA.deer_t;
plot2 = plot(xplot,real(handles.DATA.z1),xplot,...
  imag(handles.DATA.z1),'Parent',handles.axes2,'MarkerSize',3, ...
  'Marker','.','LineStyle','none');
set(plot2(1),'Color',[0 0 0]);
set(plot2(2),'Color',[0.5 0 0]);
xlo = 1.5*xplot(1);
xhi = 1.05*xplot(handles.DATA.npts);
ymax = 1.05*max(real(handles.DATA.z1));
ymin = min(imag(handles.DATA.z1));
if ymin < 0
  ymin = 1.5*ymin;
else
  ymin = 0.5*ymin;
end
axis(handles.axes2,[xlo xhi  ymin ymax]);
xlabel({'Time (\mus)'},'Parent',handles.axes2);
handles.status = 0;
end

