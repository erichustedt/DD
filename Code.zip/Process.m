function handles = Process(handles)
set(handles.phase_text,'String',num2str(0));
set(handles.time_shift_text,'String',num2str(0));
set(handles.fit_chisquared_text,'String',num2str(0.0));
set(handles.static_text_22,'String',num2str(0.0));
%
ts = ceil(handles.OPTIONS.MISC.numeric.truncate_start*1e-9/handles.DATA.dx);
te = ceil(handles.OPTIONS.MISC.numeric.truncate_end*1e-9/handles.DATA.dx);
handles.DATA.first = 1 + ts;
handles.DATA.last = handles.DATA.npts - te;
handles.DATA.nfit = handles.DATA.last - handles.DATA.first + 1;
if get(handles.phase_checkbox,'Value')
  [handles.DATA.z4,handles.DATA.z5,handles.DATA.rnoise,phase,imconst] =...
    phase_deer(handles.DATA.z1, handles.DATA.first, ...
    handles.DATA.last);
else
  handles.DATA.z4 = handles.DATA.z1(handles.DATA.first:handles.DATA.last);
  handles.DATA.z5 = handles.DATA.z1 ;
  phase = 0;
  imconst = 0;
  c = sum(imag(handles.DATA.z4))/length(handles.DATA.z4);
  temp = (imag(handles.DATA.z4) - c).^2;
  tlength = length(temp);
  % only use mid 1/2 of data to determine noise level
  temp = temp(ceil(tlength/4):floor(3*tlength/4));
  handles.DATA.rnoise = sum(temp);
  handles.DATA.rnoise = handles.DATA.rnoise/length(temp);
  handles.DATA.rnoise = sqrt(handles.DATA.rnoise);
end
set(handles.phase_text,'String',num2str(phase,'%5.1f'));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% handles.DATA.z1       : complex data - not phased
%              z4       : complex data - phased
%              z5       : complex data - phased but not truncated
%              deer_r   : real truncated phased data
%              deer_i   : imaginary truncated phased data
%              deer_t   : time
%              deer_t0  : truncated time zero adjusted
%              first    : first data point to be fit
%              last     : last data point to be fit
%              yfit     : fit to the data
% xplot1                : time vector for plotting (microseconds)
% xplot2                : truncated time vector for plotting (microseconds)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
handles.DATA.deer_r = real(handles.DATA.z4);
handles.DATA.deer_i = imag(handles.DATA.z4);
handles.DATA.deer_t0 = ...
  handles.DATA.deer_t(handles.DATA.first:handles.DATA.last);
xplot1 = 1.e6*handles.DATA.deer_t;
xplot2 = xplot1(handles.DATA.first:handles.DATA.last);
%   Data Input Window plot in nanoseconds
%   Plot data
try delete(handles.axes2); catch; end
handles.axes2 = axes( 'Parent', handles.figureA, 'Position', ...
  [0.075 0.40 0.175 0.50]);
%   Create multiple lines using matrix input to plot
plot2 = plot(xplot1,real(handles.DATA.z5),xplot1,imag(handles.DATA.z5), ...
  xplot2,handles.DATA.deer_r,xplot2,handles.DATA.deer_i, ...
  'Parent',handles.axes2,'MarkerSize',3,'Marker','.', ...
  'LineStyle','none');
set(plot2(1),'Color',[0 0 0]);
set(plot2(2),'Color',[0.25 0 0]);
set(plot2(3),'Color',[0.25 0.25 1]);
set(plot2(4),'Color',[1 0 0]);
xlo = xplot1(1) - 1.e7*handles.DATA.dx;
xhi = xplot1(length(handles.DATA.z5)) + 1.e7*handles.DATA.dx;
temp1 = 1.01*max(real(handles.DATA.z5));
temp2 = min(imag(handles.DATA.z5));
ymin = min(temp1,temp2);
ymax = max(temp1,temp2);
axis(handles.axes2,[xlo xhi ymin ymax]);
xlabel({'Time (\mus)'},'Parent',handles.axes2);
%   Create title
title({'data'},'Parent',handles.axes2,'Units','normalized', ...
  'FontSize',10,'Position',[0.5 0.90]);
%   Create text
q = strcat('$ Imag.\;Const.= ',num2str(imconst,'%6.0f'),'$');
text('Parent',handles.axes2,'Units','normalized','String',q,'Position', ...
  [0.01 0.25 0],'FontSize',8,'Color',[0.5 0 0],'Interpreter','latex');
q = strcat('$ Noise\;Level = ',num2str(handles.DATA.rnoise,'%6.0f'),'$');
text('Parent',handles.axes2,'Units','normalized','String',q,'Position', ...
  [0.01 0.30 0],'FontSize',8,'Color',[0.5 0 0],'Interpreter','latex');
q = strcat('$ Phase = ',num2str(phase,'%6.1f'),'^\circ$');
text('Parent',handles.axes2,'Units','normalized','String',q, ...
  'Position',[0.01 0.35],'FontSize',8,'Color',[0.5 0 0], ...
  'Interpreter','latex');
%
if get(handles.zero_time_checkbox,'Value')
  [ handles.DATA.deer_r, handles.DATA.deer_i, ...
    handles.DATA.rnoise, GAUSSIAN.par, GAUSSIAN.xg, ...
    GAUSSIAN.yg1, GAUSSIAN.yg2] = ...
    zero_deer(handles.DATA.deer_t0, handles.DATA.deer_r, ...
    handles.DATA.deer_i,handles.DATA.rnoise);
  handles.DATA.deer_t0 = ...
    handles.DATA.deer_t(handles.DATA.first:handles.DATA.last) ...
    - 1.e-09*GAUSSIAN.par(2);
  handles.axes1 = axes( 'Parent', handles.figureA, 'Position', ...
    [0.075 0.10 0.175 0.20]);
  plot1 = plot(GAUSSIAN.xg,GAUSSIAN.yg1, ...
    GAUSSIAN.xg,GAUSSIAN.yg2,'Parent',handles.axes1);
  set(plot1(1),'MarkerSize',12,'Marker','.','LineStyle','none', ...
    'Color',[0 0 0]);
  set(plot1(2),'LineWidth',3,'Color',[0 0.75 0.75]);
  %
  xlo = GAUSSIAN.xg(1);
  xhi = GAUSSIAN.xg(end);
  ymin = min(GAUSSIAN.yg1);
  ymax = 1.01*max(GAUSSIAN.yg1);
  axis(handles.axes1,[xlo xhi ymin ymax]);
  %
  title({'initial time'},'Parent',handles.axes1,'Units','normalized', ...
    'FontSize',10,'Position',[0.5 0.75]);
  q = strcat('$ zero\;time = ',num2str(GAUSSIAN.par(2), ...
    '%6.2f'),'\:ns $');
  text(0.01,0.05,q,'Units','normalized','FontSize',8, ...
    'Parent',handles.axes1,'Color',[0 0.25 0.25], ...
    'Interpreter','latex');
  set(handles.time_shift_text,'String',num2str(GAUSSIAN.par(2),'%5.1f'));
  xlabel({'Time (ns)'},'Parent',handles.axes1);
else
  handles.DATA.rnoise = handles.DATA.rnoise/max(handles.DATA.deer_r);
  handles.DATA.deer_r = handles.DATA.deer_r/max(handles.DATA.deer_r);
end
%
q = strcat('$Norm.\;Noise = ',num2str(handles.DATA.rnoise,'%6.5f'),'$');
text('Parent',handles.axes2,'Units','normalized','String',q,'Position', ...
  [0.01 0.20 0],'FontSize',8,'Color',[0.5 0 0],'Interpreter','latex')
%
set(handles.message_text,'String', ...
  'DATA Spectrum Processed and Fit Initialized', ...
  'BackgroundColor',[1.000 0.969 0.922]);
%
handles.DATA.weight = ones(size(handles.DATA.z4))/handles.DATA.rnoise;

handles.totalpoints = handles.DATA.nfit;

if get(handles.auto_checkbox,'Value')
  temp_mid = floor(length(handles.DATA.deer_r)/2);
  temp_x = handles.DATA.deer_t0(temp_mid:end);
  temp_y = handles.DATA.deer_r(temp_mid:end);
  temp_poly = polyfit(temp_x,log(temp_y),1);
  temp_z = temp_y./exp(temp_poly(1)*abs(temp_x));
  handles.ANS.values(5) = 1 - temp_z(end);
  la = real(log10(temp_poly(1)));
  % concX is display only concentration
  concX = (10^la)*1.0e-03/handles.ANS.values(5);
  temp_half = 1 - handles.ANS.values(5)/2;
  [~, idx] = min(abs(handles.DATA.deer_r - temp_half));
  handles.ANS.values(14) = 6407*(abs(handles.DATA.deer_t0(idx))^(1/3));
  set(handles.depth_edit,'String',num2str(handles.ANS.values(5)));
  set(handles.r_1_edit,'String',num2str(handles.ANS.values(14)));
  if get(handles.exponential_checkbox,'Value')
    handles.ANS.values(6) = la;
    set(handles.lambda_edit,'String',num2str(handles.ANS.values(6)));
    set(handles.concentrationX_edit,'String',num2str(concX));
  else
    handles.ANS.values(9) = concX;
    set(handles.concentration_edit,'String',num2str(concX));
  end
end
%% set a couple of PARAM values
handles.PARAM.ng = get(handles.g_1_checkbox,'Value') + ...
 get(handles.g_2_checkbox,'Value') + get(handles.g_3_checkbox,'Value') ...
 + get(handles.g_4_checkbox,'Value') + get(handles.g_5_checkbox,'Value')...
 + get(handles.g_6_checkbox,'Value')+ get(handles.g_7_checkbox,'Value')...
 + get(handles.g_8_checkbox,'Value');
handles.PARAM.shape = handles.ANS.values(13);
%%
handles.status = 1;