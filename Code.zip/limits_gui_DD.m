function varargout = limits_gui_DD(varargin)
% LIMITS_GUI_DD MATLAB code for limits_gui_DD.fig
%      LIMITS_GUI_DD, by itself, creates a new LIMITS_GUI_DD or raises the existing
%      singleton*.
%
%      H = LIMITS_GUI_DD returns the handle to a new LIMITS_GUI_DD or the handle to
%      the existing singleton*.
%
%      LIMITS_GUI_DD('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LIMITS_GUI_DD.M with the given input arguments.
%
%      LIMITS_GUI_DD('Property','Value',...) creates a new LIMITS_GUI_DD or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before limits_gui_DD_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to limits_gui_DD_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help limits_gui_DD

% Last Modified by GUIDE v2.5 06-Nov-2012 09:43:33

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @limits_gui_DD_OpeningFcn, ...
                   'gui_OutputFcn',  @limits_gui_DD_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before limits_gui_DD is made visible.
function limits_gui_DD_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to limits_gui_DD (see VARARGIN)

% Choose default command line output for limits_gui_DD
handles.output = hObject;
%
handles.names = varargin{1};
handles.ll = varargin{2}';
handles.ul = varargin{3}';
%
set(handles.limits_uitable,'RowName',handles.names(1:53));
temp = [handles.ll handles.ul];
set(handles.limits_uitable,'Data',temp);
%
% Update handles structure
guidata(hObject, handles);
% UIWAIT makes limits_gui_DD wait for user response (see UIRESUME)
uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = limits_gui_DD_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes when entered data in editable cell(s) in options_uitable.
function limits_uitable_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to options_uitable (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)
%
if eventdata.Indices(2)== 1
    handles.ll(eventdata.Indices(1)) = eventdata.NewData;
elseif eventdata.Indices(2)== 2
    handles.ul(eventdata.Indices(1)) = eventdata.NewData;
end
% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in return_pushbutton.
function return_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to return_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% resume
uiresume(handles.figure1);


% --- Executes when selected cell(s) is changed in limits_uitable.
function limits_uitable_CellSelectionCallback(hObject, eventdata, handles)
% hObject    handle to limits_uitable (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) currently selecteds
% handles    structure with handles and user data (see GUIDATA)
