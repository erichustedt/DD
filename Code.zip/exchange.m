function [bvect,svect,dvect]= exchange(PARAM)
%
bvect = [PARAM.R_sphere PARAM.rho PARAM.concentration ...
  PARAM.delta_R_background PARAM.background_depth];
svect = [PARAM.delta_R PARAM.R_max];
if(PARAM.ng > 0)
 dvect = [PARAM.ng PARAM.r0 PARAM.width ...
         PARAM.beta PARAM.zeta PARAM.amp];
else
    dvect = 0;
end
return;