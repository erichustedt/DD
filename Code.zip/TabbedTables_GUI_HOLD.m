function TabbedTables_GUI(hObject,~,handles)
% 06/08/2015 This function generates a GUI with TABBED Tables which can be 
% used to edit various OPTIONS.
figure_TT = figure('Resize','on','Units','normalized', ...
    'Position',[0.1 0.1 0.75 0.50],'ToolBar','none','MenuBar','none');
%
NAMES = fieldnames(handles.OPTIONS); 
% set up tabbed table of options
for i = 1:length(NAMES)
    tabname = char(NAMES(i));
    TAB.(tabname) = uitab('Title',tabname);
    firstname = fieldnames(handles.OPTIONS.(tabname));
    if any(strcmp('logical',firstname)) || any(strcmp('numeric',firstname))
        if any(strcmp('logical',firstname))
            rowname = fieldnames(handles.OPTIONS.(tabname).logical);
            TABLEZ.(tabname).logical = uitable(TAB.(tabname), ...
                'Data',struct2cell(handles.OPTIONS.(tabname).logical), ...
                'RowName',rowname,'ColumnName','Logical', ...
                'ColumnEditable',true,'ColumnWidth',{100}, ... 
                'ColumnFormat',{'logical'}, ...
                'Units','normalized', 'Position',[0.02 0.2 0.40 0.65], ...
                'Tag',strcat(tabname,'.logical'));
        end
        if any(strcmp('numeric',firstname))
            rowname = fieldnames(handles.OPTIONS.(tabname).numeric);
            TABLEZ.(tabname).numeric = uitable(TAB.(tabname), ...
                'Data', struct2cell(handles.OPTIONS.(tabname).numeric), ...
                'RowName',rowname,'ColumnName','Values', ...
                'ColumnEditable',true,'ColumnWidth',{100}, ...  
                'ColumnFormat',{'numeric'}, ...
                'Units','normalized', 'Position',[0.52 0.2 0.40 0.65], ...
                'Tag',strcat(tabname,'.numeric'));
        end
    else
        rowname = firstname;
        TABLEZ.(tabname) = uitable(TAB.(tabname), ...
            'Data', struct2cell(handles.OPTIONS.(tabname)), ...
            'RowName',rowname,'ColumnName',[], ...
            'ColumnEditable',true, ... 
            'Units','normalized', 'Position',[0.1 0.6 0.333 0.333], ...
            'Tag',tabname);
    end
end
%
% for i = 1:length(NAMES)
%   tabname = char(NAMES(i)); 
%   firstname = fieldnames(handles.OPTIONS.(tabname));
%   if any(strcmp('logical',firstname)) 
%     TABLEZ.(tabname).logical.CellEditCallback = ...
%       @(src,event)Logical_Edit_Callback(src,event,TABLEZ,figure_TT);
%   end
% end
set(figure_TT,'deletefcn',{@passback,hObject,handles,TABLEZ});
end

function passback(varargin)
hObject = varargin{3};
handles = varargin{4};
TABLEZ = varargin{5};
NAMES_1 = fieldnames(TABLEZ);
for i = 1:length(NAMES_1)
  tabname = char(NAMES_1(i));
  NAMES_2 = fieldnames(TABLEZ.(tabname));
  for j = 1:length(NAMES_2)
    subname = char(NAMES_2(j));
    NAMES_3 = TABLEZ.(tabname).(subname).RowName;
    for k = 1:length(NAMES_3)
      rowname = char(NAMES_3(k));
      handles.OPTIONS.(tabname).(subname).(rowname) = ...
        cell2mat(TABLEZ.(tabname).(subname).Data(k));
    end
  end
end
%% Changed 02/14/2018  
temp1 = handles.OPTIONS.LM.logical.LM+ ...
        handles.OPTIONS.IP.logical.interiorpoint + ...
        handles.OPTIONS.GS.logical.globalsearch + ...
        handles.OPTIONS.PS.logical.particleswarm +...
        handles.OPTIONS.SP.logical.fminsearch ; 
if temp1 == 0
  h = msgbox('return and select a fitting method');
  uiwait(h);
  TabbedTables_GUI(hObject, [], handles);
end
if temp1 > 1
  h = msgbox('return and select only one minimization method');
  uiwait(h);
  TabbedTables_GUI(hObject, [], handles);
end 
%%
set(handles.truncate_end_edit,'String', ...
  num2str(handles.OPTIONS.MISC.numeric.truncate_end));
set(handles.truncate_start_edit,'String', ...
  num2str(handles.OPTIONS.MISC.numeric.truncate_start));
% Update handles structure
guidata(hObject,handles); 
end
