function [ handles ] = set_calculated( handles )
% 08/12/2015 - EJH
% Function to activate use of Calculated background
% lambda
de = handles.ANS.values(5);
la = handles.ANS.values(6);
co = (10^la)*1.0e-03/de;
handles.ANS.values(6) = -10;
set(handles.lambda_edit,'String',num2str(handles.ANS.values(6)));
handles.ANS.fixed(6) = 1;
set(handles.lambda_checkbox,'Value',~handles.ANS.fixed(6));
% dimension
% handles.ANS.values(7) = 3;
% set(handles.d_edit,'String',num2str(handles.ANS.values(7)));
handles.ANS.fixed(7) = 1;
set(handles.d_checkbox,'Value',~handles.ANS.fixed(7));
% background depth
handles.ANS.values(8) = 0;
set(handles.b_depth_edit,'String',num2str(handles.ANS.values(8)));
handles.ANS.fixed(8) = 1;
set(handles.b_depth_checkbox,'Value',~handles.ANS.fixed(8));
handles.ANS.links(8) = 5;
set(handles.link_depth_checkbox,'Value',1);
% concentration
if la > 0 
   handles.ANS.values(9) = co;
   set(handles.concentration_edit,'String',num2str(handles.ANS.values(9)));
end 
handles.ANS.fixed(9) = 0;
set(handles.concentration_checkbox,'Value',~handles.ANS.fixed(9));
% rho
handles.ANS.values(10) = 35;
set(handles.rho_edit,'String',num2str(handles.ANS.values(10)));
handles.ANS.fixed(10) = 0;
set(handles.rho_checkbox,'Value',~handles.ANS.fixed(10));
end

