function varargout = confidence_bands_A_GUI(varargin)
% CONFIDENCE_BANDS_A_GUI MATLAB code for confidence_bands_A_GUI.fig
%      CONFIDENCE_BANDS_A_GUI, by itself, creates a new CONFIDENCE_BANDS_A_GUI or raises the existing
%      singleton*.
%
%      H = CONFIDENCE_BANDS_A_GUI returns the handle to a new CONFIDENCE_BANDS_A_GUI or the handle to
%      the existing singleton*.
%
%      CONFIDENCE_BANDS_A_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CONFIDENCE_BANDS_A_GUI.M with the given input arguments.
%
%      CONFIDENCE_BANDS_A_GUI('Property','Value',...) creates a new CONFIDENCE_BANDS_A_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before confidence_bands_A_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to confidence_bands_A_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help confidence_bands_A_GUI

% Last Modified by GUIDE v2.5 02-Oct-2015 17:39:41

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @confidence_bands_A_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @confidence_bands_A_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before confidence_bands_A_GUI is made visible.
function confidence_bands_A_GUI_OpeningFcn(hObject, ~, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to confidence_bands_A_GUI (see VARARGIN)

% Choose default command line output for confidence_bands_A_GUI
%
hObject.WindowStyle = 'normal';
hObject.ToolBar = 'none';
%
handles.output = hObject;
CB = varargin{1}; 
p = plot(CB.CI.bestr,CB.CI.bestp,'Parent',handles.axes51);
hold on;
p(1).LineStyle = '-';
p(1).Color = 'k';
p(1).LineWidth = 2;
patch(CB.CI.bestr,CB.CI.upper,'b','LineStyle','none', ...
    'FaceAlpha',0.25,'Parent',handles.axes51)
patch(CB.CI.bestr,CB.CI.lower,'w','LineStyle','none', ...
    'Parent',handles.axes51);
for i = 1:CB.PARAM.ng
    p(i+1) = plot(CB.HOLD.r,CB.HOLD.component(i,:), ...
        'Parent',handles.axes51);
    p(i+1).Color = [0.0 0.5 0.0];
    p(i+1).LineWidth = 0.5;
end 
temp = 1.05*max(CB.CI.upper);
temps = (CB.DATA.deer_t(end)*5.204e10)^(1/3);
tempe = CB.CI.bestr(end);
patch([temps temps tempe tempe temps],[0. temp temp 0 0],'red',...
  'LineStyle','none','FaceAlpha',0.05); 
try
    axis(handles.axes51,[CB.CI.bestr(1) CB.CI.bestr(end) ...
      0. 1.05*max(CB.CI.upper)]);
catch
end
%% Integrals
textv = num2str(trapz(CB.CI.bestr,CB.CI.lower));
textv = strcat('Integral= ',textv);
text(0.75,0.81,textv,'Units','normalized','FontSize',10,'Color', ...
  [0.75 0 0],'Parent',handles.axes51);
textv = num2str(trapz(CB.CI.bestr,CB.CI.bestp));
textv = strcat('Integral= ',textv);
text(0.75,0.88,textv,'Units','normalized','FontSize',10,'Color', ...
  [0 0 0],'Parent',handles.axes51);
textv = num2str(trapz(CB.CI.bestr,CB.CI.upper));
textv = strcat('Integral= ',textv);
text(0.75,0.95,textv,'Units','normalized','FontSize',10,'Color', ...
  [0 0.5 0],'Parent',handles.axes51);
%%
q = strcat('$\chi_{\nu}^2 = ',num2str(CB.DATA.chisquared),'$');
text(0.01,0.16,q,'Units','normalized', ...
    'FontSize',10,'Color',[0 0 0.5],'Parent',handles.axes51, ...
    'Interpreter','latex');
%% AICc
q= horzcat('$ AICc = ',num2str(CB.DATA.AICc,'%10.1f'),'$');
text(0.01,0.10,q,'Units','normalized', ...
    'FontSize',10,'Color',[0 0 0.5],'Parent',handles.axes51, ...
    'Interpreter','latex');
q= horzcat('$ BIC = ',num2str(CB.DATA.BIC,'%10.1f'),'$');
text(0.01,0.04,q,'Units','normalized', ...
    'FontSize',10,'Color',[0 0 0.5],'Parent',handles.axes51, ...
    'Interpreter','latex');
%% Data File Name
text(0.01,0.95,CB.DATA.name,'Units','normalized','FontSize',10,'Color', ...
  [0 0 0.5],'Parent',handles.axes51,'Interpreter','none'); 
%% Display parameters and uncertainties
p = 'param. = val. +/- uncert. (2 sigma covar.)';
q = strcat(CB.FLOAT.floatnames,' = ', ...
    num2str(CB.FLOAT.float'),' +/- ',num2str(2*CB.CI.uncertainty'));
q = vertcat(p,q);
if CB.status == 5
    q(1) = strcat(q(1),' [- (2 sigma CI) + (2 sigma CI)]');
    for i = 1:CB.FLOAT.nfloat
        q(i+1) = strcat(q(i+1),' [ ', ...
            num2str(CB.CI.errors(i,2,1) - CB.FLOAT.float(i)), ' +', ...
            num2str(CB.CI.errors(i,2,2) - CB.FLOAT.float(i)),' ]');
    end
end
set(handles.parameters_listbox,'String',q)
%%
try
  axis(handles.axes51,[CB.CI.bestr(1) CB.CI.bestr(end) ...
    0. 1.05*max(CB.CI.upper)]);
catch 
end
% Update handles structure
guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = confidence_bands_A_GUI_OutputFcn(hObject, ~, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function parameters_listbox_CreateFcn(hObject, ~, ~)
% hObject    handle to parameters_listbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
