function varargout = confidence_interval_gui(varargin)
% CONFIDENCE_INTERVAL_GUI MATLAB code for confidence_interval_gui.fig
%      CONFIDENCE_INTERVAL_GUI, by itself, creates a new CONFIDENCE_INTERVAL_GUI or raises the existing
%      singleton*.
%
%      H = CONFIDENCE_INTERVAL_GUI returns the handle to a new CONFIDENCE_INTERVAL_GUI or the handle to
%      the existing singleton*.
%
%      CONFIDENCE_INTERVAL_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CONFIDENCE_INTERVAL_GUI.M with the given input arguments.
%
%      CONFIDENCE_INTERVAL_GUI('Property','Value',...) creates a new CONFIDENCE_INTERVAL_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before confidence_interval_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to confidence_interval_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help confidence_interval_gui

% Last Modified by GUIDE v2.5 04-Nov-2016 21:20:12

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @confidence_interval_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @confidence_interval_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before confidence_interval_gui is made visible.
function confidence_interval_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to confidence_interval_gui (see VARARGIN)

% Choose default command line output for confidence_interval_gui
handles.output = hObject;
%%
handles.floatnames = varargin{1};
handles.best = varargin{2};
handles.np = length(handles.best);
handles.uncertainty = cell2mat(varargin(3));
ci_stop = varargin{4};
ci_plot = varargin{5};
ci_bflag = varargin{6};
ci_cflag = varargin{7};
%%
try
  cicell= varargin{8};
  cicell(:,1) = num2cell(handles.best);
catch 
  tab1 = handles.best;
  tab2 = -1*ones(1,handles.np);
  tab3 = ones(1,handles.np);
  tab4 = ones(1,handles.np);
  tab5 = true(1,handles.np);
  citable = table(tab1',tab2',tab3',tab4',tab5');
  cicell = table2cell(citable);
end;
%%
set(handles.confidence_interval_uitable,'ColumnFormat',{'numeric' ...
  'numeric' 'numeric' 'numeric' 'logical'});
set(handles.confidence_interval_uitable,'ColumnEditable',[false true ...
  true true true]);
set(handles.confidence_interval_uitable,'RowName',handles.floatnames);
set(handles.confidence_interval_uitable,'Data',cicell);
%%
set(handles.stop_ci_checkbox,'Value',ci_stop);
set(handles.plot_ci_checkbox,'Value',ci_plot);
%%
set(handles.extreme_GUI_checkbox,'Value',ci_bflag);
set(handles.fill_GUI_checkbox,'Value',ci_cflag);
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes confidence_interval_gui wait for user response (see UIRESUME)
uiwait(handles.figure1);

% --- Outputs from this function are returned to the command line.
function varargout = confidence_interval_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes when entered data in editable cell(s) in confidence_interval_uitable.
function confidence_interval_uitable_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to confidence_interval_uitable (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)
%
% Update handles structure
guidata(hObject, handles);

% --- Executes on button press in return_pushbutton.
function return_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to return_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.data = get(handles.confidence_interval_uitable,'Data');
handles.data(:,1) = {0.};
handles.plot = get(handles.plot_ci_checkbox,'Value');
handles.stop = get(handles.stop_ci_checkbox,'Value');
handles.bflag = get(handles.extreme_GUI_checkbox,'Value');
handles.cflag = get(handles.fill_GUI_checkbox,'Value');
% Update handles structure
guidata(hObject, handles);
% resume
uiresume(handles.figure1);

% --- Executes on button press in plot_ci_checkbox.
function plot_ci_checkbox_Callback(hObject, eventdata, ~)
% hObject    handle to plot_ci_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of plot_ci_checkbox

% --- Executes on button press in stop_ci_checkbox.
function stop_ci_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to stop_ci_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of stop_ci_checkbox

% --- Executes on button press in narrow_pushbutton.
function narrow_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to narrow_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
tab1 = handles.best;
tab2 = -10.*handles.uncertainty/3.;
tab3 = +10.*handles.uncertainty/3.;
tab4 = handles.uncertainty/3.;
tab5 = true(1,handles.np);
citable = table(tab1',tab2',tab3',tab4',tab5');
cicell = table2cell(citable); 
%
set(handles.confidence_interval_uitable,'ColumnFormat',{'numeric' ...
  'numeric' 'numeric' 'numeric' 'logical'});
set(handles.confidence_interval_uitable,'ColumnEditable',[false true ...
  true true true]);
set(handles.confidence_interval_uitable,'RowName',handles.floatnames);
set(handles.confidence_interval_uitable,'Data',cicell);

% Update handles structure
guidata(hObject, handles);

% --- Executes on button press in broad_pushbutton.
function broad_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to broad_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
tab1 = handles.best;
tab2 = -25.*handles.uncertainty;
tab3 = +25.*handles.uncertainty;
tab4 = 2.5*handles.uncertainty;
tab5 = true(1,handles.np);
citable = table(tab1',tab2',tab3',tab4',tab5');
cicell = table2cell(citable); 
%
set(handles.confidence_interval_uitable,'ColumnFormat',{'numeric' ...
  'numeric' 'numeric' 'numeric' 'logical'});
set(handles.confidence_interval_uitable,'ColumnEditable',[false true ...
  true true true]);
set(handles.confidence_interval_uitable,'RowName',handles.floatnames);
set(handles.confidence_interval_uitable,'Data',cicell);
% Update handles structure
guidata(hObject, handles);

% --- Executes on button press in extreme_GUI_checkbox.
function extreme_GUI_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to extreme_GUI_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of extreme_GUI_checkbox
handles.bflag = get(handles.extreme_GUI_checkbox,'Value');
% Update handles structure
guidata(hObject, handles);

% --- Executes on button press in fill_GUI_checkbox.
function fill_GUI_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to fill_GUI_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of fill_GUI_checkbox
handles.cflag = get(handles.fill_GUI_checkbox,'Value');
% Update handles structure
guidata(hObject, handles);