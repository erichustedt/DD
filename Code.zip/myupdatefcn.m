function txt = myupdatefcn(empt,event_obj,m,n,x) 
pos = get(event_obj,'Position');
index1 = find(x == pos(1));
if pos(1) <= 0 
  index2 = m + index1 - 1;
  text = 'From first: ';
else
  index2 = n - index1;
  text = 'From last : ';
end 
txt = {['Time        : ',num2str(pos(1))],...
       ['Amplitude: ',num2str(pos(2))],...
       ['Index       : ', num2str(index1)]...
       [text, num2str(index2)]};

