function varargout = list_statistics_gui_DD(varargin)
% LIST_STATISTICS_GUI_DD MATLAB code for list_statistics_gui_DD.fig
%      LIST_STATISTICS_GUI_DD, by itself, creates a new LIST_STATISTICS_GUI_DD or raises the existing
%      singleton*.
%
%      H = LIST_STATISTICS_GUI_DD returns the handle to a new LIST_STATISTICS_GUI_DD or the handle to
%      the existing singleton*.
%
%      LIST_STATISTICS_GUI_DD('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LIST_STATISTICS_GUI_DD.M with the given input arguments.
%
%      LIST_STATISTICS_GUI_DD('Property','Value',...) creates a new LIST_STATISTICS_GUI_DD or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before list_statistics_gui_DD_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to list_statistics_gui_DD_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help list_statistics_gui_DD

% Last Modified by GUIDE v2.5 28-Jun-2016 15:27:00

% Begin initialization code - DO NOT EDIT
%__________________________________________________________________________
% modified 6/2/2018 to fix various issues with sort/delete - EJH
% modified 4/11/2019 to fix issue with findjobj and Matlab 2018b
% findjobj(handles.figure1,'class','UIScrollPane') seems OK - EJH
%__________________________________________________________________________
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @list_statistics_gui_DD_OpeningFcn, ...
                   'gui_OutputFcn',  @list_statistics_gui_DD_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before list_statistics_gui_DD is made visible.
function list_statistics_gui_DD_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to list_statistics_gui_DD (see VARARGIN)

% Choose default command line output for list_statistics_gui_DD
handles.output = hObject;
%
temp = varargin{1};
handles.Directory = temp.DataDirectory;
%
ns = size(temp.save_statistics,1);
temp_data = temp.save_statistics; 
% 
list = temp_data(:,1);
%% Delta AICc values
values = cell2mat(temp_data(:,12));
u = unique(list);
v = length(u);
z = zeros(ns,1);
for i = 1:v
    w = strmatch(u(i),list,'exact');
    [a,~] = min(values(w));
    z(w) = values(w) - a;
end
temp_data = [temp_data num2cell(z)];
%% Delta BIC values
values = cell2mat(temp_data(:,13));
u = unique(list);
v = length(u);
z = zeros(ns,1);
for i = 1:v
    w = strmatch(u(i),list,'exact');
    [a,~] = min(values(w));
    z(w) = values(w) - a;
end
temp_data = [temp_data num2cell(z)];
set(handles.list_statistics_uitable,'Data',temp_data);
%% Code to make uitable sortable
jscroll = findjobj(handles.figure1,'class','UIScrollPane'); 
handles.jtable = jscroll(1).getViewport.getView;
handles.jtable.setSortable(true);
handles.jtable;
%% Code to make rows selectable
handles.jtable.setNonContiguousCellSelection(false);
handles.jtable.setRowSelectionAllowed(true); 
handles.jtable.setColumnSelectionAllowed(false);
%%
%-------------------------------------------------------------------------- 
% find all static text UIControls whose 'Tag' begins with 'latex_', these
% will be replaced with axes text labels formatted in LaTeX
latex_labels = findobj(hObject,'-regexp','Tag','latex_');
for i = 1:length(latex_labels)
    set(latex_labels(i),'Units','normalized');
    % get parent of current label and the tag for the parent
    latex_xp = get(latex_labels(i),'Parent');
    latex_xt = get(latex_xp,'Tag');
    % TEXT annotations require an axes as parent so create an invisible axes
    if ~isfield(handles,'latex_axes') || ~isfield(handles.latex_axes,latex_xt)
        handles.latex_axes.(latex_xt) = axes('Parent',latex_xp, ...
            'Units','normalized','Position',[0 0 1 1], ...
            'Visible','off');
    end
    % get current text, position, tag,and color
    latex_s = get(latex_labels(i),'String');
    latex_p = get(latex_labels(i),'Position');
    latex_t = get(latex_labels(i),'Tag');
    latex_c = get(latex_labels(i),'ForegroundColor');
    % remove the original UIControl
    delete(latex_labels(i));
    % replace with a TEXT object
    handles.(latex_t) = text(latex_p(1),latex_p(2),latex_s, ...
        'Interpreter','latex','Parent',handles.latex_axes.(latex_xt), ...
        'FontSize',12,'Color',latex_c);
end
%--------------------------------------------------------------------------
% Update handles structure
guidata(hObject, handles);
% UIWAIT makes limits_gui_DD wait for user response (see UIRESUME)
uiwait(handles.figure1);  

% --- Outputs from this function are returned to the command line.
function varargout = list_statistics_gui_DD_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
try
  varargout{1} = handles.output;
catch
  varargout{1} = {}; 
end

% --- Executes on button press in save_pushbutton.
function save_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to save_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
col = {'Filename','Sigma','Components','Shape','Background','RSS', ...
  'N','m','nu','Reduced chi-square','Modes','AICc','BIC','Delta-AICc', ...
  'Delta-BIC'}; 
data=get(handles.list_statistics_uitable,'Data');
[file,path] = uiputfile('*.xls','Save As:',handles.Directory);
if exist(strcat(path,file)) == 2
  delete(strcat(path,file));
end
out = [col;data];
% this instance of xlswrite is ok
xlswrite(strcat(path,file),out);

% --- Executes on button press in print_pushbutton.
function print_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to print_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.print_pushbutton.Visible = 'off';
handles.save_pushbutton.Visible = 'off';
handles.quit_pushbutton.Visible = 'off';
handles.clear_pushbutton.Visible = 'off';
handles.sortA_pushbutton.Visible = 'off';
handles.sortB_pushbutton.Visible = 'off';
handles.delete_last_pushbutton.Visible = 'off';
handles.delete_selected_pushbutton.Visible = 'off';
orient(handles.output,'landscape');
print(handles.output);
handles.print_pushbutton.Visible = 'on';
handles.save_pushbutton.Visible = 'on';
handles.quit_pushbutton.Visible = 'on';
handles.clear_pushbutton.Visible = 'on';
handles.sortA_pushbutton.Visible = 'on';
handles.sortB_pushbutton.Visible = 'on';
handles.delete_last_pushbutton.Visible = 'on';
handles.delete_selected_pushbutton.Visible = 'on';

% --- Executes on button press in quit_pushbutton.
function quit_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to quit_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Update handles structure
guidata(hObject, handles);
% resume
uiresume(handles.figure1);  

% --- Executes on button press in clear_pushbutton.
function clear_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to clear_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.list_statistics_uitable,'Data',{});
% Update handles structure
guidata(hObject, handles);
% resume
uiresume(handles.figure1);  

% --- Executes on button press in sortA_pushbutton.
function sortA_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to sortA_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
q = get(handles.list_statistics_uitable,'Data'); 
q = sortrows(q,14);
set(handles.list_statistics_uitable,'Data',q);
% Update handles structure
guidata(hObject, handles);

% --- Executes on button press in sortB_pushbutton.
function sortB_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to sortB_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
q = get(handles.list_statistics_uitable,'Data'); 
q = sortrows(q,15);
set(handles.list_statistics_uitable,'Data',q);
% Update handles structure
guidata(hObject, handles);

% --- Executes on button press in delete_last_pushbutton.
function delete_last_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to delete_last_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
q = get(handles.list_statistics_uitable,'Data'); 
% java uses zero-based indexing so subtract 1
v = handles.jtable.getRowCount - 1;  
% after sorting by clicking on columns data is not sorted just display
% need to be sure to get correct rows using 'jtable.getActualRowAt'
u = handles.jtable.getActualRowAt(v);
% java uses zero-based indexing so add 1
% SelectedRows is java / removerows is Matlab
q = removerows(q,'ind',u+1);
set(handles.list_statistics_uitable,'Data',q);
% Update handles structure
guidata(hObject, handles);

% --- Executes on button press in delete_selected_pushbutton.
function delete_selected_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to delete_selected_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
q = get(handles.list_statistics_uitable,'Data'); 
v = get(handles.jtable,'SelectedRows');
nd = length(v);
for k = 1:nd
  u = handles.jtable.getActualRowAt(v(k));
  % java uses zero-based indexing so add 1
  % SelectedRows is java / removerows is Matlab
  q = removerows(q,'ind',u+1);
end
set(handles.list_statistics_uitable,'Data',q);
