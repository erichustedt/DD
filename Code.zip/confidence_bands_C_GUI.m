function varargout = confidence_bands_C_GUI(varargin)
% 09/19/2016 - EJH - Version 6B
% CONFIDENCE_BANDS_C_GUI MATLAB code for confidence_bands_C_GUI.fig
%  CONFIDENCE_BANDS_C_GUI, by itself, creates a new CONFIDENCE_BANDS_C_GUI or raises the existing
%  singleton*.
%
%  H = CONFIDENCE_BANDS_C_GUI returns the handle to a new CONFIDENCE_BANDS_C_GUI or the handle to
%  the existing singleton*.
%
%  CONFIDENCE_BANDS_C_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%  function named CALLBACK in CONFIDENCE_BANDS_C_GUI.M with the given input arguments.
%
%  CONFIDENCE_BANDS_C_GUI('Property','Value',...) creates a new CONFIDENCE_BANDS_C_GUI or raises the
%  existing singleton*.  Starting from the left, property value pairs are
%  applied to the GUI before confidence_bands_C_GUI_OpeningFcn gets called.  An
%  unrecognized property name or invalid value makes property application
%  stop.  All inputs are passed to confidence_bands_C_GUI_OpeningFcn via varargin.
%
%  *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%  instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help confidence_bands_C_GUI

% Last Modified by GUIDE v2.5 08-Sep-2016 13:57:52

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',   mfilename, ...
  'gui_Singleton',  gui_Singleton, ...
  'gui_OpeningFcn', @confidence_bands_C_GUI_OpeningFcn, ...
  'gui_OutputFcn',  @confidence_bands_C_GUI_OutputFcn, ...
  'gui_LayoutFcn',  [] , ...
  'gui_Callback',   []);
if nargin && ischar(varargin{1})
  gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
  [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
  gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before confidence_bands_C_GUI is made visible.
function confidence_bands_C_GUI_OpeningFcn(hObject, ~, handles, varargin)
% This function has no output args, see OutputFcn.
% hObjecthandle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handlesstructure with handles and user data (see GUIDATA)
% varargin   command line arguments to confidence_bands_C_GUI (see VARARGIN)
% Choose default command line output for confidence_bands_C_GUI
handles.output = hObject;
handles.CC = varargin{1};
%%
if(get(handles.s1_radiobutton,'Value')); handles.sigma = 1; end
if(get(handles.s2_radiobutton,'Value')); handles.sigma = 2; end
if(get(handles.s3_radiobutton,'Value')); handles.sigma = 3; end
%%
handles.limits = zeros(handles.CC.CI.nconf,2);
for i = 1:handles.CC.CI.nconf
  handles.limits(i,1) = handles.CC.CI.errors(i,handles.sigma,1);
  handles.limits(i,2) = handles.CC.CI.errors(i,handles.sigma,2);
end
%%
[row,col] = find(isnan(handles.limits));
if ~isempty(row)
  for k = 1:length(row)
    fpi = handles.CC.FLOAT.floatparindex(1,:);
    j = fpi(handles.CC.CI.cindex(row(k)));
    if col(k) == 1
      handles.limits(row(k),col(k)) = handles.CC.ANS.lowerlimit(j);
    end
    if col(k) == 2 
      handles.limits(row(k),col(k)) = handles.CC.ANS.upperlimit(j);
    end
  end
end
%%
set(handles.limits_listbox,'String',num2str(handles.limits));
try
  set(handles.number_edit,'String',num2str(handles.number));
catch
end
try
  set(handles.success_text,'String',num2str(0));
catch
end
%%
cla(handles.axes22);
handles.plot9 = plot(handles.axes22,handles.CC.CI.bestr, ...
  handles.CC.CI.delta, handles.CC.CI.bestr, ...
  handles.CC.CI.matrix_1(13,:));
handles.plot9(1).LineStyle = '-';
handles.plot9(1).Color = 'k';
handles.plot9(1).LineWidth = 2;
handles.plot9(2).LineStyle = '-';
handles.plot9(2).Color = 'r';
handles.plot9(2).LineWidth = 2;
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes confidence_bands_C_GUI wait for user response (see UIRESUME)
% uiwait(handles.figureCBc);

% --- Outputs from this function are returned to the command line.
function varargout = confidence_bands_C_GUI_OutputFcn(hObject, ~, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObjecthandle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handlesstructure with handles and user data (see GUIDATA)
  
% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in fill_pushbutton.
function fill_pushbutton_Callback(hObject, ~, handles)
% hObjecthandle to fill_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handlesstructure with handles and user data (see GUIDATA)
%%
set(handles.fill_pushbutton,'Enable','off');
set(handles.fill_pushbutton,'String','running');
set(handles.fill_pushbutton,'ForegroundColor','red');
drawnow;
GUI_Control(handles.CC.figureDD,'off');
try
  GUI_Control(handles.CC.figureCBb,'off');
catch
end
%%
handles.number = str2num(get(handles.number_edit,'String'));
if(get(handles.s1_radiobutton,'Value')); target = handles.CC.CI.target1s; end
if(get(handles.s2_radiobutton,'Value')); target = handles.CC.CI.target2s; end
if(get(handles.s3_radiobutton,'Value')); target = handles.CC.CI.target3s; end
%%
temp(1,:) = handles.CC.CI.bestp +  ...
  handles.sigma*handles.CC.CI.matrix_1(13,:);
temp(2,:) = handles.CC.CI.bestp - ...
  handles.sigma*handles.CC.CI.matrix_1(13,:);
%%
k = 0;
set(handles.success_text,'String',[num2str(k)]);
for j = 1:handles.number 
  set(handles.number_edit,'String', ...
    [num2str(j) '/' num2str(handles.number)]);
  drawnow;
  for i = 1:handles.CC.CI.nconf
    q = rand;
    handles.CC.ANS.values(handles.CC.FLOAT.floatparindex(1, ...
      handles.CC.CI.cindex(i))) = (1-q)*handles.limits(i,1) + ...
      q*handles.limits(i,2);
  end
  %% Copy all parameters to PARAM
  [handles.CC.PARAM,handles.CC.DISTRIBUTION] = copy_param( ...
    handles.CC.PARAM, 1, handles.CC.ANS, handles.CC.ANS.nparam, ...
    handles.CC.ANS.namelengths);
  %% initial calculation
  [handles.CC.DATA,handles.CC.PARAM,handles.CC.HOLD, ...
    handles.CC.PARAM0] = deer_first(1,handles.CC.DATA,handles.CC.PARAM);
  handles.CC = determine_chi2(handles.CC);
  if handles.CC.DATA.totalchisquared <= target
    k = k + 1;
    temp(k+2,:) = handles.CC.HOLD.p;
    set(handles.success_text,'String',[num2str(k) '/' num2str(j)]);
    a = max(temp(1:k+2,:)) ;
    b = min(temp(1:k+2,:)) ;
    d = (a-b)/(2*handles.sigma);
    cla(handles.axes22);
    handles.plot9 = plot(handles.axes22,handles.CC.CI.bestr, ...
      handles.CC.CI.delta, handles.CC.CI.bestr, ...
      handles.CC.CI.matrix_1(13,:), handles.CC.CI.bestr, d);
    handles.plot9(1).LineStyle = '-';
    handles.plot9(1).Color = 'k';
    handles.plot9(1).LineWidth = 2;
    handles.plot9(2).LineStyle = '-';
    handles.plot9(2).Color = 'r';
    handles.plot9(2).LineWidth = 2;
    handles.plot9(3).LineStyle = '--';
    handles.plot9(3).Color = 'g';
    handles.plot9(3).LineWidth = 2;
    drawnow;
  end
end
%% Output to Excel
if handles.CC.OPTIONS.OUTPUT.logical.output2Excel;
  %% KILL any existing EXCEL processe
  killExcel
  %%
  ExcelTrue = actxserver ('Excel.Application');
  set(ExcelTrue, 'Visible', 0);
  %% Check Office Version
  %  For Office 2010 or earlier 3 sheets are opened by default, for later
  %  versions only 1 sheet is opened
  office_version = ExcelTrue.Version;
  if office_version >= 15
    open_sheet = 1;
  else
    open_sheet = 3;
  end
  %%
  WorkBook =  ExcelTrue.Workbooks.Open(handles.CC.answerfile);
  Sheets = ExcelTrue.ActiveWorkbook.Sheets;
  %% 
  sheetname = char('deltas');
  temp = sheet_names(ExcelTrue,Sheets);
  if ~all(~strcmp(temp,sheetname))
    ClearExcelWorksheet(handles.CC.answerfile,sheetname);
    invoke(ExcelTrue.ActiveWorkbook.Sheets.Item(sheetname),'Activate');
    ActiveSheet = ExcelTrue.Activesheet; 
  else
    esheet = Sheets.Count + 1;
    if esheet > open_sheet
      Sheets.Add([], ...
        ExcelTrue.ActiveWorkbook.Sheets.Item(esheet-1));
    end
    invoke(get(Sheets, 'Item', esheet), 'Activate');
    ActiveSheet = ExcelTrue.Activesheet;  % Make sheet active
    ActiveSheet.Name = strcat(sheetname);
  end
  disp(ActiveSheet.Name);
  %
  q = {'R'};
  set(get(ActiveSheet,'Range', ExcelRange('A1',q)), 'Value', q);
  %
  q = handles.CC.CI.bestr';
  set(get(ActiveSheet,'Range', ExcelRange('A2',q)), 'Value', q);
  %
  q = {'delta'};
  set(get(ActiveSheet,'Range', ExcelRange('B1',q)), 'Value', q);
  %
  q = handles.CC.CI.delta';
  set(get(ActiveSheet,'Range', ExcelRange('B2',q)), 'Value', q);
  %
  q = {'CI Min.'};
  set(get(ActiveSheet,'Range', ExcelRange('C1',q)), 'Value', q);
  %
  q = handles.CC.CI.matrix_1(9,:)';
  set(get(ActiveSheet,'Range', ExcelRange('C2',q)), 'Value', q);  
  %
  q = {'CI Max.'};
  set(get(ActiveSheet,'Range', ExcelRange('D1',q)), 'Value', q);
  %
  q = handles.CC.CI.matrix_1(10,:)';
  set(get(ActiveSheet,'Range', ExcelRange('D2',q)), 'Value', q);
  %
  q = {'CI delta'};
  set(get(ActiveSheet,'Range', ExcelRange('E1',q)), 'Value', q);
  %
  q = handles.CC.CI.matrix_1(13,:)';
  set(get(ActiveSheet,'Range', ExcelRange('E2',q)), 'Value', q);
  %
  if exist('b')
    q = {'FILL Min.'};
    set(get(ActiveSheet,'Range', ExcelRange('F1',q)), 'Value', q);
    %
    q = b';
    set(get(ActiveSheet,'Range', ExcelRange('F2',q)), 'Value', q); 
  end
  %
  if exist('a')
    q = {'FILL Max.'};
    set(get(ActiveSheet,'Range', ExcelRange('G1',q)), 'Value', q);
    %
    q = a';
    set(get(ActiveSheet,'Range', ExcelRange('G2',q)), 'Value', q); 
  end  
  %
  if exist('d')
    q = {'FILL Delta'};
    set(get(ActiveSheet,'Range', ExcelRange('H1',q)), 'Value', q);
    %
    q = d';
    set(get(ActiveSheet,'Range', ExcelRange('H2',q)), 'Value', q); 
  end
  %% Close Excel
  sheet = get(Sheets, 'Item', 1);
  invoke(sheet, 'Activate');
  ExcelTrue.displayalerts = false;
  WorkBook.SaveAs(handles.CC.answerfile);
  DeleteEmptyExcelSheets(handles.CC.answerfile);
  invoke(ExcelTrue, 'Quit');
  delete(ExcelTrue);
end
%%
[t1,~,~] = fileparts(handles.CC.answerfile);
q = [t1 handles.CC.sep 'C.pdf'];
saveas(handles.figureCBc, q);
%%
set(handles.fill_pushbutton,'Enable','on');
set(handles.fill_pushbutton,'String','FILL');
set(handles.fill_pushbutton,'ForegroundColor','white');
GUI_Control(handles.CC.figureDD);
try
  GUI_Control(handles.CC.figureCBb);
catch
end
% Update handles structure
% Update handles structure
guidata(hObject, handles);

function number_edit_Callback(hObject, ~, handles)
% hObjecthandle to number_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handlesstructure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of number_edit as text
%str2double(get(hObject,'String')) returns contents of number_edit as a double
handles.number = get(handles.number_edit,'Value');
cla(handles.axes22);
handles.plot9 = plot(handles.axes22,handles.CC.CI.bestr, ...
  handles.CC.CI.delta, handles.CC.CI.bestr, ...
  handles.CC.CI.matrix_1(13,:));
handles.plot9(1).LineStyle = '-';
handles.plot9(1).Color = 'k';
handles.plot9(1).LineWidth = 2;
handles.plot9(2).LineStyle = '-';
handles.plot9(2).Color = 'r';
handles.plot9(2).LineWidth = 2;
set(handles.success_text,'String',num2str(0))
% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function number_edit_CreateFcn(hObject, ~, handles)
% hObjecthandle to number_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handlesempty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%   See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in s1_radiobutton.
function s1_radiobutton_Callback(hObject, ~, handles)
% hObjecthandle to s1_radiobutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handlesstructure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of s1_radiobutton
%%
if(get(handles.s1_radiobutton,'Value'))  
  handles.sigma = 1; 
  handles.target = handles.CC.CI.target1s;
end
if(get(handles.s2_radiobutton,'Value')) 
  handles.sigma = 2; 
  handles.target = handles.CC.CI.target2s; end
if(get(handles.s3_radiobutton,'Value')) 
  handles.sigma = 3; 
  handles.target = handles.CC.CI.target3s; end
%% 
for i = 1:handles.CC.CI.nconf
  handles.limits(i,1) = handles.CC.CI.errors(i,handles.sigma,1);
  handles.limits(i,2) = handles.CC.CI.errors(i,handles.sigma,2);
end
%%
[row,col] = find(isnan(handles.limits));
if ~isempty(row)
  for k = 1:length(row)
    fpi = handles.CC.FLOAT.floatparindex(1,:);
    j = fpi(handles.CC.CI.cindex(row(k)));
    if col(k) == 1
      handles.limits(row(k),col(k)) = handles.CC.ANS.lowerlimit(j);
    end
    if col(k) == 2 
      handles.limits(row(k),col(k)) = handles.CC.ANS.upperlimit(j);
    end
  end
end
set(handles.limits_listbox,'String',num2str(handles.limits));
%%
cla(handles.axes22);
handles.plot9 = plot(handles.axes22,handles.CC.CI.bestr, ...
  handles.CC.CI.delta, handles.CC.CI.bestr, ...
  handles.CC.CI.matrix_1(13,:));
handles.plot9(1).LineStyle = '-';
handles.plot9(1).Color = 'k';
handles.plot9(1).LineWidth = 2;
handles.plot9(2).LineStyle = '-';
handles.plot9(2).Color = 'r';
handles.plot9(2).LineWidth = 2;
drawnow;
% Update handles structure
guidata(hObject, handles);

% --- Executes on button press in s2_radiobutton.
function s2_radiobutton_Callback(hObject, ~, handles)
% hObjecthandle to s2_radiobutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handlesstructure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of s2_radiobutton
%%
if(get(handles.s1_radiobutton,'Value'))  
  handles.sigma = 1; 
  handles.target = handles.CC.CI.target1s;
end
if(get(handles.s2_radiobutton,'Value')) 
  handles.sigma = 2; 
  handles.target = handles.CC.CI.target2s; end
if(get(handles.s3_radiobutton,'Value')) 
  handles.sigma = 3; 
  handles.target = handles.CC.CI.target3s; end
for i = 1:handles.CC.CI.nconf
  handles.limits(i,1) = handles.CC.CI.errors(i,handles.sigma,1);
  handles.limits(i,2) = handles.CC.CI.errors(i,handles.sigma,2);
end
%%
[row,col] = find(isnan(handles.limits));
if ~isempty(row)
  for k = 1:length(row)
    fpi = handles.CC.FLOAT.floatparindex(1,:);
    j = fpi(handles.CC.CI.cindex(row(k)));
    if col(k) == 1
      handles.limits(row(k),col(k)) = handles.CC.ANS.lowerlimit(j);
    end
    if col(k) == 2 
      handles.limits(row(k),col(k)) = handles.CC.ANS.upperlimit(j);
    end
  end
end
set(handles.limits_listbox,'String',num2str(handles.limits));
%% 
cla(handles.axes22);
handles.plot9 = plot(handles.axes22,handles.CC.CI.bestr, ...
  handles.CC.CI.delta, handles.CC.CI.bestr, ...
  handles.CC.CI.matrix_1(13,:));
handles.plot9(1).LineStyle = '-';
handles.plot9(1).Color = 'k';
handles.plot9(1).LineWidth = 2;
handles.plot9(2).LineStyle = '-';
handles.plot9(2).Color = 'r';
handles.plot9(2).LineWidth = 2;
drawnow;
% Update handles structure
guidata(hObject, handles);

% --- Executes on button press in s3_radiobutton.
function s3_radiobutton_Callback(hObject, ~, handles)
% hObjecthandle to s3_radiobutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handlesstructure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of s3_radiobutton
%%
if(get(handles.s1_radiobutton,'Value'))  
  handles.sigma = 1; 
  handles.target = handles.CC.CI.target1s;
end
if(get(handles.s2_radiobutton,'Value')) 
  handles.sigma = 2; 
  handles.target = handles.CC.CI.target2s; end
if(get(handles.s3_radiobutton,'Value')) 
  handles.sigma = 3; 
  handles.target = handles.CC.CI.target3s; end
%% 
for i = 1:handles.CC.CI.nconf
  handles.limits(i,1) = handles.CC.CI.errors(i,handles.sigma,1);
  handles.limits(i,2) = handles.CC.CI.errors(i,handles.sigma,2);
end
%%
[row,col] = find(isnan(handles.limits));
if ~isempty(row)
  for k = 1:length(row)
    fpi = handles.CC.FLOAT.floatparindex(1,:);
    j = fpi(handles.CC.CI.cindex(row(k)));
    if col(k) == 1
      handles.limits(row(k),col(k)) = handles.CC.ANS.lowerlimit(j);
    end
    if col(k) == 2 
      handles.limits(row(k),col(k)) = handles.CC.ANS.upperlimit(j);
    end
  end
end
set(handles.limits_listbox,'String',num2str(handles.limits));
%% 
cla(handles.axes22);
handles.plot9 = plot(handles.axes22,handles.CC.CI.bestr, ...
  handles.CC.CI.delta, handles.CC.CI.bestr, ...
  handles.CC.CI.matrix_1(13,:));
handles.plot9(1).LineStyle = '-';
handles.plot9(1).Color = 'k';
handles.plot9(1).LineWidth = 2;
handles.plot9(2).LineStyle = '-';
handles.plot9(2).Color = 'r';
handles.plot9(2).LineWidth = 2;
drawnow;
% Update handles structure
guidata(hObject, handles);
