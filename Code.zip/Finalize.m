function [ handles ] = Finalize( functionhandle, handles )
% Revised 07/28/2015
%% Set Text Strings
set(handles.nfloat_text,'String',num2str(handles.FLOAT.nfloat));
set(handles.fit_chisquared_text,'String', ...
  num2str(handles.DATA.totalchisquared));
set(handles.r_text,'String',num2str(handles.HOLD.mean));
set(handles.s_text,'String',num2str(handles.HOLD.width));
%% Copy all parameters to PARAM
handles.PARAM.ng = get(handles.g_1_checkbox,'Value') + ...
  get(handles.g_2_checkbox,'Value')+get(handles.g_3_checkbox,'Value') ...
  +get(handles.g_4_checkbox,'Value')+get(handles.g_5_checkbox,'Value')...
  +get(handles.g_6_checkbox,'Value')+get(handles.g_7_checkbox,'Value')...
  +get(handles.g_8_checkbox,'Value'); 
[handles.PARAM, handles.DISTRIBUTION] = copy_param(handles.PARAM, ....
    handles.ANS, handles.ANS.nparam, handles.ANS.namelengths); 
%% Generate Background and FFT's
rexp = 10^handles.PARAM.lambda;
t = handles.DATA.deer_t0 - 1.e-09*handles.PARAM.time_shift;
handles.DATA.back = (handles.HOLD.bv).* ...
  exp(-abs((rexp*t)).^(handles.PARAM.dimension/3.));
handles.DATA.corr1 = handles.DATA.deer_r./handles.DATA.back;
handles.DATA.corr2 = handles.DATA.yfit./handles.DATA.back;
handles.DATA.back = handles.PARAM.scale*(1. - ...
  handles.PARAM.depth)*handles.DATA.back;
f1 = handles.DATA.corr1 - (1.-handles.PARAM.depth);
f2 = handles.DATA.corr2 - (1.-handles.PARAM.depth);
% 06/26/2014 deer_t replaced with deer_t0
[ handles.DATA.ww1, handles.DATA.ss1 ] = myfft(handles.DATA.deer_t0,f1);
[ handles.DATA.ww2, handles.DATA.ss2 ] = myfft(handles.DATA.deer_t0,f2);

%% Plot Section
% Plot final fits
%--------------------------------------------------------------------------
try
  delete(handles.axes3);
  set(handles.cursor,'Enable','off');
catch
end
xplot = handles.DATA.deer_t0*1.e06;
dx = handles.DATA.dx*1.e09;
xlo = xplot(1) - 5.e-03*dx;
xhi = xplot(handles.DATA.nfit) + 5e-03*dx;
%
handles.axes4 = axes('Parent',handles.figureA, ...
  'Position',[0.775 0.70 0.175 0.2]);
box(handles.axes4,'on');
hold(handles.axes4,'all');
% Create plot
plot(handles.HOLD.r,handles.HOLD.p,'Parent',handles.axes4, ...
  'LineWidth',2,'Color',[0 0 0.75]);
% Create xlabel
xlabel({'distance (�)'},'Parent',handles.axes4,'FontSize',8);
%--------------------------------------------------------------------------
% Calculate statistics for distance distributions
%--------------------------------------------------------------------------
[~,imax] = max(handles.HOLD.p);
rmax = handles.HOLD.r(imax);
q1 = horzcat('$<R>= ',num2str(handles.HOLD.mean,'%5.1f'),'$\AA');
q2 = horzcat('$R_{max}= ',num2str(rmax,'%5.1f'),'$\AA');
q3 = horzcat('$\sigma= ',num2str(handles.HOLD.width,'%5.1f'),'$\AA');
p1 = horzcat('<R>= ',num2str(handles.HOLD.mean,'%5.1f'),'�');
p2 = horzcat('Rmax= ',num2str(rmax,'%5.1f'),'�');
p3 = horzcat('width= ',num2str(handles.HOLD.width,'%5.1f'),'�');
fprintf('%s \n','Statistics for Probability Distribution');
fprintf('%s \n',p1);
fprintf('%s \n',p2);
fprintf('%s \n',p3); 
% Create title
title({'distribution'},'Parent',handles.axes4,'Units','normalized',...
  'FontSize',10,'Position',[0.5 0.85]);
text(0.4,0.78,q1,'Parent',handles.axes4,'Units','normalized',...
  'FontSize',8,'Color',[0 0 0],'Interpreter','latex');
text(0.4,0.65,q2,'Parent',handles.axes4,'Units','normalized',...
  'FontSize',8,'Color',[0 0 0],'Interpreter','latex');
text(0.4,0.52,q3,'Parent',handles.axes4,'Units','normalized',...
  'FontSize',8,'Color',[0 0 0],'Interpreter','latex');
%
handles.axes6 = axes('Parent',handles.figureA, ...
  'Position',[0.325 0.55 0.375 0.35]);
plot6 = plot(xplot,handles.DATA.deer_r, ...
  xplot,handles.DATA.yfit, ...
  xplot,handles.DATA.back,'Parent',handles.axes6);
set(plot6(1),'MarkerSize',5,'Marker','.','LineStyle','none', ...
  'Color',[0 0 0]);
set(plot6(2),'LineWidth',2,'Color',[1 0 0]);
set(plot6(3),'LineWidth',1,'Color',[0 0.4 0]);
axis(handles.axes6,[xplot(1)*2 ...
  xplot(handles.DATA.nfit)*1.05  ...
  0.95*handles.DATA.deer_r(handles.DATA.nfit)  1.05]);
q = strcat('$\chi_{\nu}^2 = ',num2str(handles.DATA.chisquared), ...
  '\;\;iter.= ',num2str(handles.iter),'$');
text(0.01,0.05,q,'Parent',handles.axes6,'Units','normalized', ...
  'FontSize',12,'Interpreter','latex');
kg = 1;
if(handles.PARAM.ng > 0) 
  for kg = 1:handles.PARAM.ng
    q = strcat('$<R> =',num2str(handles.PARAM.r0(kg),'%6.2f'), ...
      '$\AA  $\;\sigma =',num2str(handles.PARAM.width(kg),'%6.2f'),...
      '$\AA $\;f = ',num2str(100*handles.HOLD.normamp(kg),'%4.0f'),'$\%');
    text(0.32,1.0-kg*0.07,q,'Units','normalized', ...
      'FontSize',8,'Color',[0 0 0.75],'Interpreter','latex', ...
      'Parent',handles.axes6);
  end 
end 
q= horzcat('Mod. Depth = ',num2str(handles.PARAM.depth,'%6.3f'));
text(0.32,1.0-(kg+1)*0.07,q,'Units','normalized','FontSize',8, ...
  'Color',[1 0 0],'Parent',handles.axes6,'Interpreter','latex'); 
if get(handles.exponential_checkbox,'Value')
  q= horzcat('$\lambda $= ',num2str(handles.PARAM.lambda,'%6.4f'), ...
    '  (dim = ',num2str(handles.PARAM.dimension,'%2.1f'),')');
  text(0.32,1.0-(kg+2)*0.07,q,'Units','normalized','FontSize',8, ...
    'Color',[0 0.4 0],'Parent',handles.axes6,'Interpreter','latex');
  % concX is display only concentration
  concX = (10^handles.PARAM.lambda)*1.0e-03/handles.PARAM.depth;
  q= horzcat('effective','$\;[\;\;]$ = ',num2str(concX,'%6.1f'),' $\mu M \;\;\;\;$');
  text(0.32,1.0-(kg+3)*0.07,q,'Units','normalized','FontSize',8, ...
    'Color',[0 0.4 0],'Parent',handles.axes6,'Interpreter','latex');
elseif get(handles.calculated_checkbox,'Value') 
  q= horzcat('$[\;\;] = ',num2str(handles.PARAM.concentration,'%6.1f'), ...
    ' \mu M \;\;\;\; \rho = ',num2str(handles.PARAM.rho,'%5.1f'),'$', ...
    '\AA');
  text(0.32,1.0-(kg+3)*0.07,q,'Units','normalized','FontSize',8, ...
    'Color',[0 0.4 0],'Parent',handles.axes6,'Interpreter','latex'); 
end
q= horzcat('Backgr. Mod. Depth = ', ...
  num2str(handles.PARAM.background_depth,'%6.3f'));
text(0.32,1.0-(kg+4)*0.07,q,'Units','normalized','FontSize',8, ...
  'Color',[0 0.4 0],'Parent',handles.axes6,'Interpreter','latex');
q= horzcat('Scale= ',num2str(handles.PARAM.scale,' %6.4f '), ...
  ' time shift= ',num2str(handles.PARAM.time_shift,'%6.4f '),' ns');
text(0.32,1.0-(kg+5)*0.07,q,'Units','normalized','FontSize',8, ...
  'Color',[0 0 0],'Parent',handles.axes6,'Interpreter','latex');
q= horzcat(num2str(handles.DATA.nfit,'%4.0f'),' points  ', ...
  num2str(handles.FLOAT.nfloat,'%3.0f'),' parameters');
text(0.32,1.0-(kg+6)*0.07,q,'Units','normalized','FontSize',8, ...
  'Color',[0 0 0],'Parent',handles.axes6,'Interpreter','latex');
q= horzcat(datestr(now),' Version 7');
text(0.32,1.0-(kg+7)*0.07,q,'Units','normalized','FontSize',8, ...
  'Color',[0 0 0],'Parent',handles.axes6,'Interpreter','latex');

xlabel({'Time (\mus)'},'Parent',handles.axes6);
%
handles.axes8 = axes('Parent',handles.figureA, ...
  'Position',[0.325 0.1 0.375 0.35]);
plot8 = plot(xplot,handles.DATA.corr1,...
  xplot,handles.DATA.corr2,'Parent',handles.axes8);
set(plot8(1),'MarkerSize',5,'Marker','.','LineStyle', ...
  'none','Color',[0 0 0]);
set(plot8(2),'LineWidth',2,'Color',[1 0 0]);
axis(handles.axes8,[xplot(1)*2 ...
  xplot(handles.DATA.nfit)*1.05  ...
  0.95*min([min(handles.DATA.corr1) min(handles.DATA.corr2)]) ...
  1.05*max([max(handles.DATA.corr1) max(handles.DATA.corr2)])]);
if isempty( find(isnan(handles.DATA.ss1),1) ) 
  if isempty( find(isnan(handles.DATA.ss2),1) ) 
    handles.axes7 = axes('Parent',handles.figureA,'Position', ...
      [0.5 0.3 0.18 0.13],'Visible','off');
    plot7 = plot(handles.DATA.ww1,real(handles.DATA.ss1), ...
      handles.DATA.ww2,real(handles.DATA.ss2), ...
      'Parent',handles.axes7);
    set(plot7(1),'LineWidth',2,'Color',[0 0 0]);
    set(plot7(2),'LineWidth',2,'Color',[1 0 0]);
    axis(handles.axes7, [ -3e7 3e7 min([min(real(handles.DATA.ss1)) ...
      min(real(handles.DATA.ss2))]) ...
      max([max(real(handles.DATA.ss1)) ...
      max(real(handles.DATA.ss2))]) ],'off' );
  end 
end
handles.axes5 = axes('Parent',handles.figureA, ...
  'Position',[0.775 0.10 0.175 0.500]);

y1 = -2.*max(abs(handles.DATA.residuals));
y2 = -y1;
box(handles.axes5,'on');
hold(handles.axes5,'all');
plot(xplot,handles.DATA.residuals, ...
  'Parent',handles.axes5,'MarkerSize',5,'Marker','.', ...
  'LineStyle','none','Color',[0 0 0]);
axis(handles.axes5,[xlo xhi y1 y2]);
% Calculate AICc and BIC values - added 03/16/2015
% for specific equations see Burnham and Anderson: "Model Selection and
% Multimodel Inference" 2002 p. 63 and p.
ssr = handles.DATA.ssr;
nn = handles.DATA.nfit;
mm = handles.FLOAT.nfloat;

handles.DATA.AICc = nn*log(ssr/nn) + 2*(mm + 1)*(nn/(nn-mm-2)) ;
handles.DATA.BIC = nn*log(ssr/nn) + (mm + 1)*log(nn) ;
q= horzcat('$Noise = ',num2str(handles.DATA.rnoise,'%8.5f'),'$');
text(0.01,0.95,q,'Units','normalized', ...
  'FontSize',12,'Color',[0 0 0],'Parent',handles.axes5, ...
  'Interpreter','latex');
q= horzcat('$ AICc = ',num2str(handles.DATA.AICc,'%10.1f'),'$');
text(0.01,0.10,q,'Units','normalized', ...
  'FontSize',12,'Color',[0 0 0],'Parent',handles.axes5, ...
  'Interpreter','latex');
q= horzcat('$ BIC = ',num2str(handles.DATA.BIC,'%10.1f'),'$');
text(0.01,0.03,q,'Units','normalized', ...
  'FontSize',12,'Color',[0 0 0],'Parent',handles.axes5, ...
  'Interpreter','latex');
%
if get(handles.write_plot_checkbox,'Value')
  
  [t1,t2,~] = fileparts(handles.answerfile);
  
  if isdir(t1)
    t1c = {t1};
    % 6/13/EJH - do not ask about overwriting existing directory
    % b = question_gui_DD( t1c );
    b = 'Yes'; 
    if strcmp(b,'Yes')
      try
        rmdir(t1,'s');
        mkdir(t1);
      catch
        1;
      end 
    else
      2;
    end 
  else
    mkdir(t1);
  end 
  
  q = [t1 handles.sep t2 '.pdf'];
  %   saveas(handles.figureA, q);
  if verLessThan('matlab','9.0')
      print(handles.figureA,q,'-dpdf');
  else
      print(handles.figureA,q,'-dpdf','-fillpage');
  end
end 
%% determine number of maxima in P(R)
handles.mode_number = 0;
try
  temp = findpeaks(handles.HOLD.p,handles.HOLD.r);
  handles.mode_number = length(temp);
  set(handles.m_text,'String',num2str(handles.mode_number));
catch
  set(handles.m_text,'String',' ');
end
%% Store probability distribution for confidence bands
% 9/28/2015 comment out - This was my initial attempt to generate
% confidence bands from confidence interval calculations
handles.CI.bestr = handles.HOLD.r;
handles.CI.bestp = handles.HOLD.p;
%% 9/28/2015 - Use covariance matrix
% to estimate uncertainties
handles.CI.errors = NaN(handles.FLOAT.nfloat,3,2);
[derivatives,~,~] = numderiv(functionhandle, handles);
curvature = derivatives'*derivatives;
handles.covariance = (handles.DATA.rnoise^2)*inv(curvature);
% sprintf([strrep(mat2str(handles.covariance),';','\n ')]);
handles.CI.uncertainty = sqrt(diag(handles.covariance))';
% to generate confidence bands
handles = confidence_bands_A( handles );
q = [t1 handles.sep 'A.pdf'];
saveas(handles.figureCBa, q);
% set(handles.figureCBa,'Visible','off');
%% check if auto save statistics
if handles.save_statistics_checkbox.Value
  [handles] = save_statistics_function(handles);
end
