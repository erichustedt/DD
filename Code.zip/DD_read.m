function [ DATA ] = DD_read( file )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
%%
try
  temp = findobj(0,'type','figure');
  delete(temp(2:end));
catch
end 
%%
DATA.deer_t = [ ];
DATA.z1 = [ ];
DATA.dx = 0;
DATA.VB = [ ];
DATA.npts = 0;
tempfile = char(file);
fprintf('\n %s %s \n  ', 'FILE: ', tempfile );
test1 = exist([tempfile '.DTA'],'file');
test2 = exist([tempfile '.DSC'],'file');
if test1 == 2 && test2 == 2  
  [DATA.deer_t,DATA.z1,DATA.dx] =...
    read_elexsys(tempfile);
else
  test3 = exist([tempfile '.DAT'],'file');
  test4 = exist([tempfile '.dat'],'file');
  test5 = exist([tempfile '.ASC'],'file');
  test6 = exist([tempfile '.asc'],'file');
  if test3 == 2 || test4 == 2 || test5 == 2 || test6 == 2 
    [DATA.deer_t,DATA.z1,DATA.dx] = read_DATA(tempfile);
  else
    disp('DATAFILE DOES NOT EXIST');
    return;
  end 
end
%
fprintf('\n %s %s %s \n  ', 'FILE: ', tempfile, ' read.' );
fprintf(' \n ');
%
DATA.deer_t = DATA.deer_t*1.e-09;
DATA.dx = DATA.dx*1.e-09;
DATA.npts = length(DATA.deer_t);
DATA.name = file;
%
end

