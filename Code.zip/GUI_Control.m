function GUI_Control(hFig,state)
% 08/07/2016 - EJH - java function to suspend/resume input to GUI
% Based loosely on:  
%    http://UndocumentedMatlab.com/blog/blurred-matlab-figure-window
%% Set default input parameters values
if nargin < 1,  hFig = gcf;    end
if nargin < 2,  state = 'on';  end
%%
% Check valid figure handle
if ~ishghandle(hFig)
    error('first input must be a valid GUI handle');
end
% Check valid state values
if ischar(state)
    if ~any(strcmpi(state,{'on','off'}))
        error([mfilename ...
             ' requires a STATE value of ''on'', ''off'', true or false']);
    end 
else
    error([mfilename ...
     ' requires a character STATE value of ''on'' or  ''off'' ']);
end  
%%
set( findall(hFig, '-property', 'Enable'), 'Enable', state)
end

