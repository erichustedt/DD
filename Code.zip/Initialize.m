function [ handles ] = Initialize( handles )
% Revised 05/20/2016
%% check to see if data has been read and processed
if handles.status < 1 
  return
end
%%
try close(handles.figureCBa);catch;end
try close(handles.figureCBb);catch;end
%% setup
%% store initial values
handles.ANS.initialvalues = handles.ANS.values;
%% setup float parameters and indices
handles = find_float_values(handles);
handles.ndegreefreedom = handles.DATA.nfit - handles.FLOAT.nfloat;
handles.totalndegreefreedom = sum(handles.ndegreefreedom);
%% Set linked parameters 
for k = 1:handles.FLOAT.nlinked
  handles.ANS.values(handles.FLOAT.linkedindex(k)) =...
    handles.ANS.values(handles.FLOAT.linkedtoindex(1,k) );
end
%% Copy all parameters to PARAM
handles.PARAM.ng = get(handles.g_1_checkbox,'Value') + ...
 get(handles.g_2_checkbox,'Value') + get(handles.g_3_checkbox,'Value') ...
 + get(handles.g_4_checkbox,'Value') + get(handles.g_5_checkbox,'Value')...
 + get(handles.g_6_checkbox,'Value')+ get(handles.g_7_checkbox,'Value')...
 + get(handles.g_8_checkbox,'Value'); 
[handles.PARAM,handles.DISTRIBUTION] = copy_param(handles.PARAM, ....
   handles.ANS, handles.ANS.nparam, handles.ANS.namelengths);
%% initial calculation
[handles.DATA,handles.PARAM,handles.HOLD,handles.PARAM0] = ...
  deer_first(handles.DATA,handles.PARAM);  
handles.DATA.yfit0 = handles.DATA.yfit;
handles = determine_chi2(handles); 
fprintf('%s %8.4f \n  ', ' reduced chisquared= ', handles.DATA.totalchisquared );
handles.DATA.initialchisquared = handles.DATA.totalchisquared;
handles.iter = 0;
%% plot
try
  delete(handles.axes3);
catch
end
try
  delete(handles.axes4);
catch
end
try
  delete(handles.axes5);
catch
end
try
  delete(handles.axes6);
catch
end
try
  delete(handles.axes7);
catch
end
try
  delete(handles.axes8);
catch
end
rexp = 10^handles.PARAM.lambda;
% 06/26/2014 deer_t replaced with deer_t0
handles.DATA.back = (handles.HOLD.bv).* ...
  exp(-abs((rexp*handles.DATA.deer_t0)).^ ...
  (handles.PARAM.dimension/3.));
handles.DATA.back = handles.PARAM.scale*(1. - ...
  handles.PARAM.depth)*handles.DATA.back;
handles.axes3 = axes('Parent',handles.figureA,...
  'Position',[0.325 0.15 0.625 0.75]);
plot3 = plot(handles.DATA.deer_t0,handles.DATA.deer_r,...
  handles.DATA.deer_t0,handles.DATA.yfit0,handles.DATA.deer_t0, ...
  handles.DATA.back,'Parent',handles.axes3);
axis(handles.axes3,[handles.DATA.deer_t0(1)*2 ...
  handles.DATA.deer_t0(handles.DATA.nfit)*1.05 ...
  0.95*handles.DATA.deer_r(handles.DATA.nfit)  1.05]);
set(plot3(1),'MarkerSize',5,'Marker','.','LineStyle','none',...
  'Color',[0 0 0]);
set(plot3(2),'LineWidth',2,'Color',[1 0 0]);
set(plot3(3),'LineWidth',2,'Color',[0 0.5 0]);
q = strcat('Initial $\chi_{\nu}^2 = ',num2str(handles.DATA.totalchisquared), ...
    '\;\;iter.= ',num2str(handles.iter),'$');
text(0.01,0.05,q,'Parent',handles.axes3,'Units','normalized', ...
    'FontSize',12,'Interpreter','latex');
xlabel({'Time (\mus)'},'Parent',handles.axes3);
% now set all x ticks to microseconds
xt = arrayfun(@num2str,get(handles.axes3,'xtick')*1e6,'un',0);
set(handles.axes3,'xticklabel',xt);
%
handles.hax = ...
  axes('Parent',handles.figureA,'Position',[0.55, 0.55, 0.35, 0.35]);
plot(handles.HOLD.r,handles.HOLD.p,'Parent',handles.hax);
set(handles.hax,'visible','off');
%
set(handles.nfloat_text,'String',num2str(handles.FLOAT.nfloat));
set(handles.fit_chisquared_text,'String', ...
    num2str(handles.DATA.totalchisquared));
set(handles.r_text,'String',num2str(handles.HOLD.mean));
set(handles.s_text,'String',num2str(handles.HOLD.width));
%
if get(handles.filename_update_checkbox,'Value')
  [t1,t2,~] = fileparts(handles.DATA.name);
  if get(handles.exponential_checkbox,'Value')
    t3 = '_e';
  elseif get(handles.calculated_checkbox,'Value')
    t3 = '_r';
  else
    t3 = '';
  end
  if handles.PARAM.shape == 1
    shape = 'G';
  elseif handles.PARAM.shape == 5
    shape = 'R';
  elseif handles.PARAM.shape == 8
    shape = 'B';
  elseif handles.PARAM.shape == 9
    shape = 'Q';
  elseif handles.PARAM.shape == 10
    shape = 'D';
  end
  t4 = [handles.sep t2 '_' num2str(handles.PARAM.ng) shape t3] ;
  %
  handles.answerfile = [t1 handles.sep t2 t4 t4];
  set(handles.answerfile_text,'String',handles.answerfile);
end
%  
try
  delete(handles.fAtitle);
catch
end 
handles.fAtitle = annotation(handles.figureA,'textbox',...
  [0.325 0.925 0.35 0.075],'String',...
  handles.answerfile,'HorizontalAlignment','center',...
  'FontSize',10,'FitBoxToText','off','LineStyle','none',...
  'Interpreter','none','Color',[0 0 0.5]);

%
[ handles ] = update_GUI_values( handles );
%% determine number of maxima in P(R)
handles.mode_number = 0;
try
  temp = findpeaks(handles.HOLD.p,handles.HOLD.r);
  handles.mode_number = length(temp);
  set(handles.m_text,'String',num2str(handles.mode_number));
catch
  set(handles.m_text,'String',' ');
end
%% ADD in data cursor
text1 = [num2str(handles.DATA.nfit),' out of ', ...
    num2str(handles.DATA.npts),' points'];
text2 = ['\Delta{\itt} = ',num2str(handles.DATA.dx)];
text(0.75,0.96,text1,'Units','normalized','Parent',handles.axes3);
text(0.75,0.92,text2,'Units','normalized','Parent',handles.axes3);  
handles.cursor = datacursormode(handles.figureA);
set(handles.cursor,'Enable','on','UpdateFcn',{@myupdatefcn, handles.DATA.first,...
  handles.DATA.npts, handles.DATA.deer_t0},'DisplayStyle','datatip', ...
  'SnapToDataVertex','on');
%% 
handles.status = 2;
end

