function [ handles ] = output_DD( handles )
%   Function to output results from DD
%   Heavily modified to use ActiveX capabilities of Matlab starting with
%   2014(?) versions of Matlab. New version is much faster outputting to
%   Excel.
%   06/21/2016
if(handles.OPTIONS.OUTPUT.logical.output2Excel)
    %% KILL any existing EXCEL processe
    killExcel
    %%
    try
        esheet = 0;
        ExcelTrue = actxserver ('Excel.Application');
        set(ExcelTrue, 'Visible', 0);
        %% Check Office Version
        %  For Office 2010 or earlier 3 sheets are opened by default, for
        %  later versions only 1 sheet is opened
        office_version = ExcelTrue.Version;
        if office_version >= 15
            open_sheet = 1;
        else
            open_sheet = 3;
        end  
        %
        WorkBook = invoke(ExcelTrue.Workbooks, 'Add'); % Create a new workbook
        Sheets = ExcelTrue.ActiveWorkbook.Sheets;
        %%
        if(handles.OPTIONS.OUTPUT.logical.outputparam)
            %
            esheet = esheet + 1;
            if esheet > open_sheet
                Sheets.Add([], ActiveSheet); end 
            %
            Sheet = get(Sheets, 'Item', esheet);
            invoke(Sheet, 'Activate');
            ActiveSheet = ExcelTrue.Activesheet;  % Make sheet active
            ActiveSheet.Name = strcat('PARAMETERS(1)');
            disp(ActiveSheet.Name);
            %
            q = {handles.DATA.name 'names' 'values' 'fixed' 'experiment' ...
                'links' 'lowerlimit' 'upperlimit' 'confidence' 'start' ...
                'end' 'increment' 'new values'};
            set(get(ActiveSheet,'Range', ExcelRange('A1',q)), 'Value', q);
            %
            q = (1:1:handles.ANS.nparam)';
            set(get(ActiveSheet,'Range', ExcelRange('A2',q)), 'Value', q);
            %
            q = {'chisquared =';'iterations =';'Date and Time ='; ...
                'Total chisquared'};
            set(get(ActiveSheet,'Range', ExcelRange('A55',q)), 'Value', q);
            %
            q = handles.ANS.names;
            set(get(ActiveSheet,'Range', ExcelRange('B2',q)), 'Value', q);
            %
            q = handles.ANS.initialvalues;
            set(get(ActiveSheet,'Range', ExcelRange('C2',q)), 'Value', q);
            %
            q = handles.DATA.initialchisquared;
            set(get(ActiveSheet,'Range', ExcelRange('C55',q)), 'Value', q);
            %
            q = {'chisquared =';'iterations =';'Date and Time ='; ...
                'Total chisquared'};
            set(get(ActiveSheet,'Range', ExcelRange('A55',q)), 'Value', q);
            %
            q = handles.ANS.fixed;
            set(get(ActiveSheet,'Range', ExcelRange('D2',q)), 'Value', q);
            %
            q = handles.ANS.experiment;
            set(get(ActiveSheet,'Range', ExcelRange('E2',q)), 'Value', q);
            %
            q = handles.ANS.links;
            set(get(ActiveSheet,'Range', ExcelRange('F2',q)), 'Value', q);
            %
            q = handles.ANS.lowerlimit;
            set(get(ActiveSheet,'Range', ExcelRange('G2',q)), 'Value', q);
            %
            q = handles.ANS.upperlimit;
            set(get(ActiveSheet,'Range', ExcelRange('H2',q)), 'Value', q);
            %
            q = handles.ANS.confidence;
            set(get(ActiveSheet,'Range', ExcelRange('I2',q)), 'Value', q);
            %
            q = handles.ANS.start;
            set(get(ActiveSheet,'Range', ExcelRange('J2',q)), 'Value', q);
            %
            q = handles.ANS.end;
            set(get(ActiveSheet,'Range', ExcelRange('K2',q)), 'Value', q);
            %
            q = handles.ANS.increment;
            set(get(ActiveSheet,'Range', ExcelRange('L2',q)), 'Value', q);
            %
            q = handles.ANS.values;
            set(get(ActiveSheet,'Range', ExcelRange('M2',q)), 'Value', q);
            %
            q = handles.DATA.totalchisquared;
            set(get(ActiveSheet,'Range', ExcelRange('M55',q)), 'Value', q);
            %
            q = handles.iter;
            set(get(ActiveSheet,'Range', ExcelRange('M56',q)), 'Value', q);
            %
            q = {datestr(clock)};
            set(get(ActiveSheet,'Range', ExcelRange('M57',q)), 'Value', q);
            %
            q = handles.DATA.totalchisquared;
            set(get(ActiveSheet,'Range', ExcelRange('M58',q)), 'Value', q);
            %
        end 
        %%
        esheet = esheet + 1;
        if esheet > open_sheet
            Sheets.Add([], ActiveSheet); end 
        %
        Sheet = get(Sheets, 'Item', esheet);
        invoke(Sheet, 'Activate');
        ActiveSheet = ExcelTrue.Activesheet;  % Make sheet active
        ActiveSheet.Name = strcat('OPTIONS');
        disp(ActiveSheet.Name);
        %
        NAMES_1 = fieldnames(handles.OPTIONS);
        l = 0;
        listA = cell(1,1);
        listB = cell(1,1);
        for i = 1:length(NAMES_1)
            tabname = char(NAMES_1(i));
            NAMES_2 = fieldnames(handles.OPTIONS.(tabname));
            for j = 1:length(NAMES_2)
                subname = char(NAMES_2(j));
                NAMES_3 = fieldnames(handles.OPTIONS.(tabname).(subname));
                for k = 1:length(NAMES_3)
                    l = l + 1;
                    rowname = char(NAMES_3(k));
                    listA(l) = NAMES_3(k);
                    listB(l) = num2cell(single ...
                        (handles.OPTIONS.(tabname).(subname).(rowname)));
                end 
            end 
        end 
        set(get(ActiveSheet,'Range', ExcelRange('A1',listA')), 'Value', ...
            listA');
        set(get(ActiveSheet,'Range', ExcelRange('B1',listB')), 'Value', ...
            listB');
        %%
        if(handles.OPTIONS.OUTPUT.logical.outputdistribution) 
            esheet = esheet + 1;
            if esheet > open_sheet
                Sheets.Add([], ActiveSheet); end 
            %
            Sheet = get(Sheets, 'Item', esheet);
            invoke(Sheet, 'Activate');
            ActiveSheet = ExcelTrue.Activesheet;  % Make sheet active
            ActiveSheet.Name = strcat('DISTRIBUTION(1)');
            disp(ActiveSheet.Name);
            %
            q = {'R' 'PROBABILITY' '95% Lower' '95% upper' 'delta'};
            set(get(ActiveSheet,'Range', ExcelRange('A1',q)), 'Value', q);
            %
            q = horzcat(handles.HOLD.r', handles.HOLD.p', ...
                handles.CI.lower', handles.CI.upper', handles.CI.delta');
            set(get(ActiveSheet,'Range', ExcelRange('A2',q)), 'Value', q);
            %
            q = {'mean =';'width =';'# of Gaussians ='};
            set(get(ActiveSheet,'Range', ExcelRange('F1',q)), 'Value', q);
            %
            q = [handles.HOLD.mean handles.HOLD.width handles.PARAM.ng]';
            set(get(ActiveSheet,'Range', ExcelRange('G1',q)), 'Value', q);
            %
        end 
        %%
        if(handles.OPTIONS.OUTPUT.logical.outputfit)
            esheet = esheet + 1;
            if esheet > open_sheet
                Sheets.Add([], ActiveSheet); end 
            %
            Sheet = get(Sheets, 'Item', esheet);
            invoke(Sheet, 'Activate');
            ActiveSheet = ExcelTrue.Activesheet;  % Make sheet active
            ActiveSheet.Name = strcat('FIT(1)');
            disp(ActiveSheet.Name);
            %
            q = {'X' 'Data' 'Fit' 'Background' 'Residuals' 'Corr. Data' ...
                'Corr. Fit'};
            set(get(ActiveSheet,'Range', ExcelRange('A1',q)), 'Value', q);
            %
            q = horzcat(handles.DATA.deer_t0', ...
                handles.DATA.deer_r', handles.DATA.yfit', ...
                handles.DATA.back', handles.DATA.residuals', ...
                handles.DATA.corr1', handles.DATA.corr2' );
            set(get(ActiveSheet,'Range', ExcelRange('A2',q)), 'Value', q);
        end 
        %%
        esheet = esheet + 1;
        if esheet > open_sheet
            Sheets.Add([], ActiveSheet); end 
        %
        Sheet = get(Sheets, 'Item', esheet);
        invoke(Sheet, 'Activate');
        ActiveSheet = ExcelTrue.Activesheet;  % Make sheet active
        ActiveSheet.Name = strcat('DATA(1)');
        disp(ActiveSheet.Name);
        %
        q = {'Time' 'REAL' 'IMAG' 'Phased Real' 'Phased Imag' ...
            'Truncated Time' 'Truncated Real' 'Truncated Imag'};
        set(get(ActiveSheet,'Range', ExcelRange('A1',q)), 'Value', q);
        %
        q = horzcat(handles.DATA.deer_t',...
            real(handles.DATA.z1'), imag(handles.DATA.z1'), ...
            real(handles.DATA.z5'), imag(handles.DATA.z5') );
        set(get(ActiveSheet,'Range', ExcelRange('A2',q)), 'Value', q);
        %
        q = ...
            horzcat( ...
            handles.DATA.deer_t(handles.DATA.first:handles.DATA.last)',...
            real(handles.DATA.z4'), imag(handles.DATA.z4') );
        set(get(ActiveSheet,'Range', ExcelRange('F2',q)), 'Value', q);
        %
        %% Output all uncertainties to Excel file
        esheet = esheet + 1;
        if esheet > open_sheet
            Sheets.Add([], ActiveSheet); end 
        %
        Sheet = get(Sheets, 'Item', esheet);
        invoke(Sheet, 'Activate');
        ActiveSheet = ExcelTrue.Activesheet;  % Make sheet active
        ActiveSheet.Name = strcat('UNCERTAINTIES');
        disp(ActiveSheet.Name);
        q = {'Parameter' 'Value' '2 sigma Covar.'};
        set(get(ActiveSheet,'Range', ExcelRange('A1',q)), 'Value', q);
        %
        q = handles.FLOAT.floatnames;
        set(get(ActiveSheet,'Range', ExcelRange('A2',q)), 'Value', q);
        %
        q = handles.FLOAT.float';
        set(get(ActiveSheet,'Range', ExcelRange('B2',q)), 'Value', q);
        %
        q = 2*handles.CI.uncertainty';
        set(get(ActiveSheet,'Range', ExcelRange('C2',q)), 'Value', q);
        
        %% Output covariance matrix to Excel file
        esheet = esheet + 1;
        if esheet > open_sheet
            Sheets.Add([], ActiveSheet); end 
        %
        Sheet = get(Sheets, 'Item', esheet);
        invoke(Sheet, 'Activate');
        ActiveSheet = ExcelTrue.Activesheet;  % Make sheet active
        ActiveSheet.Name = strcat('COVARIANCE');
        disp(ActiveSheet.Name);
        q = handles.covariance;
        set(get(ActiveSheet,'Range', ExcelRange('A1',q)), 'Value', q);
        %%
        sheet = get(Sheets, 'Item', 1);
        invoke(sheet, 'Activate');
        ExcelTrue.displayalerts = false;
        WorkBook.SaveAs(handles.answerfile);
        DeleteEmptyExcelSheets(handles.answerfile);
        invoke(ExcelTrue, 'Quit');
        delete(ExcelTrue);
        %%
    catch
        ExcelTrue.displayalerts = false;
        invoke(ExcelTrue, 'Quit');
        delete(ExcelTrue);
        disp('error writing to Excel file')
        handles.OPTIONS.OUTPUT.logical.output2Excel = false;
        handles.OPTIONS.OUTPUT.logical.output2ASCII = true;
        handles.OPTIONS.OUTPUT.logical.output2MAT = true;
    end 
end 
% MAT output --------------------------------------------------------------
if(handles.OPTIONS.OUTPUT.logical.output2MAT) 
    
    matfile = strcat(handles.answerfile,'.mat');
    ANS = handles.ANS;
    DATA = handles.DATA;
    HOLD = handles.HOLD;
    iter = handles.iter;
    save(matfile,'ANS','DATA','HOLD','iter');
    clear ANS DATA HOLD iter;
    
end 
% % ASCII output ----------------------------------------------------------
if(handles.OPTIONS.OUTPUT.logical.output2ASCII)
    if(handles.OPTIONS.OUTPUT.logical.outputdistribution)
        
        outfile = strcat(handles.answerfile,...
            '_','distribution','.dat');
        fid = fopen(outfile,'w');
        fprintf('\n %s %s \n',outfile,'is open.');
        fprintf(fid,'%s \n', ...
            '    Dist.      Prob.      95% Lower  95% Upper  Delta');
        for n = 1:size(handles.HOLD.r,2)
            fprintf(fid,'\n %10.5f %10.5f %10.5f %10.5f %10.5f',...
                handles.HOLD.r(n), handles.HOLD.p(n), ...
                handles.CI.lower(n), handles.CI.upper(n), ...
                handles.CI.delta(n) );
        end 
        fclose(fid);
        
    end 
    
    if(handles.OPTIONS.OUTPUT.logical.outputparam)
        
        outfile = strcat(handles.answerfile,...
            '_','results','.dat');
        fid = fopen(outfile,'w');
        fprintf(' \n %s %s \n',outfile,'is open.');
        fprintf(fid,' %s \n',handles.answerfile);
        
        fprintf(fid,' %s \n \n',char(handles.DATA.name));
        fprintf(fid, ...
            ' %s \n', ...
            '      name                 value   fix link initial');
        for n = 1:handles.ANS.nparam
            fprintf(fid,'\n %2.0f %20s %10.5g %2.0f %2.0f %10.5g',...
                n, char(handles.ANS.names(n,:)), handles.ANS.values(n), ...
                handles.ANS.fixed(n), handles.ANS.links(n), ...
                handles.ANS.initialvalues(n) );
        end 
        fprintf(fid,' \n \n %s %12.5f \n','chisquared = ', ...
            handles.DATA.chisquared);
        
        fprintf(fid,' \n \n %s %12.5f \n','Initial Chisquared = ', ...
            handles.DATA.initialchisquared);
        fprintf(fid,' %s %3.0f \n','Iterations = ',handles.iter);
        fprintf(fid,' %s \n',datestr(clock));
        fprintf(fid,' %s %12.5f \n','Final Chisquared = ', ...
            handles.DATA.totalchisquared);
        fclose(fid);
        
    end 
    
    if(handles.OPTIONS.OUTPUT.logical.outputfit)
        
        outfile = strcat(handles.answerfile,...
            '_','fit','.dat');
        fid = fopen(outfile,'w');
        fprintf('\n %s %s \n',outfile,'is open.');
        fprintf(fid, ...
            '%s \n', ...
            '      Time         Data         Fit          Backgr.      Resid.');
        for n = 1:handles.DATA.nfit
            fprintf(fid, ...
                '\n %12.5g %12.5f %12.5f %12.5f %12.5f %12.5f %12.5f',...
                handles.DATA.deer_t0(n), ...
                handles.DATA.deer_r(n), handles.DATA.yfit(n), ...
                handles.DATA.back(n), handles.DATA.residuals(n), ...
                handles.DATA.corr1(n), handles.DATA.corr2(n) );
        end 
        fclose(fid);
        
    end 
end 
end

