function [y, HOLD, PARAM0] = deer_calc(HOLD, PARAM0, PARAM, DATA,...
                              quickversion)
% January 4th 2015 - EJH
% Revise because quickversion is not working properly, i.e. RECALCULATE ALL
% is performed too often particularly when time_shift is varied or when
% calculating confidence intervals
% See the exchange routine for the definition of the vectors BACK SHORT and
% DISTR. BACK0 SHORT0 and DISTR0 store values from the previous calculation
% If the parameters in these vectors do not change then do not need to
% repeat calculation governed by that set of variables. TIME0 is the time
% vector from the previous calculation. If TIME changes then entire
% calculation needs to be repeated.
[BACK0,SHORT0,DISTR0] = exchange(PARAM0);
[BACK,SHORT,DISTR] = exchange(PARAM);
TIME = DATA.deer_t0 - 1.e-09*PARAM.time_shift;    
% To force a recalculation of all parts of the DEER signal then set TIME0
% vector to zero.
if(~quickversion) 
  HOLD.TIME0 = 0;
end
    
if(~comp_vect(TIME,HOLD.TIME0))
    % disp('RECALCULATE ALL');
    HOLD = deer_back(TIME,HOLD,PARAM);
    HOLD = deer_short(TIME,HOLD,PARAM);
    HOLD = deer_prob(HOLD,PARAM);
    BACK0 = BACK;
    SHORT0 = SHORT;
    DISTR0 = DISTR;
end
%
if(~comp_vect(BACK,BACK0))
    % disp('RECALCULATE BACKGROUND');
    HOLD = deer_back(TIME,HOLD,PARAM); 
end
%
if(~comp_vect(SHORT,SHORT0))
    % disp('RECALCULATE SHORT DISTANCE KERNEL');
    HOLD = deer_short(TIME,HOLD,PARAM);
end
%
if(~comp_vect(DISTR,DISTR0))
    % disp('RECALCULATE DISTRIBUTION');
    HOLD = deer_prob(HOLD,PARAM); 
end
%
rexp = 10^PARAM.lambda;
y = (1. - PARAM.depth*(1.-...
    HOLD.v)).*HOLD.bv.*exp(-abs((rexp*TIME)).^(PARAM.dimension/3.));
it0 = find(TIME == 0);
y(it0) = 1.;
y = PARAM.scale*y;
PARAM0= PARAM;
HOLD.TIME0 = TIME;
return 
