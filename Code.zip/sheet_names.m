function [sn] = sheet_names(ET,Sh)
% 6/24/2016 EJH
% Function to return sheet names of an existing Excel Workboo
ic = Sh.Count;
sn = cell(1,6);
for k = 1:ic
  sn(k) = {ET.Worksheets.Item(k).Name};
end