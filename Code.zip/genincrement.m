% 12/15/2011
% EJH
function y = genincrement(gradient,curvature,nfloat,lambda,threshold)
    curvature_2 = curvature;
    for k = 1:nfloat; curvature_2(k,k)= (1. + lambda)*curvature_2(k,k); end
    [U,S,V] = svd(curvature_2);
    Ug = U'*gradient' ;
    % calculate parameter increments
    y= zeros(1,nfloat);
    for k= 1:nfloat  
        y(k) = 0; 
        for l = 1:nfloat 
           if(S(l,l) > threshold) 
                y(k) = y(k) + (V(k,l)/S(l,l))*Ug(l);
           end
        end
    end
return
    