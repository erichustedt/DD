function [ temp ] = set_initial_options_Tabbed
% 06/02/2015 This function generates a structure with an OPTIONS field that
% contains all the default initial values. The fields are structured so
% that the various OPTIONS can be edited in a GUI with TABBED Tables.
% 01/13/2018 fmincon (interior-point) and  globalsearch added. simulated 
% annealing removed.
% 02/09/2018 particleswarm added
%% OPTIONS for fmincon algorithm
temp.OPTIONS.IP.logical.interiorpoint = true;
temp.OPTIONS.IP.numeric.MaxIterations = Inf;
temp.OPTIONS.IP.numeric.MaxFunctionEvaluations = Inf;
temp.OPTIONS.IP.numeric.StepTolerance = 1.e-05;
%% OPTIONS for globalsearch algorithm
temp.OPTIONS.GS.logical.globalsearch = false;
temp.OPTIONS.GS.numeric.MaxIterations = 1000;
temp.OPTIONS.GS.numeric.MaxFunctionEvaluations = 50000;
temp.OPTIONS.GS.numeric.StepTolerance = 1.e-06;
temp.OPTIONS.GS.numeric.NumTrialPoints = 5000;
% larger NumStageOnePoints -- faster run -- should be less than
% NumTrialPoints
temp.OPTIONS.GS.numeric.NumStageOnePoints = 4000; 
temp.OPTIONS.GS.numeric.MaxTime = 900; % total real time seconds
%% OPTIONS for particleswarm algorithm
temp.OPTIONS.PS.logical.particleswarm = false;
temp.OPTIONS.PS.logical.SetInitialSwarmMatrix = false;
temp.OPTIONS.PS.numeric.SwarmSizeFactor = 50;
temp.OPTIONS.PS.numeric.SelfAdjustmentWeight = 1.49;
temp.OPTIONS.PS.numeric.SocialAdjustmentWeight = 1.49;
temp.OPTIONS.PS.numeric.FunctionTolerance = 1.e-08;
temp.OPTIONS.PS.numeric.MinNeighborsFraction = 0.25;
%% OPTIONS for ML algorithm
temp.OPTIONS.LM.logical.LM = false;
temp.OPTIONS.LM.numeric.delta = 0.002;
temp.OPTIONS.LM.numeric.lambda = 0.001;
temp.OPTIONS.LM.numeric.threshold = 1.00E-12;
temp.OPTIONS.LM.numeric.maxiter = 50;
temp.OPTIONS.LM.numeric.lambdascalemaxiter = 10;
temp.OPTIONS.LM.numeric.mindifference = 1.00E-04;
%% OPTIONS for SIMPLEX algorithm
temp.OPTIONS.SP.logical.fminsearch = false;
temp.OPTIONS.SP.numeric.TolFun = 1e-08;
temp.OPTIONS.SP.numeric.TolX = 1e-12;
temp.OPTIONS.SP.numeric.MaxFunEvals = 500;
%% OUTPUT OPTIONS
temp.OPTIONS.OUTPUT.logical.output2Excel = true;
temp.OPTIONS.OUTPUT.logical.output2ASCII = false;
temp.OPTIONS.OUTPUT.logical.output2MAT = false;
temp.OPTIONS.OUTPUT.logical.outputparam = true;
temp.OPTIONS.OUTPUT.logical.outputfit = true;
temp.OPTIONS.OUTPUT.logical.outputdistribution = true;
temp.OPTIONS.OUTPUT.logical.plotintermediate = true;
%% Miscellaneous
temp.OPTIONS.MISC.logical.quickversion = true;
temp.OPTIONS.MISC.logical.phase = true;
temp.OPTIONS.MISC.logical.gaussianfit = true;
temp.OPTIONS.MISC.logical.confidence = true;
temp.OPTIONS.MISC.numeric.truncate_start = 0;
temp.OPTIONS.MISC.numeric.truncate_end = 0;
temp.OPTIONS.MISC.numeric.filter_notch = 0;
temp.OPTIONS.MISC.numeric.filter_lowpass = 0;
%
end