function [ handles ] = set_g0( handles )
% 07/28/2015
%%
% 08/02/2016 - EJH - Version 6B
% Revised to include beta factors for generalized normal distribution
%% 
handles.ANS.fixed(14:53) = 1;
%
handles.ANS.values(18) = 0;
set(handles.a_1_text,'String',num2str(handles.ANS.values(16)));
handles.ANS.values(23) = 0;
set(handles.a_2_edit,'String',num2str(handles.ANS.values(19)));
handles.ANS.values(28) = 0;
set(handles.a_3_edit,'String',num2str(handles.ANS.values(22)));
handles.ANS.values(33) = 0;
set(handles.a_4_edit,'String',num2str(handles.ANS.values(25)));
handles.ANS.values(38) = 0;
set(handles.a_5_edit,'String',num2str(handles.ANS.values(28)));
handles.ANS.values(43) = 0;
set(handles.a_6_edit,'String',num2str(handles.ANS.values(31)));
handles.ANS.values(48) = 0;
set(handles.a_7_edit,'String',num2str(handles.ANS.values(34)));
handles.ANS.values(53) = 0;
set(handles.a_8_edit,'String',num2str(handles.ANS.values(37)));
%
set(handles.g_2_checkbox,'Value',0);
set(handles.g_3_checkbox,'Value',0);
set(handles.g_4_checkbox,'Value',0);
set(handles.g_5_checkbox,'Value',0);
set(handles.g_6_checkbox,'Value',0);
set(handles.g_7_checkbox,'Value',0);
set(handles.g_8_checkbox,'Value',0);

[ handles ] = set_fixed( handles );

end

