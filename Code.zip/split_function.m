function [ handles ] = split_function( handles, old )
% 07/31/2015
%%
% 08/02/2016 - EJH - Version 6B
% Revised to include beta factors for generalized normal distribution
%%
new = 14 + 5*handles.PARAM.ng;
rval = handles.ANS.values(old);
qval = handles.ANS.values(old+1)/2.;
handles.ANS.values(old) = rval - qval;
if handles.ANS.values(old) < handles.ANS.lowerlimit(old)
    handles.ANS.values(old) = handles.ANS.lowerlimit(old) + 1.;
end 
handles.ANS.values(old+1) = qval;
if handles.ANS.values(old+1) < handles.ANS.lowerlimit(old+1)
    handles.ANS.values(old+1) = handles.ANS.lowerlimit(old+1) + 0.1;
end 
%
fhandle = (strcat('@set_g',num2str(handles.PARAM.ng + 1)));
fhandle = str2func(fhandle);
handles = feval(fhandle,handles);
%
text = strcat('g_',num2str(handles.PARAM.ng + 1),'_checkbox');
set(handles.(text),'Value',1);
%
handles.ANS.values(new) = rval + qval;
if handles.ANS.values(new) > handles.ANS.upperlimit(new)
    handles.ANS.values(new) = handles.ANS.upperlimit(new) - 1.;
end 
handles.ANS.values(new+1) = qval;
if handles.ANS.values(new+1) < handles.ANS.lowerlimit(new+1)
    handles.ANS.values(new+1) = handles.ANS.lowerlimit(new+1) + 0.1;
end  
%
temp = handles.HOLD.normamp(1:1:handles.PARAM.ng)';
ig = (old - 9)/5;
temp(ig) = temp(ig)/2;
temp(handles.PARAM.ng+1) = temp(ig);
factor = 1.;
for i= 2:handles.PARAM.ng + 1
  handles.ANS.values(13 + i*5) = 1 - (temp(i-1)/factor);
  factor = factor*handles.ANS.values(13 + i*5);
end 
%
[ handles ] = update_GUI_values( handles );
[handles] = Initialize(handles);
end

