function [stats,matrix_1,matrix_2] = confidence_bands_B( ...
    bestr,current,stats,matrix_1,matrix_2) 
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
%% 
o = moments(bestr,current);
if o(1) < stats(1,1)
    stats(1,1) = o(1);
    matrix_1(1,:) = current;
end
if o(1) > stats(2,1)
    stats(2,1) = o(1);
    matrix_1(2,:) = current;
end
if o(2) < stats(1,2)
    stats(1,2) = o(2);
    matrix_1(3,:) = current;
end
if o(2) > stats(2,2)
    stats(2,2) = o(2);
    matrix_1(4,:) = current;
end
if o(3) < stats(1,3)
    stats(1,3) = o(3);
    matrix_1(5,:) = current;
end
if o(3) > stats(2,3)
    stats(2,3) = o(3);
    matrix_1(6,:) = current;
end
if o(4) < stats(1,4)
    stats(1,4) = o(4);
    matrix_1(7,:) = current;
end
if o(4) > stats(2,4)
    stats(1,4) = o(4);
    matrix_1(8,:) = current;
end
%%
matrix_2 = cat(1,matrix_2,current);
