function [ handles ] = set_g7( handles )
% 07/12/2016 - EJH - Version 6
% Revised to include beta factors for generalized normal distribution
% 08/02/2016 - EJH - Version 6B
% Revised to include zeta factors for generalized skew norm. distribution
%% float all variables
handles.ANS.fixed(14:17) = 0;
handles.ANS.fixed(18) = 1;
handles.ANS.fixed(19:48) = 0;
handles.ANS.fixed(49:53) = 1;
%% fix beta's unless variable beta
if handles.PARAM.shape < 8
    handles.ANS.fixed(16:5:46) = 1;
    handles.ANS.fixed(17:5:47) = 1;
end
if handles.PARAM.shape == 8
    handles.ANS.fixed(16:5:46) = 0;
    handles.ANS.fixed(17:5:47) = 1;
end
if handles.PARAM.shape == 9
    handles.ANS.fixed(16:5:46) = 1;
    handles.ANS.fixed(17:5:47) = 0;
end
if handles.PARAM.shape == 10
    handles.ANS.fixed(16:5:46) = 0;
    handles.ANS.fixed(17:5:47) = 0;
end
%% make amplitude for last component non-zero
if ~handles.ANS.values(48) 
  handles.ANS.values(48) = 0.5;
end
set(handles.a_7_edit,'String',num2str(handles.ANS.values(48)));
handles.ANS.values(53) = 0.0;
set(handles.a_8_edit,'String',num2str(handles.ANS.values(53)));
%%
set(handles.r_2_edit,'Visible','on')
set(handles.r_2_checkbox,'Visible','on')
set(handles.split_2_pushbutton,'Visible','on')
set(handles.s_2_edit,'Visible','on')
set(handles.s_2_checkbox,'Visible','on') 
set(handles.b_2_edit,'Visible','on')
set(handles.l_2_edit,'Visible','on')
if handles.PARAM.shape >= 8
  set(handles.b_2_checkbox,'Visible','on')
  set(handles.l_2_checkbox,'Visible','on')
end
if handles.PARAM.shape == 8 
  set(handles.l_2_checkbox,'Visible','off')
end
if handles.PARAM.shape == 9
  set(handles.b_2_checkbox,'Visible','off') 
end  
set(handles.a_2_edit,'Visible','on')
set(handles.a_2_checkbox,'Visible','on')
set(handles.a_2_calc_text,'Visible','on')
%
set(handles.r_3_edit,'Visible','on')
set(handles.r_3_checkbox,'Visible','on')
set(handles.split_3_pushbutton,'Visible','on')
set(handles.s_3_edit,'Visible','on')
set(handles.s_3_checkbox,'Visible','on')
set(handles.a_3_edit,'Visible','on')
set(handles.b_3_edit,'Visible','on')
set(handles.l_3_edit,'Visible','on')
if handles.PARAM.shape >= 8
  set(handles.b_3_checkbox,'Visible','on')
  set(handles.l_3_checkbox,'Visible','on')
end
if handles.PARAM.shape == 8 
  set(handles.l_3_checkbox,'Visible','off')
end
if handles.PARAM.shape == 9
  set(handles.b_3_checkbox,'Visible','off') 
end  
set(handles.a_3_checkbox,'Visible','on')
set(handles.a_3_calc_text,'Visible','on')
%
set(handles.r_4_edit,'Visible','on')
set(handles.r_4_checkbox,'Visible','on')
set(handles.split_4_pushbutton,'Visible','on')
set(handles.s_4_edit,'Visible','on')
set(handles.s_4_checkbox,'Visible','on')
set(handles.b_4_edit,'Visible','on')
set(handles.l_4_edit,'Visible','on')
if handles.PARAM.shape >= 8
  set(handles.b_4_checkbox,'Visible','on')
  set(handles.l_4_checkbox,'Visible','on')
end
if handles.PARAM.shape == 8 
  set(handles.l_4_checkbox,'Visible','off')
end
if handles.PARAM.shape == 9
  set(handles.b_4_checkbox,'Visible','off') 
end  
set(handles.a_4_edit,'Visible','on')
set(handles.a_4_checkbox,'Visible','on')
set(handles.a_4_calc_text,'Visible','on')
%
set(handles.r_5_edit,'Visible','on')
set(handles.r_5_checkbox,'Visible','on')
set(handles.split_5_pushbutton,'Visible','on')
set(handles.s_5_edit,'Visible','on')
set(handles.s_5_checkbox,'Visible','on')
set(handles.b_5_edit,'Visible','on')
set(handles.l_5_edit,'Visible','on')
if handles.PARAM.shape >= 8
  set(handles.b_5_checkbox,'Visible','on')
  set(handles.l_5_checkbox,'Visible','on')
end
if handles.PARAM.shape == 8 
  set(handles.l_5_checkbox,'Visible','off')
end
if handles.PARAM.shape == 9
  set(handles.b_5_checkbox,'Visible','off') 
end  
set(handles.a_5_edit,'Visible','on')
set(handles.a_5_checkbox,'Visible','on')
set(handles.a_5_calc_text,'Visible','on')
%
set(handles.r_6_edit,'Visible','on')
set(handles.r_6_checkbox,'Visible','on')
set(handles.split_6_pushbutton,'Visible','on')
set(handles.s_6_edit,'Visible','on')
set(handles.s_6_checkbox,'Visible','on')
set(handles.b_6_edit,'Visible','on')
set(handles.l_6_edit,'Visible','on')
if handles.PARAM.shape >= 8
  set(handles.b_6_checkbox,'Visible','on')
  set(handles.l_6_checkbox,'Visible','on')
end
if handles.PARAM.shape == 8 
  set(handles.l_6_checkbox,'Visible','off')
end
if handles.PARAM.shape == 9
  set(handles.b_6_checkbox,'Visible','off') 
end  
set(handles.a_6_edit,'Visible','on')
set(handles.a_6_checkbox,'Visible','on')
set(handles.a_6_calc_text,'Visible','on')
%
set(handles.r_7_edit,'Visible','on')
set(handles.r_7_checkbox,'Visible','on')
set(handles.split_7_pushbutton,'Visible','on')
set(handles.s_7_edit,'Visible','on')
set(handles.s_7_checkbox,'Visible','on')
set(handles.b_7_edit,'Visible','on')
set(handles.l_7_edit,'Visible','on')
if handles.PARAM.shape >= 8
  set(handles.b_7_checkbox,'Visible','on')
  set(handles.l_7_checkbox,'Visible','on')
end
if handles.PARAM.shape == 8 
  set(handles.l_7_checkbox,'Visible','off')
end
if handles.PARAM.shape == 9
  set(handles.b_7_checkbox,'Visible','off') 
end  
set(handles.a_7_edit,'Visible','on')
set(handles.a_7_checkbox,'Visible','on')
set(handles.a_7_calc_text,'Visible','on')
%
set(handles.r_8_edit,'Visible','off')
set(handles.r_8_checkbox,'Visible','off')
set(handles.s_8_edit,'Visible','off')
set(handles.s_8_checkbox,'Visible','off')
set(handles.b_8_edit,'Visible','off')
set(handles.b_8_checkbox,'Visible','off')
set(handles.l_8_edit,'Visible','off')
set(handles.l_8_checkbox,'Visible','off')
set(handles.a_8_calc_text,'Visible','off')
set(handles.a_8_checkbox,'Visible','off')
set(handles.a_8_calc_text,'Visible','off')
%
set(handles.g_8_checkbox,'Value',0);
%
[ handles ] = set_fixed( handles );
%
end

