function [ handles ] = update_value( hObject, handles, index )
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
temp = str2double(get(hObject,'String'));
if (temp < handles.ANS.lowerlimit(index) || ...
    temp > handles.ANS.upperlimit(index))
      set(handles.message_text,'String','VALUE OUTSIDE OF RANGE', ...
        'BackgroundColor',[1 0.65 0.65]);
else
      set(handles.message_text,'String','OK', ...
        'BackgroundColor',[1 1 1]);
      handles.ANS.values(index) = temp;
end 
end

