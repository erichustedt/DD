% 11/08/2012
% EJH
function [ handles ] = find_float_values( handles )
%--------------------------------------------------------------------------
nflex = 0;
n = 0;
handles.FLOAT = [ ];

% detemine parameters to be varied
temp = find(~handles.ANS.fixed & ~handles.ANS.links);
handles.FLOAT.floatparindex(1,:) = temp'; 
handles.FLOAT.floatnames = handles.ANS.names(temp);
handles.FLOAT.floatnamelengths = handles.ANS.namelengths(temp);
nflex = length(temp);
handles.FLOAT.float(n+1:n+nflex) = handles.ANS.values(temp);
n = n + nflex;
% determine linked parameters
handles.FLOAT.linkedindex(:) = find(handles.ANS.links);
handles.FLOAT.nlinked = length(handles.FLOAT.linkedindex(:));
handles.FLOAT.linkedtoindex(1,:) = ...
  handles.ANS.links(handles.FLOAT.linkedindex(:));
handles.FLOAT.nfloat = nflex;
handles.FLOAT.floatexpindex = ones(nflex);

end