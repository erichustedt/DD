function varargout = DD(varargin)
% DD Version 3 - EJH
% 09/30/2015 --------------------------------------------------------------
% revised to estimate uncertainties in parameters from covariance matrix
% and to estimate uncertainty in P(R) using delta method.
% DD Version 2 - EJH
% 09/10/2015 --------------------------------------------------------------
% revised to correctly calculate confidence levels at 1, 2, and 3 standard
% deviations and to interpolate chisquared curve to identify where it 
% crosses confidence levels.
% 08/12/2015 --------------------------------------------------------------
% CHANGED:  behavior when Exponential or Calculated checkboxes are checked
% 07/27/2015 --------------------------------------------------------------
% ADDED:    4th thru 8th components
% ADDED:    split buttons
% ADDED:    reorder button
% ADDED:    initial guess option
% 04/06/2015 --------------------------------------------------------------
% ADDED:    Add Save Statistics and List Statistics buttons
% 04/03/2015 --------------------------------------------------------------
% ADDED:    Add LaTeX to GUI
% 11/06/2013 --------------------------------------------------------------
% CHANGED   The name of the program from GG to DD.
% CHANGED:  Made minor changes to the way the final results are displayed.
% -------------------------------------------------------------------------
% 10/28/2013 --------------------------------------------------------------
% FIXED:    The way that the relative amplitudes of multiple components are 
%           calculated.
% CHANGED:  Relative amplitudes of multiple components are displayed as 
%           percentages.
% 07/13/2016 - EJH - Version 6
% Revised to include generalized normal and skew normal distributions
% 08/02/2016 - EJH - Version 6B
% Revised to include generalized skew normal distributions
% 01/10/2017 - EJH - Version 7
% added fmincon and globalsearch. 
% 02/09/2018 - EJH 
% added particleswarm
% -------------------------------------------------------------------------
% DD MATLAB code for DD.fig
%      DD, by itself, creates a new DD or raises the existing
%      singleton*.
%
%      H = DD returns the handle to a new DD or the handle to
%      the existing singleton*.
%
%      DD('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DD.M with the given input arguments.
%
%      DD('Property','Value',...) creates a new DD or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DD_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DD_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DD

% Last Modified by GUIDE v2.5 04-Jul-2018 14:55:13

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @DD_OpeningFcn, ...
    'gui_OutputFcn',  @DD_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before DD is made visible.
function DD_OpeningFcn(hObject, ~, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DD (see VARARGIN)

% Include subdirectories in path
addpath(genpath(pwd));
% Check to see if Matlab version is pre-2014B
handles.oldMatlabVersion = verLessThan('matlab','8.4');
% Choose default command line output for DD
warning off MATLAB:MKDIR:DirectoryExists;
warning off MATLAB:RMDIR:RemovedFromPath;
handles.output = hObject;
[ handles ] = set_initial_answer_values( handles );
%
handles.status = -1;
% Set up OPTIONS
temp = set_initial_options_Tabbed;
options_update([],[],hObject,handles,temp);
handles = guidata(hObject);
%
handles.DATA.name = ' ';
%
handles.DataDirectory = pwd;
%
set(handles.phase_text,'String',num2str(0));
set(handles.time_shift_text,'String',num2str(0));
set(handles.fit_chisquared_text,'String',num2str(0.0));
set(handles.static_text_22,'String',num2str(0.0));
set(handles.truncate_end_edit,'String', ...
  num2str(handles.OPTIONS.MISC.numeric.truncate_end));
set(handles.truncate_start_edit,'String', ...
  num2str(handles.OPTIONS.MISC.numeric.truncate_start))
%
t1 = pwd;
handles.Unix = isunix;
if handles.Unix
  handles.sep = '/';
else
  handles.sep = '\';
end
  
handles.answerfile = [t1 handles.sep 'output'];
set(handles.answerfile_text,'String',handles.answerfile);
%--------------------------------------------------------------------------
% 04/03/2015
% find all static text UIControls whose 'Tag' begins with 'latex_', these
% will be replaced with axes text labels formatted in LaTeX
latex_labels = findobj(hObject,'-regexp','Tag','latex_');
for i = 1:length(latex_labels)
    set(latex_labels(i),'Units','normalized');
    % get parent of current label and the tag for the parent
    latex_xp = get(latex_labels(i),'Parent');
    latex_xt = get(latex_xp,'Tag');
    % TEXT annotations require an axes as parent so create an invisible axes
    if ~isfield(handles,'latex_axes') || ~isfield(handles.latex_axes,latex_xt)
        handles.latex_axes.(latex_xt) = axes('Parent',latex_xp, ...
            'Units','normalized','Position',[0 0 1 1], ...
            'Visible','off');
    end
    % get current text, position, tag,and color
    latex_s = get(latex_labels(i),'String');
    latex_p = get(latex_labels(i),'Position');
    latex_t = get(latex_labels(i),'Tag');
    latex_c = get(latex_labels(i),'ForegroundColor');
    % remove the original UIControl
    delete(latex_labels(i));
    % replace with a TEXT object
    handles.(latex_t) = text(latex_p(1),latex_p(2),latex_s, ...
        'Interpreter','latex','Parent',handles.latex_axes.(latex_xt), ...
        'FontSize',12,'Color',latex_c);
end
% 08/27/2015 - turn off unneeded text labels for Version 2 - background
% calculations
handles.latex_static_text_13.Visible = 'off';
handles.latex_static_text_14.Visible = 'off';
%--------------------------------------------------------------------------
% 04/06/2015
handles.save_statistics = {};
% 04/08/2015
handles.CI.plot = 1;
handles.CI.stop = 0;
handles.CI.bflag = 0;
handles.CI.cflag = 0;
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes DD wait for user response (see UIRESUME)
% uiwait(handles.figureDD);

% --- Outputs from this function are returned to the command line.
function varargout = DD_OutputFcn(~, ~, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in find_data_pushbutton.
function find_data_pushbutton_Callback(hObject, ~, handles)
% hObject    handle to find_data_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%
handles.status = -1;
[t2,t1,~] = uigetfile(fullfile(handles.DataDirectory, ...
    '*.dat;*.asc;*.DTA'),'EPR data');
handles.DataDirectory = t1;
temp = strcat(t1,t2);
handles.DATA.name = temp(1:strfind(temp,'.')-1);
set(handles.data_edit,'String',handles.DATA.name);
disp(handles.DATA.name);
%
[ handles.DATA ] = DD_read( handles.DATA.name );
%
if handles.DATA.npts > 0
    [~,t2a,~] = fileparts(t2);
    handles.answerfile = [t1 t2a];
    set(handles.answerfile_text,'String',handles.answerfile);
    [ handles ] = plot_raw_data( handles );
else
    try delete(handles.axes2); end
end
%
set(handles.phase_text,'String',num2str(0));
set(handles.time_shift_text,'String',num2str(0));
set(handles.fit_chisquared_text,'String',num2str(0.0));
set(handles.static_text_22,'String',num2str(0.0));
%% Process Data
try
  %% Suspend DD GUI
  GUI_Control(handles.figureDD,'off');
  %%
  set(handles.message_text,'String','Processing', ...
    'BackgroundColor',[1 0.65 0.65]);
  drawnow;
  [handles] = Process(handles);
  %% Set UP Initial Calculation
  [handles] = Initialize(handles);
catch
  GUI_Control(handles.figureDD);
  set(handles.message_text,'String','Error Processing', ...
    'BackgroundColor',[0.8 0.0 0.0]);
  drawnow;
end
%% Resume DD GUI
GUI_Control(handles.figureDD);
% FINISH
guidata(hObject, handles);

function data_edit_Callback(hObject, ~, handles)
% hObject    handle to data_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of data_edit as text
%        str2double(get(hObject,'String')) returns contents of data_edit
%
handles.status = -1;
handles.DATA.name = get(hObject,'String');
disp(handles.DATA.name);
%
[ handles.DATA ] = DD_read( handles.DATA.name );
%
if handles.DATA.npts > 0
    [t1,t2a,~] = fileparts(handles.DATA.name);
    handles.answerfile = [t1 handles.sep t2a];
    set(handles.answerfile_text,'String',handles.answerfile);
    [ handles ] = plot_raw_data( handles );
else
    try delete(handles.axes2); end
end
%
set(handles.phase_text,'String',num2str(0));
set(handles.time_shift_text,'String',num2str(0));
set(handles.fit_chisquared_text,'String',num2str(0.0));
set(handles.static_text_22,'String',num2str(0.0));
%% Process Data
try
  %% Suspend DD GUI
  GUI_Control(handles.figureDD,'off');
  %%
  set(handles.message_text,'String','Processing', ...
    'BackgroundColor',[1 0.65 0.65]);
  drawnow;
  [handles] = Process(handles);
  %% Set UP Initial Calculation
  [handles] = Initialize(handles);
catch
  GUI_Control(handles.figureDD);
  set(handles.message_text,'String','Error Processing', ...
    'BackgroundColor',[0.8 0.0 0.0]);
  drawnow;
end
%% Resume DD GUI
GUI_Control(handles.figureDD);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function data_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to data_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in process_data_pushbutton.
function process_data_pushbutton_Callback(hObject, ~, handles)
% hObject    handle to process_data_pushbutton (see GCBO)
% eventdata  reserved - to be defined in da future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
  %% Suspend DD GUI
  GUI_Control(handles.figureDD,'off');
  %%
  set(handles.message_text,'String','Processing', ...
    'BackgroundColor',[1 0.65 0.65]);
  drawnow;
  [handles] = Process(handles);
  %% Set UP Initial Calculation
  [handles] = Initialize(handles);
catch
  GUI_Control(handles.figureDD);
  set(handles.message_text,'String','Error Processing', ...
    'BackgroundColor',[0.8 0.0 0.0]);
  drawnow;
end
%% Resume DD GUI
GUI_Control(handles.figureDD);
%% FINISH
guidata(hObject, handles);

% --- Executes on button press in phase_checkbox.
function phase_checkbox_Callback(hObject, ~, handles)
% hObject    handle to phase_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% 
handles.OPTIONS.MISC.logical.phase = get(handles.phase_checkbox,'Value');
%% FINISH
guidata(hObject, handles);

% --- Executes on button press in zero_time_checkbox.
function zero_time_checkbox_Callback(hObject, ~, handles)
% hObject    handle to zero_time_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% 
handles.OPTIONS.MISC.logical.gaussianfit = ...
  get(handles.zero_time_checkbox,'Value');
%% FINISH
guidata(hObject, handles);

% --- Executes on button press in auto_checkbox.
function auto_checkbox_Callback(~, ~, ~)
% hObject    handle to auto_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of auto_checkbox

% --- Executes on button press in g_1_checkbox.
function g_1_checkbox_Callback(hObject, ~, handles)
% hObject    handle to g_1_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of g_1_checkbox
temp = get(hObject,'Value');
if temp
    handles = set_g1(handles);
else
    handles = set_g0(handles);
end
%
clear handles.CI.data;
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% Hint: get(hObject,'Value') returns toggle state of zero_time_checkbox

function r_1_edit_Callback(hObject, ~, handles)
% hObject    handle to r_1_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of r_1_edit as text
%        str2double(get(hObject,'String')) returns contents of r_1_edit
index = 14;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function r_1_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to r_1_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in r_1_checkbox.
function r_1_checkbox_Callback(hObject, ~, handles)
% hObject    handle to r_1_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of r_1_checkbox
index = 14;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function s_1_edit_Callback(hObject, ~, handles)
% hObject    handle to s_1_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of s_1_edit as text
%        str2double(get(hObject,'String')) returns contents of s_1_edit
index = 15;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function s_1_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to s_1_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in s_1_checkbox.
function s_1_checkbox_Callback(hObject, ~, handles)
% hObject    handle to s_1_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of s_1_checkbox
index = 15;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in split_1_pushbutton.
function split_1_pushbutton_Callback(hObject, ~, handles)
% hObject    handle to split_1_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[ handles ] = split_function( handles, 14 );
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in g_2_checkbox.
function g_2_checkbox_Callback(hObject, ~, handles)
% hObject    handle to g_2_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of g_2_checkbox
temp = get(hObject,'Value');
temp1 = get(handles.g_1_checkbox,'Value');
if ~temp1
    set(hObject,'Value',0);
    return;
end
if temp
    [ handles ] = set_g2(handles);
else
    [ handles ] = set_g1(handles);
end
%
[handles] = Initialize(handles);
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function r_2_edit_Callback(hObject, ~, handles)
% hObject    handle to r_2_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of r_2_edit as text
%        str2double(get(hObject,'String')) returns contents of r_2_edit
index = 19;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function r_2_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to r_2_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in r_2_checkbox.
function r_2_checkbox_Callback(hObject, ~, handles)
% hObject    handle to r_2_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of r_2_checkbox
index = 19;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function s_2_edit_Callback(hObject, ~, handles)
% hObject    handle to s_2_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of s_2_edit as text
%        str2double(get(hObject,'String')) returns contents of s_2_edit
index = 20;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function s_2_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to s_2_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in s_2_checkbox.
function s_2_checkbox_Callback(hObject, ~, handles)
% hObject    handle to s_2_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of s_2_checkbox
index = 20;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function a_2_edit_Callback(hObject, ~, handles)
% hObject    handle to a_2_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of a_2_edit as text
%        str2double(get(hObject,'String')) returns contents of a_2_edit
index = 23;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function a_2_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to a_2_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in a_2_checkbox.
function a_2_checkbox_Callback(hObject, ~, handles)
% hObject    handle to a_2_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of a_2_checkbox
index = 23;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in g_3_checkbox.
function g_3_checkbox_Callback(hObject, ~, handles)
% hObject    handle to g_3_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of g_3_checkbox
temp = get(hObject,'Value');
temp1 = get(handles.g_1_checkbox,'Value');
temp2 = get(handles.g_2_checkbox,'Value');
if ~temp1 || ~temp2
    set(hObject,'Value',0);
    return;
end
if temp
    [ handles ] = set_g3(handles);
else
    [ handles ] = set_g2(handles);
end
%
[handles] = Initialize(handles);
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function r_3_edit_Callback(hObject, ~, handles)
% hObject    handle to r_3_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of r_3_edit as text
%        str2double(get(hObject,'String')) returns contents of r_3_edit
index = 24;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function r_3_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to r_3_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in r_3_checkbox.
function r_3_checkbox_Callback(hObject, ~, handles)
% hObject    handle to r_3_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of r_3_checkbox
index = 24;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function s_3_edit_Callback(hObject, ~, handles)
% hObject    handle to s_3_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of s_3_edit as text
%        str2double(get(hObject,'String')) returns contents of s_3_edit
index = 25;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function s_3_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to s_3_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in s_3_checkbox.
function s_3_checkbox_Callback(hObject, ~, handles)
% hObject    handle to s_3_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of s_3_checkbox
index = 25;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function a_3_edit_Callback(hObject, ~, handles)
% hObject    handle to a_3_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of a_3_edit as text
%        str2double(get(hObject,'String')) returns contents of a_3_edit
index = 28;
[ handles ] = update_value( hObject, handles, index );
%
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function a_3_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to a_3_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in a_3_checkbox.
function a_3_checkbox_Callback(hObject, ~, handles)
% hObject    handle to a_3_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of a_3_checkbox
index = 28;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in g_4_checkbox.
function g_4_checkbox_Callback(hObject, ~, handles)
% hObject    handle to g_4_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of g_4_checkbox
temp = get(hObject,'Value');
temp1 = get(handles.g_1_checkbox,'Value');
temp2 = get(handles.g_2_checkbox,'Value');
temp3 = get(handles.g_3_checkbox,'Value');
if ~temp1 || ~temp2 || ~temp3
    set(hObject,'Value',0);
    return;
end
%
if temp
    [ handles ] = set_g4(handles);
else
    [ handles ] = set_g3(handles);
end
%
[handles] = Initialize(handles);
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function r_4_edit_Callback(hObject, ~, handles)
% hObject    handle to r_4_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of r_4_edit as text
%        str2double(get(hObject,'String')) returns contents of r_4_edit as a double
index = 29;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function r_4_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to r_4_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in r_4_checkbox.
function r_4_checkbox_Callback(hObject, ~, handles)
% hObject    handle to r_4_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of r_4_checkbox
index = 29;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function s_4_edit_Callback(hObject, ~, handles)
% hObject    handle to s_4_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of s_4_edit as text
%        str2double(get(hObject,'String')) returns contents of s_4_edit as a double
index = 30;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function s_4_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to s_4_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in s_4_checkbox.
function s_4_checkbox_Callback(hObject, ~, handles)
% hObject    handle to s_4_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of s_4_checkbox
index = 30;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function a_4_edit_Callback(hObject, ~, handles)
% hObject    handle to a_4_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of a_4_edit as text
%        str2double(get(hObject,'String')) returns contents of a_4_edit as a double
index = 33;
[ handles ] = update_value( hObject, handles, index );
%

%
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function a_4_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to a_4_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in a_4_checkbox.
function a_4_checkbox_Callback(hObject, ~, handles)
% hObject    handle to a_4_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of a_4_checkbox
index = 33;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in g_5_checkbox.
function g_5_checkbox_Callback(hObject, ~, handles)
% hObject    handle to g_5_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of g_5_checkbox
temp = get(hObject,'Value');
temp1 = get(handles.g_1_checkbox,'Value');
temp2 = get(handles.g_2_checkbox,'Value');
temp3 = get(handles.g_3_checkbox,'Value');
temp4 = get(handles.g_4_checkbox,'Value');
if ~temp1 || ~temp2 || ~temp3 || ~temp4
    set(hObject,'Value',0);
    return;
end
%
if temp
    [ handles ] = set_g5(handles);
else
    [ handles ] = set_g4(handles);
end
%
[handles] = Initialize(handles);
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function r_5_edit_Callback(hObject, ~, handles)
% hObject    handle to r_5_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of r_5_edit as text
%        str2double(get(hObject,'String')) returns contents of r_5_edit as a double
index = 34;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function r_5_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to r_5_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in r_5_checkbox.
function r_5_checkbox_Callback(hObject, ~, handles)
% hObject    handle to r_5_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of r_5_checkbox
index = 34;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function s_5_edit_Callback(hObject, ~, handles)
% hObject    handle to s_5_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of s_5_edit as text
%        str2double(get(hObject,'String')) returns contents of s_5_edit as a double
index = 35;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function s_5_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to s_5_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in s_5_checkbox.
function s_5_checkbox_Callback(hObject, ~, handles)
% hObject    handle to s_5_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of s_5_checkbox
index = 35;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function a_5_edit_Callback(hObject, ~, handles)
% hObject    handle to a_5_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of a_5_edit as text
%        str2double(get(hObject,'String')) returns contents of a_5_edit as a double
index = 38;
[ handles ] = update_value( hObject, handles, index );
%
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function a_5_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to a_5_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in a_5_checkbox.
function a_5_checkbox_Callback(hObject, ~, handles)
% hObject    handle to a_5_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of a_5_checkbox
index = 38;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in g_6_checkbox.
function g_6_checkbox_Callback(hObject, ~, handles)
% hObject    handle to g_6_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of g_6_checkbox
temp = get(hObject,'Value');
temp1 = get(handles.g_1_checkbox,'Value');
temp2 = get(handles.g_2_checkbox,'Value');
temp3 = get(handles.g_3_checkbox,'Value');
temp4 = get(handles.g_4_checkbox,'Value');
temp5 = get(handles.g_5_checkbox,'Value');
if ~temp1 || ~temp2 || ~temp3 || ~temp4 || ~temp5
    set(hObject,'Value',0);
    return;
end
%
if temp
    [ handles ] = set_g6(handles);
else
    [ handles ] = set_g5(handles);
end
%
[handles] = Initialize(handles);
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function r_6_edit_Callback(hObject, ~, handles)
% hObject    handle to r_6_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of r_6_edit as text
%        str2double(get(hObject,'String')) returns contents of r_6_edit as a double
index = 39;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function r_6_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to r_6_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in r_6_checkbox.
function r_6_checkbox_Callback(hObject, ~, handles)
% hObject    handle to r_6_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of r_6_checkbox
index = 39;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function s_6_edit_Callback(hObject, ~, handles)
% hObject    handle to s_6_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of s_6_edit as text
%        str2double(get(hObject,'String')) returns contents of s_6_edit as a double
index = 40;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function s_6_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to s_6_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in s_6_checkbox.
function s_6_checkbox_Callback(hObject, ~, handles)
% hObject    handle to s_6_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of s_6_checkbox
index = 40;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function a_6_edit_Callback(hObject, ~, handles)
% hObject    handle to a_6_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of a_6_edit as text
%        str2double(get(hObject,'String')) returns contents of a_6_edit as a double
index = 43;
[ handles ] = update_value( hObject, handles, index );
%
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function a_6_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to a_6_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in a_6_checkbox.
function a_6_checkbox_Callback(hObject, ~, handles)
% hObject    handle to a_6_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of a_6_checkbox
index = 43;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in g_7_checkbox.
function g_7_checkbox_Callback(hObject, ~, handles)
% hObject    handle to g_7_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of g_7_checkbox
temp = get(hObject,'Value');
temp1 = get(handles.g_1_checkbox,'Value');
temp2 = get(handles.g_2_checkbox,'Value');
temp3 = get(handles.g_3_checkbox,'Value');
temp4 = get(handles.g_4_checkbox,'Value');
temp5 = get(handles.g_5_checkbox,'Value');
temp6 = get(handles.g_6_checkbox,'Value');
if ~temp1 || ~temp2 || ~temp3 || ~temp4 || ~temp5 || ~temp6
    set(hObject,'Value',0);
    return;
end
%
if temp
    [ handles ] = set_g7(handles);
else
    [ handles ] = set_g6(handles);
end
%
[handles] = Initialize(handles);
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function r_7_edit_Callback(hObject, ~, handles)
% hObject    handle to r_7_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of r_7_edit as text
%        str2double(get(hObject,'String')) returns contents of r_7_edit as a double
index = 44;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function r_7_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to r_7_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in r_7_checkbox.
function r_7_checkbox_Callback(hObject, ~, handles)
% hObject    handle to r_7_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of r_7_checkbox
index = 44;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function s_7_edit_Callback(hObject, ~, handles)
% hObject    handle to s_7_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of s_7_edit as text
%        str2double(get(hObject,'String')) returns contents of s_7_edit as a double
index = 45;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function s_7_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to s_7_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in s_7_checkbox.
function s_7_checkbox_Callback(hObject, ~, handles)
% hObject    handle to s_7_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of s_7_checkbox
index = 45;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function a_7_edit_Callback(hObject, ~, handles)
% hObject    handle to a_7_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of a_7_edit as text
%        str2double(get(hObject,'String')) returns contents of a_7_edit as a double
index = 48;
[ handles ] = update_value( hObject, handles, index );
%
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function a_7_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to a_7_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in a_7_checkbox.
function a_7_checkbox_Callback(hObject, ~, handles)
% hObject    handle to a_7_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of a_7_checkbox
index = 48;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in g_8_checkbox.
function g_8_checkbox_Callback(hObject, ~, handles)
% hObject    handle to g_8_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of g_8_checkbox
temp = get(hObject,'Value');
temp1 = get(handles.g_1_checkbox,'Value');
temp2 = get(handles.g_2_checkbox,'Value');
temp3 = get(handles.g_3_checkbox,'Value');
temp4 = get(handles.g_4_checkbox,'Value');
temp5 = get(handles.g_5_checkbox,'Value');
temp6 = get(handles.g_6_checkbox,'Value');
temp7 = get(handles.g_7_checkbox,'Value');
if ~temp1 || ~temp2 || ~temp3 || ~temp4 || ~temp5 || ~temp6 || ~temp7
    set(hObject,'Value',0);
    return;
end
%
if temp
    [ handles ] = set_g8(handles);
else
    [ handles ] = set_g7(handles);
end
%
[handles] = Initialize(handles);
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function r_8_edit_Callback(hObject, ~, handles)
% hObject    handle to r_8_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of r_8_edit as text
%        str2double(get(hObject,'String')) returns contents of r_8_edit as a double
index = 49;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function r_8_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to r_8_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in r_8_checkbox.
function r_8_checkbox_Callback(hObject, ~, handles)
% hObject    handle to r_8_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of r_8_checkbox
index = 49;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function s_8_edit_Callback(hObject, ~, handles)
% hObject    handle to s_8_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of s_8_edit as text
%        str2double(get(hObject,'String')) returns contents of s_8_edit as a double
index = 50;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function s_8_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to s_8_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in s_8_checkbox.
function s_8_checkbox_Callback(hObject, ~, handles)
% hObject    handle to s_8_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of s_8_checkbox
index = 50;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function a_8_edit_Callback(hObject, ~, handles)
% hObject    handle to a_8_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of a_8_edit as text
%        str2double(get(hObject,'String')) returns contents of a_8_edit as a double
index = 53;
[ handles ] = update_value( hObject, handles, index );
%
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function a_8_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to a_8_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in a_8_checkbox.
function a_8_checkbox_Callback(hObject, ~, handles)
% hObject    handle to a_8_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of a_8_checkbox
index = 53;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);
% --- Executes on button press in gaussian_checkbox.

function gaussian_checkbox_Callback(hObject, ~, handles)
% hObject    handle to gaussian_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of gaussian_checkbox
temp = get(hObject,'Value');
if temp
    handles.ANS.values(13) = 1;
    set(handles.rice_checkbox,'Value',0); 
    set(handles.variable_checkbox,'Value',0); 
    set(handles.skewed_checkbox,'Value',0);
    set(handles.GSND_checkbox,'Value',0);
    %
    handles.ANS.values(16:5:51) = 2.; 
    set(handles.b_1_edit,'String',num2str(handles.ANS.values(16)));
    set(handles.b_2_edit,'String',num2str(handles.ANS.values(21)));
    set(handles.b_3_edit,'String',num2str(handles.ANS.values(26)));
    set(handles.b_4_edit,'String',num2str(handles.ANS.values(31)));
    set(handles.b_5_edit,'String',num2str(handles.ANS.values(36)));
    set(handles.b_6_edit,'String',num2str(handles.ANS.values(41)));
    set(handles.b_7_edit,'String',num2str(handles.ANS.values(46)));
    set(handles.b_8_edit,'String',num2str(handles.ANS.values(51)));
    handles.ANS.fixed(16:5:51) = 1;
    set(handles.b_1_checkbox,'Value',~handles.ANS.fixed(16));
    set(handles.b_2_checkbox,'Value',~handles.ANS.fixed(21));
    set(handles.b_3_checkbox,'Value',~handles.ANS.fixed(26));
    set(handles.b_4_checkbox,'Value',~handles.ANS.fixed(31));
    set(handles.b_5_checkbox,'Value',~handles.ANS.fixed(36));
    set(handles.b_6_checkbox,'Value',~handles.ANS.fixed(41));
    set(handles.b_7_checkbox,'Value',~handles.ANS.fixed(46));
    set(handles.b_8_checkbox,'Value',~handles.ANS.fixed(51));
    set(handles.b_1_checkbox,'Visible','off');
    set(handles.b_2_checkbox,'Visible','off');
    set(handles.b_3_checkbox,'Visible','off');
    set(handles.b_4_checkbox,'Visible','off');
    set(handles.b_5_checkbox,'Visible','off');
    set(handles.b_6_checkbox,'Visible','off');
    set(handles.b_7_checkbox,'Visible','off');
    set(handles.b_8_checkbox,'Visible','off');  
    set(handles.b_1_edit,'Style','text');
    set(handles.b_2_edit,'Style','text');
    set(handles.b_3_edit,'Style','text');
    set(handles.b_4_edit,'Style','text');
    set(handles.b_5_edit,'Style','text');
    set(handles.b_6_edit,'Style','text');
    set(handles.b_7_edit,'Style','text');
    set(handles.b_8_edit,'Style','text');
    %
    handles.ANS.values(17:5:52) = 0.; 
    set(handles.l_1_edit,'String',num2str(handles.ANS.values(17)));
    set(handles.l_2_edit,'String',num2str(handles.ANS.values(22)));
    set(handles.l_3_edit,'String',num2str(handles.ANS.values(27)));
    set(handles.l_4_edit,'String',num2str(handles.ANS.values(32)));
    set(handles.l_5_edit,'String',num2str(handles.ANS.values(37)));
    set(handles.l_6_edit,'String',num2str(handles.ANS.values(42)));
    set(handles.l_7_edit,'String',num2str(handles.ANS.values(47)));
    set(handles.l_8_edit,'String',num2str(handles.ANS.values(52)));
    handles.ANS.fixed(17:5:52) = 1;
    set(handles.l_1_checkbox,'Value',~handles.ANS.fixed(17));
    set(handles.l_2_checkbox,'Value',~handles.ANS.fixed(22));
    set(handles.l_3_checkbox,'Value',~handles.ANS.fixed(27));
    set(handles.l_4_checkbox,'Value',~handles.ANS.fixed(32));
    set(handles.l_5_checkbox,'Value',~handles.ANS.fixed(37));
    set(handles.l_6_checkbox,'Value',~handles.ANS.fixed(42));
    set(handles.l_7_checkbox,'Value',~handles.ANS.fixed(47));
    set(handles.l_8_checkbox,'Value',~handles.ANS.fixed(52));
    set(handles.l_1_checkbox,'Visible','off');
    set(handles.l_2_checkbox,'Visible','off');
    set(handles.l_3_checkbox,'Visible','off');
    set(handles.l_4_checkbox,'Visible','off');
    set(handles.l_5_checkbox,'Visible','off');
    set(handles.l_6_checkbox,'Visible','off');
    set(handles.l_7_checkbox,'Visible','off');
    set(handles.l_8_checkbox,'Visible','off');  
    set(handles.l_1_edit,'Style','text');
    set(handles.l_2_edit,'Style','text');
    set(handles.l_3_edit,'Style','text');
    set(handles.l_4_edit,'Style','text');
    set(handles.l_5_edit,'Style','text');
    set(handles.l_6_edit,'Style','text');
    set(handles.l_7_edit,'Style','text');
    set(handles.l_8_edit,'Style','text');
end
% FINISH
guidata(hObject, handles);

% --- Executes on button press in rice_checkbox.
function rice_checkbox_Callback(hObject, ~, handles)
% hObject    handle to rice_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of rice_checkbox
temp = get(hObject,'Value');
if temp 
    handles.ANS.values(13) = 5;
    set(handles.gaussian_checkbox,'Value',0); 
    set(handles.variable_checkbox,'Value',0);
    set(handles.skewed_checkbox,'Value',0);
    set(handles.GSND_checkbox,'Value',0); 
    %
    handles.ANS.values(16:5:51) = 2.; 
    set(handles.b_1_edit,'String',num2str(handles.ANS.values(16)));
    set(handles.b_2_edit,'String',num2str(handles.ANS.values(21)));
    set(handles.b_3_edit,'String',num2str(handles.ANS.values(26)));
    set(handles.b_4_edit,'String',num2str(handles.ANS.values(31)));
    set(handles.b_5_edit,'String',num2str(handles.ANS.values(36)));
    set(handles.b_6_edit,'String',num2str(handles.ANS.values(41)));
    set(handles.b_7_edit,'String',num2str(handles.ANS.values(46)));
    set(handles.b_8_edit,'String',num2str(handles.ANS.values(51)));
    handles.ANS.fixed(16:5:51) = 1;
    set(handles.b_1_checkbox,'Value',~handles.ANS.fixed(16));
    set(handles.b_2_checkbox,'Value',~handles.ANS.fixed(21));
    set(handles.b_3_checkbox,'Value',~handles.ANS.fixed(26));
    set(handles.b_4_checkbox,'Value',~handles.ANS.fixed(31));
    set(handles.b_5_checkbox,'Value',~handles.ANS.fixed(36));
    set(handles.b_6_checkbox,'Value',~handles.ANS.fixed(41));
    set(handles.b_7_checkbox,'Value',~handles.ANS.fixed(46));
    set(handles.b_8_checkbox,'Value',~handles.ANS.fixed(51));
    set(handles.b_1_checkbox,'Visible','off');
    set(handles.b_2_checkbox,'Visible','off');
    set(handles.b_3_checkbox,'Visible','off');
    set(handles.b_4_checkbox,'Visible','off');
    set(handles.b_5_checkbox,'Visible','off');
    set(handles.b_6_checkbox,'Visible','off');
    set(handles.b_7_checkbox,'Visible','off');
    set(handles.b_8_checkbox,'Visible','off');  
    set(handles.b_1_edit,'Style','text');
    set(handles.b_2_edit,'Style','text');
    set(handles.b_3_edit,'Style','text');
    set(handles.b_4_edit,'Style','text');
    set(handles.b_5_edit,'Style','text');
    set(handles.b_6_edit,'Style','text');
    set(handles.b_7_edit,'Style','text');
    set(handles.b_8_edit,'Style','text');
    %
    handles.ANS.values(17:5:52) = 0.; 
    set(handles.l_1_edit,'String',num2str(handles.ANS.values(17)));
    set(handles.l_2_edit,'String',num2str(handles.ANS.values(22)));
    set(handles.l_3_edit,'String',num2str(handles.ANS.values(27)));
    set(handles.l_4_edit,'String',num2str(handles.ANS.values(32)));
    set(handles.l_5_edit,'String',num2str(handles.ANS.values(37)));
    set(handles.l_6_edit,'String',num2str(handles.ANS.values(42)));
    set(handles.l_7_edit,'String',num2str(handles.ANS.values(47)));
    set(handles.l_8_edit,'String',num2str(handles.ANS.values(52)));
    handles.ANS.fixed(17:5:52) = 1;
    set(handles.l_1_checkbox,'Value',~handles.ANS.fixed(17));
    set(handles.l_2_checkbox,'Value',~handles.ANS.fixed(22));
    set(handles.l_3_checkbox,'Value',~handles.ANS.fixed(27));
    set(handles.l_4_checkbox,'Value',~handles.ANS.fixed(32));
    set(handles.l_5_checkbox,'Value',~handles.ANS.fixed(37));
    set(handles.l_6_checkbox,'Value',~handles.ANS.fixed(42));
    set(handles.l_7_checkbox,'Value',~handles.ANS.fixed(47));
    set(handles.l_8_checkbox,'Value',~handles.ANS.fixed(52));
    set(handles.l_1_checkbox,'Visible','off');
    set(handles.l_2_checkbox,'Visible','off');
    set(handles.l_3_checkbox,'Visible','off');
    set(handles.l_4_checkbox,'Visible','off');
    set(handles.l_5_checkbox,'Visible','off');
    set(handles.l_6_checkbox,'Visible','off');
    set(handles.l_7_checkbox,'Visible','off');
    set(handles.l_8_checkbox,'Visible','off');  
    set(handles.l_1_edit,'Style','text');
    set(handles.l_2_edit,'Style','text');
    set(handles.l_3_edit,'Style','text');
    set(handles.l_4_edit,'Style','text');
    set(handles.l_5_edit,'Style','text');
    set(handles.l_6_edit,'Style','text');
    set(handles.l_7_edit,'Style','text');
    set(handles.l_8_edit,'Style','text');
end
% FINISH
guidata(hObject, handles);

% --- Executes on button press in variable_checkbox.
function variable_checkbox_Callback(hObject, ~, handles)
% hObject    handle to variable_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of variable_checkbox
temp = get(hObject,'Value');
if temp
    handles.ANS.values(13) = 8;
    set(handles.gaussian_checkbox,'Value',0);
    set(handles.rice_checkbox,'Value',0); 
    set(handles.skewed_checkbox,'Value',0);
    set(handles.GSND_checkbox,'Value',0);                      
    handles.ANS.fixed(linspace(16,16+(handles.PARAM.ng - 1)*5, ...
        handles.PARAM.ng)) = 0;
    set(handles.b_1_checkbox,'Value',~handles.ANS.fixed(16));
    set(handles.b_2_checkbox,'Value',~handles.ANS.fixed(21));
    set(handles.b_3_checkbox,'Value',~handles.ANS.fixed(26));
    set(handles.b_4_checkbox,'Value',~handles.ANS.fixed(31));
    set(handles.b_5_checkbox,'Value',~handles.ANS.fixed(36));
    set(handles.b_6_checkbox,'Value',~handles.ANS.fixed(41));
    set(handles.b_7_checkbox,'Value',~handles.ANS.fixed(46));
    set(handles.b_8_checkbox,'Value',~handles.ANS.fixed(51));
    if handles.PARAM.ng > 0; set(handles.b_1_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 1; set(handles.b_2_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 2; set(handles.b_3_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 3; set(handles.b_4_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 4; set(handles.b_5_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 5; set(handles.b_6_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 6; set(handles.b_7_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 7; set(handles.b_8_checkbox,'Visible','on'); end
    set(handles.b_1_edit,'Style','edit');
    set(handles.b_2_edit,'Style','edit');
    set(handles.b_3_edit,'Style','edit');
    set(handles.b_4_edit,'Style','edit');
    set(handles.b_5_edit,'Style','edit');
    set(handles.b_6_edit,'Style','edit');
    set(handles.b_7_edit,'Style','edit');
    set(handles.b_8_edit,'Style','edit');
    index = 16;
    handles.ANS.lowerlimit(index) =  0.25;
    handles.ANS.upperlimit(index) = 25.00;
    index = 21;
    handles.ANS.lowerlimit(index) =  0.25;
    handles.ANS.upperlimit(index) = 25.00;
    index = 26;
    handles.ANS.lowerlimit(index) =  0.25;
    handles.ANS.upperlimit(index) = 25.00;
    index = 31;
    handles.ANS.lowerlimit(index) =  0.25;
    handles.ANS.upperlimit(index) = 25.00;
    index = 36;
    handles.ANS.lowerlimit(index) =  0.25;
    handles.ANS.upperlimit(index) = 25.00;
    index = 41;
    handles.ANS.lowerlimit(index) =  0.25;
    handles.ANS.upperlimit(index) = 25.00;
    index = 46;
    handles.ANS.lowerlimit(index) =  0.25;
    handles.ANS.upperlimit(index) = 25.00;
    index = 51;
    handles.ANS.lowerlimit(index) =  0.25;
    handles.ANS.upperlimit(index) = 25.00;
    %
    handles.ANS.values(17:5:52) = 0.; 
    set(handles.l_1_edit,'String',num2str(handles.ANS.values(17)));
    set(handles.l_2_edit,'String',num2str(handles.ANS.values(22)));
    set(handles.l_3_edit,'String',num2str(handles.ANS.values(27)));
    set(handles.l_4_edit,'String',num2str(handles.ANS.values(32)));
    set(handles.l_5_edit,'String',num2str(handles.ANS.values(37)));
    set(handles.l_6_edit,'String',num2str(handles.ANS.values(42)));
    set(handles.l_7_edit,'String',num2str(handles.ANS.values(47)));
    set(handles.l_8_edit,'String',num2str(handles.ANS.values(52)));
    handles.ANS.fixed(17:5:52) = 1;
    set(handles.l_1_checkbox,'Value',~handles.ANS.fixed(17));
    set(handles.l_2_checkbox,'Value',~handles.ANS.fixed(22));
    set(handles.l_3_checkbox,'Value',~handles.ANS.fixed(27));
    set(handles.l_4_checkbox,'Value',~handles.ANS.fixed(32));
    set(handles.l_5_checkbox,'Value',~handles.ANS.fixed(37));
    set(handles.l_6_checkbox,'Value',~handles.ANS.fixed(42));
    set(handles.l_7_checkbox,'Value',~handles.ANS.fixed(47));
    set(handles.l_8_checkbox,'Value',~handles.ANS.fixed(52));
    set(handles.l_1_checkbox,'Visible','off');
    set(handles.l_2_checkbox,'Visible','off');
    set(handles.l_3_checkbox,'Visible','off');
    set(handles.l_4_checkbox,'Visible','off');
    set(handles.l_5_checkbox,'Visible','off');
    set(handles.l_6_checkbox,'Visible','off');
    set(handles.l_7_checkbox,'Visible','off');
    set(handles.l_8_checkbox,'Visible','off');  
    set(handles.l_1_edit,'Style','text');
    set(handles.l_2_edit,'Style','text');
    set(handles.l_3_edit,'Style','text');
    set(handles.l_4_edit,'Style','text');
    set(handles.l_5_edit,'Style','text');
    set(handles.l_6_edit,'Style','text');
    set(handles.l_7_edit,'Style','text');
    set(handles.l_8_edit,'Style','text');
end
% FINISH
guidata(hObject, handles);

% --- Executes on button press in skewed_checkbox.
function skewed_checkbox_Callback(hObject, ~, handles)
% hObject    handle to skewed_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of skewed_checkbox
temp = get(hObject,'Value');
if temp
    handles.ANS.values(13) = 9;
    set(handles.gaussian_checkbox,'Value',0);
    set(handles.rice_checkbox,'Value',0); 
    set(handles.variable_checkbox,'Value',0);
    set(handles.GSND_checkbox,'Value',0);
    %
    handles.ANS.values(16:5:51) = 2.; 
    set(handles.b_1_edit,'String',num2str(handles.ANS.values(16)));
    set(handles.b_2_edit,'String',num2str(handles.ANS.values(21)));
    set(handles.b_3_edit,'String',num2str(handles.ANS.values(26)));
    set(handles.b_4_edit,'String',num2str(handles.ANS.values(31)));
    set(handles.b_5_edit,'String',num2str(handles.ANS.values(36)));
    set(handles.b_6_edit,'String',num2str(handles.ANS.values(41)));
    set(handles.b_7_edit,'String',num2str(handles.ANS.values(46)));
    set(handles.b_8_edit,'String',num2str(handles.ANS.values(51)));
    handles.ANS.fixed(16:5:51) = 1;
    set(handles.b_1_checkbox,'Value',~handles.ANS.fixed(16));
    set(handles.b_2_checkbox,'Value',~handles.ANS.fixed(21));
    set(handles.b_3_checkbox,'Value',~handles.ANS.fixed(26));
    set(handles.b_4_checkbox,'Value',~handles.ANS.fixed(31));
    set(handles.b_5_checkbox,'Value',~handles.ANS.fixed(36));
    set(handles.b_6_checkbox,'Value',~handles.ANS.fixed(41));
    set(handles.b_7_checkbox,'Value',~handles.ANS.fixed(46));
    set(handles.b_8_checkbox,'Value',~handles.ANS.fixed(51));
    set(handles.b_1_checkbox,'Visible','off');
    set(handles.b_2_checkbox,'Visible','off');
    set(handles.b_3_checkbox,'Visible','off');
    set(handles.b_4_checkbox,'Visible','off');
    set(handles.b_5_checkbox,'Visible','off');
    set(handles.b_6_checkbox,'Visible','off');
    set(handles.b_7_checkbox,'Visible','off');
    set(handles.b_8_checkbox,'Visible','off');  
    set(handles.b_1_edit,'Style','text');
    set(handles.b_2_edit,'Style','text');
    set(handles.b_3_edit,'Style','text');
    set(handles.b_4_edit,'Style','text');
    set(handles.b_5_edit,'Style','text');
    set(handles.b_6_edit,'Style','text');
    set(handles.b_7_edit,'Style','text');
    set(handles.b_8_edit,'Style','text');
    %
    handles.ANS.fixed(linspace(17,17+(handles.PARAM.ng - 1)*5, ...
        handles.PARAM.ng)) = 0;
    set(handles.l_1_checkbox,'Value',~handles.ANS.fixed(17));
    set(handles.l_2_checkbox,'Value',~handles.ANS.fixed(22));
    set(handles.l_3_checkbox,'Value',~handles.ANS.fixed(27));
    set(handles.l_4_checkbox,'Value',~handles.ANS.fixed(32));
    set(handles.l_5_checkbox,'Value',~handles.ANS.fixed(37));
    set(handles.l_6_checkbox,'Value',~handles.ANS.fixed(42));
    set(handles.l_7_checkbox,'Value',~handles.ANS.fixed(47));
    set(handles.l_8_checkbox,'Value',~handles.ANS.fixed(52));
    if handles.PARAM.ng > 0; set(handles.l_1_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 1; set(handles.l_2_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 2; set(handles.l_3_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 3; set(handles.l_4_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 4; set(handles.l_5_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 5; set(handles.l_6_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 6; set(handles.l_7_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 7; set(handles.l_8_checkbox,'Visible','on'); end
    set(handles.l_1_edit,'Style','edit');
    set(handles.l_2_edit,'Style','edit');
    set(handles.l_3_edit,'Style','edit');
    set(handles.l_4_edit,'Style','edit');
    set(handles.l_5_edit,'Style','edit');
    set(handles.l_6_edit,'Style','edit');
    set(handles.l_7_edit,'Style','edit');
    set(handles.l_8_edit,'Style','edit');
    for i = 17:5:52 
        handles.ANS.lowerlimit(i) = -10.;
        handles.ANS.upperlimit(i) = +10.;
    end
end
% FINISH
guidata(hObject, handles);

% --- Executes on button press in exponential_checkbox.
function exponential_checkbox_Callback(hObject, ~, handles)
% hObject    handle to exponential_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of exponential_checkbox
temp = get(hObject,'Value');
if temp
    set(handles.calculated_checkbox,'Value',0);
    %
    [ handles ] = set_exponential( handles );
else
    set(handles.calculated_checkbox,'Value',1);
    %
    [ handles ] = set_calculated( handles );
end
%
clear handles.CI.data;
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

function lambda_edit_Callback(hObject, ~, handles)
% hObject    handle to lambda_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of lambda_edit as text
%        str2double(get(hObject,'String')) returns contents of lambda_edit
index = 6;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function lambda_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to lambda_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in lambda_checkbox.
function lambda_checkbox_Callback(hObject, ~, handles)
% hObject    handle to lambda_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of lambda_checkbox
index = 6;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function d_edit_Callback(hObject, ~, handles)
% hObject    handle to d_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of d_edit as text
%        str2double(get(hObject,'String')) returns contents of d_edit
index = 7;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function d_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to d_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in d_checkbox.
function d_checkbox_Callback(hObject, ~, handles)
% hObject    handle to d_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of d_checkbox
index = 7;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in calculated_checkbox.
function calculated_checkbox_Callback(hObject, ~, handles)
% hObject    handle to calculated_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of calculated_checkbox
temp = get(hObject,'Value');
if ~temp
    set(handles.exponential_checkbox,'Value',1);
    %
    [ handles ] = set_exponential( handles );
else
    set(handles.exponential_checkbox,'Value',0);
    %
    [ handles ] = set_calculated( handles );
end
%
clear handles.CI.data;
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

function concentration_edit_Callback(hObject, ~, handles)
% hObject    handle to concentration_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of concentration_edit as text
%        str2double(get(hObject,'String')) returns contents of concentration_edit
index = 9;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function concentration_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to concentration_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in concentration_checkbox.
function concentration_checkbox_Callback(hObject, ~, handles)
% hObject    handle to concentration_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of concentration_checkbox
index = 9;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function rho_edit_Callback(hObject, ~, handles)
% hObject    handle to rho_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of rho_edit as text
%        str2double(get(hObject,'String')) returns contents of rho_edit
index = 10;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function rho_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to rho_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in rho_checkbox.
function rho_checkbox_Callback(hObject, ~, handles)
% hObject    handle to rho_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of rho_checkbox
index = 10;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function b_depth_edit_Callback(hObject, ~, handles)
% hObject    handle to b_depth_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of b_depth_edit as text
%        str2double(get(hObject,'String')) returns contents of b_depth_edit
index = 8;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function b_depth_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to b_depth_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in b_depth_checkbox.
function b_depth_checkbox_Callback(hObject, ~, handles)
% hObject    handle to b_depth_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of b_depth_checkbox
index = 8;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in link_depth_checkbox.
function link_depth_checkbox_Callback(hObject, ~, handles)
% hObject    handle to link_depth_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of link_depth_checkbox
temp = get(hObject,'Value');
if temp
    handles.ANS.links(8) = 5;
else
    handles.ANS.links(8) = 0;
end
% FINISH
guidata(hObject, handles);

function deltaR_edit_Callback(hObject, ~, handles)
% hObject    handle to deltaR_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of deltaR_edit as text
%        str2double(get(hObject,'String')) returns contents of deltaR_edit
index = 1;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function deltaR_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to deltaR_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Rmax_edit_Callback(hObject, ~, handles)
% hObject    handle to Rmax_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of Rmax_edit as text
%        str2double(get(hObject,'String')) returns contents of Rmax_edit
index = 2;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function Rmax_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to Rmax_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Rsphere_edit_Callback(hObject, ~, handles)
% hObject    handle to Rsphere_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of Rsphere_edit as text
%        str2double(get(hObject,'String')) returns contents of Rsphere_edit
index = 3;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function Rsphere_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to Rsphere_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function deltaR_b_edit_Callback(hObject, ~, handles)
% hObject    handle to deltaR_b_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of deltaR_b_edit as text
%        str2double(get(hObject,'String')) returns contents of deltaR_b_edit

% --- Executes during object creation, after setting all properties.
index = 4;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

function deltaR_b_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to deltaR_b_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in depth_checkbox.
function depth_checkbox_Callback(hObject, ~, handles)
% hObject    handle to depth_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of depth_checkbox
index = 5;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function depth_edit_Callback(hObject, ~, handles)
% hObject    handle to depth_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of depth_edit as text
%        str2double(get(hObject,'String')) returns contents of depth_edit
% --- Executes when figureDD is resized.
index = 5;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function depth_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to depth_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in scale_checkbox.
function scale_checkbox_Callback(hObject, ~, handles)
% hObject    handle to scale_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of scale_checkbox
index = 11;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function scale_edit_Callback(hObject, ~, handles)
% hObject    handle to scale_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of scale_edit as text
%        str2double(get(hObject,'String')) returns contents of scale_edit
index = 11;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

function time_shift_edit_Callback(hObject, ~, handles)
% hObject    handle to time_shift_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of time_shift_edit as text
%        str2double(get(hObject,'String')) returns contents of time_shift_edit
index = 12;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes on button press in time_shift_checkbox.
function time_shift_checkbox_Callback(hObject, ~, handles)
% hObject    handle to time_shift_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of time_shift_checkbox
index = 12;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in options_pushbutton.
function options_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to options_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
TabbedTables_GUI(hObject,eventdata,handles);

% --- Executes on button press in limits_pushbutton.
function limits_pushbutton_Callback(hObject, ~, handles)
% hObject    handle to limits_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
gui_temp = limits_gui_DD(handles.ANS.names,handles.ANS.lowerlimit', ...
  handles.ANS.upperlimit');
h_temp = guidata(gui_temp);
% this next line closes Figure
close(h_temp.figure1);
clear gui_temp;
handles.ANS.lowerlimit = h_temp.ll;
handles.ANS.upperlimit = h_temp.ul;
clear h_temp;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in initialize_pushbutton.
function initialize_pushbutton_Callback(hObject, ~, handles)
% hObject    handle to initialize_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Read in starting values from GUI
%--------------------------------------------------------------------------
%%
if ~isgraphics(handles.figureA) 
    set(handles.message_text,'String','Read and Process Data', ...
        'BackgroundColor',[0.8 0 0]);
    % FINISH
    guidata(hObject, handles);
    disp('First Read and Process Data');
    return;
end
try
  %% Suspend DD GUI
  GUI_Control(handles.figureDD,'off');
  %%
  set(handles.message_text,'String','Initializing', ...
    'BackgroundColor',[1 0.65 0.65]);
  drawnow;
  [handles] = Initialize(handles);
  %
  set(handles.message_text,'String','Fit Initialized', ...
    'BackgroundColor',[1.000 0.969 0.922]);
catch
  GUI_Control(handles.figureDD);
  set(handles.message_text,'String','Error Initializing', ...
    'BackgroundColor',[0.8 0.0 0.0]);
  drawnow;
end
%% Resume DD GUI
GUI_Control(handles.figureDD);
%%
% FINISH
guidata(hObject, handles);

% --- Executes on button press in fit_pushbutton.
function fit_pushbutton_Callback(hObject, ~, handles)
% hObject    handle to fit_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%%
if handles.status ~= 2
    set(handles.message_text,'String','First Initialize Fit', ...
        'BackgroundColor',[0.8 0 0]);
    % FINISH
    guidata(hObject, handles);
    disp('First Initialize Fit');
    return;
end
try
  %% Suspend DD GUI
  GUI_Control(handles.figureDD,'off');
  %% - Here is the section for fitting data -------------------------------
  set(handles.message_text,'String','Fit Running', ...
    'BackgroundColor',[1 0.65 0.65]);
  %%
  set(handles.static_text_22,'String',num2str(0.0));
  %%
  drawnow; 
  % 12/23/15 completely revised to combine all algorithms into one routine
  chisquaredhandle = ...
    @(floatvalues,extra)chisquared_DEER_driver_DD(floatvalues,handles);
  functionhandle = ...
    @(floatvalues,extra)fit_DEER_driver_DD(floatvalues,extra,handles);
  [handles, ~, endreason] = FITroutines_DD(chisquaredhandle, ...
    functionhandle, handles);
  %% - Finish Up ----------------------------------------------------------
  handles.status = 3;
  set(handles.message_text,'String',{endreason}, ...
    'ForegroundColor',[0 0.1 0.9],'BackgroundColor',[1 1 1]);
  [ handles ] = update_GUI_values( handles );
  % 03/16/2015 add determine_chi2
  [handles] = determine_chi2(handles);
  [ handles ] = Finalize( functionhandle, handles );
  %
  handles.ANS.fitbestvalues = handles.ANS.values;
  handles.DATA.fitbestchisquared = handles.DATA.totalchisquared;
  handles.DATA.fitbestunreducedtotalchisquared = ...
    handles.DATA.unreducedtotalchisquared;
catch
  GUI_Control(handles.figureDD);
  set(handles.message_text,'String','Error Fitting', ...
    'BackgroundColor',[0.8 0.0 0.0]);
  drawnow;
end
%
figure(handles.figureDD);
figure(handles.figureA);
% minimize_Desktop;
%% Resume DD GUI
GUI_Control(handles.figureDD);
%%
% FINISH 
guidata(hObject, handles);

% --- Executes on button press in confidence_interval_pushbutton.
function confidence_interval_pushbutton_Callback(hObject, ~, handles)
% hObject    handle to confidence_interval_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% SETUP -------------------------------------------------------------------
%%
clear handles.chibest handles.floatbest;
%
if handles.status < 4
    set(handles.message_text,'String','First Save Fit', ...
        'BackgroundColor',[0.8 0 0]);
    % FINISH
    guidata(hObject, handles);
    disp('First Save Fit');
    return;
end
try
  %% Suspend DD GUI
  GUI_Control(handles.figureDD,'off');
  %
  set(handles.message_text,'String','Confidence Interval Running', ...
    'BackgroundColor',[1 0.65 0.65]);
  drawnow;
  if isfield(handles.CI,'data')
    gui_temp = confidence_interval_gui( handles.FLOAT.floatnames, ...
      handles.FLOAT.float, handles.CI.uncertainty, ...
      handles.CI.stop, handles.CI.plot, handles.CI.bflag, ...
      handles.CI.cflag, handles.CI.data);
  else
    gui_temp = confidence_interval_gui( handles.FLOAT.floatnames, ...
      handles.FLOAT.float, handles.CI.uncertainty, ...
      handles.CI.stop, handles.CI.plot, handles.CI.bflag, ...
      handles.CI.cflag);
  end
  h_temp = guidata(gui_temp);
  % this next line closes Confidence Interval GUI
  close(h_temp.figure1);
  clear gui_temp;
  handles.CI.data = h_temp.data;
  handles.CI.plot = h_temp.plot;
  handles.CI.stop = h_temp.stop;
  handles.CI.bflag = h_temp.bflag;
  handles.CI.cflag = h_temp.cflag;
  clear h_temp;
  %
  handles.DATA.finalchisquared = handles.DATA.chisquared;
  handles.ANS.finalvalues = handles.ANS.values;
  %
  [ handles ] = run_confidence_interval( handles );
  %
  handles.ANS.values = handles.ANS.finalvalues;
  if handles.OPTIONS.OUTPUT.logical.output2Excel 
    %% KILL any existing EXCEL processe
    killExcel
    %%
    ExcelTrue = actxserver ('Excel.Application');
    set(ExcelTrue, 'Visible', 0);
    %% Check Office Version
    %  For Office 2010 or earlier 3 sheets are opened by default, for later
    %  versions only 1 sheet is opened
    office_version = ExcelTrue.Version;
    if office_version >= 15
      open_sheet = 1;
    else
      open_sheet = 3;
    end
    %
    WorkBook =  ExcelTrue.Workbooks.Open(handles.answerfile);
    Sheets = ExcelTrue.ActiveWorkbook.Sheets;
    % SHEET - Parameters(1)
    sheetname = 'PARAMETERS(1)';
    %% Make sure sheet already exists
    temp = sheet_names(ExcelTrue,Sheets);
    if ~all(~strcmp(temp,sheetname))
      invoke(ExcelTrue.ActiveWorkbook.Sheets.Item(sheetname),'Activate');
    else
      esheet = Sheets.Count;
      esheet = esheet + 1;
      if esheet > open_sheet
        Sheets.Add([], ...
          ExcelTrue.ActiveWorkbook.Sheets.Item(esheet-1));
      end
      invoke(get(Sheets, 'Item', esheet), 'Activate');
      ActiveSheet = ExcelTrue.Activesheet;  % Make sheet active
      ActiveSheet.Name = strcat(sheetname);
    end
    ActiveSheet = ExcelTrue.Activesheet;  % Make sheet active
    ActiveSheet.Name = strcat(sheetname);
    disp(ActiveSheet.Name);
    %
    q = {'confidence'};
    set(get(ActiveSheet,'Range', ExcelRange('I1',q)), 'Value', q);
    %
    q = handles.ANS.confidence;
    set(get(ActiveSheet,'Range', ExcelRange('I2',q)), 'Value', q);
    %
    q = {'start'};
    set(get(ActiveSheet,'Range', ExcelRange('J1',q)), 'Value', q);
    %
    q = handles.ANS.start;
    set(get(ActiveSheet,'Range', ExcelRange('J2',q)), 'Value', q);
    %
    q = {'end'};
    set(get(ActiveSheet,'Range', ExcelRange('K1',q)), 'Value', q);
    %
    q = handles.ANS.end;
    set(get(ActiveSheet,'Range', ExcelRange('K2',q)), 'Value', q);
    %
    q = {'increment'};
    set(get(ActiveSheet,'Range', ExcelRange('L1',q)), 'Value', q);
    %
    q = handles.ANS.increment;
    set(get(ActiveSheet,'Range', ExcelRange('L2',q)), 'Value', q);
    %
    q = {'Conf. Int.'};
    set(get(ActiveSheet,'Range', ExcelRange('N1',q)), 'Value', q);
    %
    q = handles.ANS.confbestvalues;
    set(get(ActiveSheet,'Range', ExcelRange('N2',q)), 'Value', q);
    %
    q = handles.DATA.confbestchisquared;
    set(get(ActiveSheet,'Range', ExcelRange('N39',q)), 'Value', q);
    %
    q = {datestr(clock)};
    set(get(ActiveSheet,'Range', ExcelRange('N41',q)), 'Value', q);
    %
    q = cellstr('68.3% = ');
    set(get(ActiveSheet,'Range', ExcelRange('M43',q)), 'Value', q);
    %
    q = cellstr('95.4% = ');
    set(get(ActiveSheet,'Range', ExcelRange('M44',q)), 'Value', q);
    %
    q = cellstr('99.7% = ');
    set(get(ActiveSheet,'Range', ExcelRange('M45',q)), 'Value', q);
    %
    q = handles.CI.target1s;
    set(get(ActiveSheet,'Range', ExcelRange('N43',q)), 'Value', q);
    %
    q = handles.CI.target2s;
    set(get(ActiveSheet,'Range', ExcelRange('N44',q)), 'Value', q);
    %
    q = handles.CI.target3s;
    set(get(ActiveSheet,'Range', ExcelRange('N45',q)), 'Value', q);
    %%
    sheet = get(Sheets, 'Item', 1);
    invoke(sheet, 'Activate');
    ExcelTrue.displayalerts = false;
    WorkBook.SaveAs(handles.answerfile);
    DeleteEmptyExcelSheets(handles.answerfile);
    invoke(ExcelTrue, 'Quit');
    delete(ExcelTrue);
    %%
  end
  if handles.OPTIONS.OUTPUT.logical.output2ASCII
    outfile = strcat(handles.answerfile(1:strfind(handles.answerfile,'.')-1),...
      '_','results','.dat');
    fid = fopen(outfile,'w');
    fprintf(' \n %s %s \n',outfile,'is open.');
    fprintf(fid,' %s \n',handles.answerfile);
    fprintf(fid,' %s \n \n',char(handles.DATA.name));
    fprintf(fid,' %s \n','      name                 value   fix link initial        CI');
    for n = 1:handles.ANS.nparam
      fprintf(fid,'\n %2.0f %20s %10.5g %2.0f %2.0f %10.5g %10.5g',...
        n, char(handles.ANS.names(n,:)), handles.ANS.values(n), ...
        handles.ANS.fixed(n), handles.ANS.links(n), ...
        handles.ANS.initialvalues(n), handles.ANS.confbestvalues(n) );
    end
    fprintf(fid,' \n \n %s %12.5f \n','chisquared = ', ...
      handles.DATA.chisquared);
    
    fprintf(fid,' \n \n %s %12.5f \n','Initial Chisquared = ', ...
      handles.DATA.initialchisquared);
    fprintf(fid,' %s %3.0f \n','Iterations = ',handles.iter);
    fprintf(fid,' %s \n',datestr(clock));
    fprintf(fid,' %s %12.5f \n','Final Chisquared = ', ...
      handles.DATA.finalchisquared);
    fprintf(fid,' %s %12.5f \n','Best Confidence Interval Chisquared = ', ...
      handles.DATA.confbestchisquared);
    fclose(fid);
    fprintf(' \n %s %s \n',outfile,'is closed.');
  end
  set(handles.message_text,'String','Confidence Interval Complete', ...
    'BackgroundColor',[1 1 1]);
  handles.status = 5;
  handles.figureCBa = ...
      confidence_bands_A_GUI(handles,'WindowsStyle','normal');
  [t1,~,~] = fileparts(handles.answerfile);
  q = [t1 handles.sep 'A.pdf'];
  saveas(handles.figureCBa, q);
catch
  GUI_Control(handles.figureDD);
  set(handles.message_text,'String','Error', ...
    'BackgroundColor',[0.8 0.0 0.0]);
  drawnow;
end
%% Resume DD GUI
GUI_Control(handles.figureDD);
%%
% FINISH
guidata(hObject, handles);

% --- Executes on button press in transfer_pushbutton.
function transfer_pushbutton_Callback(hObject, ~, handles)
% hObject    handle to transfer_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if handles.DATA.confbestchisquared < handles.DATA.fitbestchisquared 
    handles.ANS.values = handles.ANS.confbestvalues;
else
    handles.ANS.values = handles.ANS.fitbestvalues;
end
%
[ handles ] = update_GUI_values( handles );
%
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

function figureDD_ResizeFcn(~, ~, ~)
% hObject    handle to figureDD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- Executes on button press in write_pushbutton.
function write_pushbutton_Callback(hObject, ~, handles)
% hObject    handle to write_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Call function to write results to answerfile (Excel file)
if handles.status ~= 3
  set(handles.message_text,'String','Run Fit', ...
    'BackgroundColor',[0.8 0 0]);
  disp('First Run Fit');
else 
  try
    % Suspend DD GUI
    GUI_Control(handles.figureDD,'off');
    %%
    set(handles.message_text,'String','Writing Output', ...
      'BackgroundColor',[1 0.65 0.65]);
    drawnow;
    disp('Writing Output');
    
    [ handles ] = output_DD( handles );
    handles.status = 4;
    set(handles.message_text,'String','Fit Saved', ...
      'BackgroundColor',[1 1 1]);
  catch
    GUI_Control(handles.figureDD);
    set(handles.message_text,'String','Error Writing', ...
                     'BackgroundColor',[0.8 0.0 0.0]);
  drawnow;
  end
  %% Resume DD GUI
  GUI_Control(handles.figureDD);
end
%%
% FINISH
guidata(hObject, handles);

function answerfile_text_Callback(hObject, ~, handles)
% hObject    handle to answerfile_text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of answerfile_text as text
%        str2double(get(hObject,'String')) returns contents of answerfile_text as a double
handles.answerfile = get(hObject,'String');
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function figureDD_CreateFcn(~, ~, ~)
% hObject    handle to figureDD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% --- Executes on button press in write_plot_checkbox.
function write_plot_checkbox_Callback(~, ~, ~)
% hObject    handle to write_plot_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of write_plot_checkbox

% --- Executes on button press in filename_update_checkbox.
function filename_update_checkbox_Callback(~, ~, ~)
% hObject    handle to filename_update_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of filename_update_checkbox

% --- Executes on button press in save_statistics_pushbutton.
function save_statistics_pushbutton_Callback(hObject, ~, handles)
% hObject    handle to save_statistics_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%
[handles] = save_statistics_function(handles);
set(handles.message_text,'String','Statistics Saved', ...
    'BackgroundColor',[1 1 1]);
% FINISH
guidata(hObject, handles); 

% --- Executes on button press in list_statistics_pushbutton.
function list_statistics_pushbutton_Callback(hObject, ~, handles)
% hObject    handle to list_statistics_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%__________________________________________________________________________
% modified 6/2/2018 to fix sort/delete row issues - EJH
%% Suspend DD GUI
GUI_Control(handles.figureDD,'off');
%%
save = handles.save_statistics;
if ~isempty(handles.save_statistics)
  [gui_temp] = list_statistics_gui_DD(handles);
  try
    h_temp = guidata(gui_temp);
    try
     handles.save_statistics = h_temp.list_statistics_uitable.Data(:,1:13);
    catch
     handles.save_statistics = {};
    end
    % this next line closes Figure
    close(h_temp.figure1);
    clear gui_temp;
    clear h_temp;
    set(handles.message_text,'String','OK','BackgroundColor',[1 1 1]);
  catch
    handles.save_statistics = save;
    set(handles.message_text,'String', ...
      'use QUIT button to save changes to statistics', ...
      'BackgroundColor',[0.8 0 0]);
  end
else
  set(handles.message_text,'String','No statistics to save yet', ...
    'BackgroundColor',[0.8 0 0]);
end
%% Resume DD GUI
GUI_Control(handles.figureDD);
%%
% FINISH
guidata(hObject, handles);

% --- Executes on button press in r_pushbutton.
function r_pushbutton_Callback(hObject, ~, handles)
% hObject    handle to r_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
matrix = [handles.PARAM.r0(1:handles.PARAM.ng)', ...
  handles.PARAM.width(1:handles.PARAM.ng)', ...
  handles.PARAM.beta(1:handles.PARAM.ng)', ...
  handles.PARAM.zeta(1:handles.PARAM.ng)', ...
  handles.HOLD.normamp(1:handles.PARAM.ng)'];
matrix = sortrows(matrix,1);
handles.ANS.values(14:5: 9+handles.PARAM.ng*5) = matrix(:,1)';
handles.ANS.values(15:5:10+handles.PARAM.ng*5) = matrix(:,2)';
handles.ANS.values(16:5:11+handles.PARAM.ng*5) = matrix(:,3)';
handles.ANS.values(17:5:12+handles.PARAM.ng*5) = matrix(:,4)';
temp = matrix(:,5)';
factor = 1.
for i= 2:handles.PARAM.ng
  handles.ANS.values(13 + i*5) = 1 - (temp(i-1)/factor);
  factor = factor*handles.ANS.values(13 + i*5);
end
%
[ handles ] = update_GUI_values( handles );
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes on button press in s_pushbutton.
function s_pushbutton_Callback(hObject, ~, handles)
% hObject    handle to s_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
matrix = [handles.PARAM.r0(1:handles.PARAM.ng)', ...
  handles.PARAM.width(1:handles.PARAM.ng)', ...
  handles.PARAM.beta(1:handles.PARAM.ng)', ...
  handles.PARAM.zeta(1:handles.PARAM.ng)', ...
  handles.HOLD.normamp(1:handles.PARAM.ng)'];
matrix = sortrows(matrix,2);
handles.ANS.values(14:5: 9+handles.PARAM.ng*5) = matrix(:,1)';
handles.ANS.values(15:5:10+handles.PARAM.ng*5) = matrix(:,2)';
handles.ANS.values(16:5:11+handles.PARAM.ng*5) = matrix(:,3)';
handles.ANS.values(17:5:12+handles.PARAM.ng*5) = matrix(:,4)';
temp = matrix(:,5)';
factor = 1.;
for i= 2:handles.PARAM.ng
  handles.ANS.values(13 + i*5) = 1 - (temp(i-1)/factor);
  factor = factor*handles.ANS.values(13 + i*5);
end
%
[ handles ] = update_GUI_values( handles );
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes on button press in a_pushbutton.
function a_pushbutton_Callback(hObject, ~, handles)
% hObject    handle to a_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
matrix = [handles.PARAM.r0(1:handles.PARAM.ng)', ...
  handles.PARAM.width(1:handles.PARAM.ng)', ...
  handles.PARAM.beta(1:handles.PARAM.ng)', ...
  handles.PARAM.zeta(1:handles.PARAM.ng)', ...
  handles.HOLD.normamp(1:handles.PARAM.ng)'];
matrix = sortrows(matrix,-5);
handles.ANS.values(14:5: 9+handles.PARAM.ng*5) = matrix(:,1)';
handles.ANS.values(15:5:10+handles.PARAM.ng*5) = matrix(:,2)';
handles.ANS.values(16:5:11+handles.PARAM.ng*5) = matrix(:,3)';
handles.ANS.values(17:5:12+handles.PARAM.ng*5) = matrix(:,4)';
temp = matrix(:,5)';
factor = 1.;
for i= 2:handles.PARAM.ng
  handles.ANS.values(13 + i*5) = 1 - (temp(i-1)/factor);
  factor = factor*handles.ANS.values(13 + i*5);
end
%
[ handles ] = update_GUI_values( handles );
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes on button press in split_2_pushbutton.
function split_2_pushbutton_Callback(hObject, ~, handles)
% hObject    handle to split_2_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[ handles ] = split_function( handles, 19 );
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in split_3_pushbutton.
function split_3_pushbutton_Callback(hObject, ~, handles)
% hObject    handle to split_3_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[ handles ] = split_function( handles, 24 );
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in split_4_pushbutton.
function split_4_pushbutton_Callback(hObject, ~, handles)
% hObject    handle to split_4_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[ handles ] = split_function( handles, 29 );
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in split_5_pushbutton.
function split_5_pushbutton_Callback(hObject, ~, handles)
% hObject    handle to split_5_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[ handles ] = split_function( handles, 34 );
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in split_6_pushbutton.
function split_6_pushbutton_Callback(hObject, ~, handles)
% hObject    handle to split_6_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[ handles ] = split_function( handles, 39 );
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in split_7_pushbutton.
function split_7_pushbutton_Callback(hObject, ~, handles)
% hObject    handle to split_7_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[ handles ] = split_function( handles, 44 );
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function truncate_end_edit_Callback(hObject, ~, handles)
% hObject    handle to truncate_end_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of truncate_end_edit as text
%        str2double(get(hObject,'String')) returns contents of truncate_end_edit as a double
handles.OPTIONS.MISC.numeric.truncate_end = str2num(get(hObject,'String'));
handles = Process(handles);
handles = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function truncate_end_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to truncate_end_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function truncate_start_edit_Callback(hObject, ~, handles)
% hObject    handle to truncate_start_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of truncate_start_edit as text
%        str2double(get(hObject,'String')) returns contents of truncate_start_edit as a double
handles.OPTIONS.MISC.numeric.truncate_start = str2num(get(hObject,'String'));
handles = Process(handles);
handles = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function truncate_start_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to truncate_start_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in restrict_lambda_checkbox.
function restrict_lambda_checkbox_Callback(hObject, ~, handles)
% hObject    handle to restrict_lambda_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of restrict_lambda_checkbox
if get(hObject,'Value')
  handles.ANS.lowerlimit(6) = 0.95*handles.ANS.values(6);
  handles.ANS.upperlimit(6) = 1.05*handles.ANS.values(6);
else
  handles.ANS.lowerlimit(6) = 1;
  handles.ANS.upperlimit(6) = 6;
end 
% FINISH
guidata(hObject, handles); 

% --- Executes on button press in restrict_depth_checkbox.
function restrict_depth_checkbox_Callback(hObject, ~, handles)
% hObject    handle to restrict_depth_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of restrict_depth_checkbox
if get(hObject,'Value')
  handles.ANS.lowerlimit(5) = 0.9*handles.ANS.values(5);
  handles.ANS.upperlimit(5) = 1.1*handles.ANS.values(5);
else
  handles.ANS.lowerlimit(5) = 0.0;
  handles.ANS.upperlimit(5) = 0.5;
end
% FINISH
guidata(hObject, handles); 

function b_1_edit_Callback(hObject, ~, handles)
% hObject    handle to b_1_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of b_1_edit as text
%        str2double(get(hObject,'String')) returns contents of b_1_edit as a double
index = 16;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function b_1_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to b_1_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function b_2_edit_Callback(hObject, ~, handles)
% hObject    handle to b_2_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of b_2_edit as text
%        str2double(get(hObject,'String')) returns contents of b_2_edit as a double
index = 21;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function b_2_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to b_2_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function b_3_edit_Callback(hObject, ~, handles)
% hObject    handle to b_3_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of b_3_edit as text
%        str2double(get(hObject,'String')) returns contents of b_3_edit as a double
index = 26;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function b_3_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to b_3_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function b_4_edit_Callback(hObject, ~, handles)
% hObject    handle to b_4_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of b_4_edit as text
%        str2double(get(hObject,'String')) returns contents of b_4_edit as a double
index = 31;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function b_4_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to b_4_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function b_5_edit_Callback(hObject, ~, handles)
% hObject    handle to b_5_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of b_5_edit as text
%        str2double(get(hObject,'String')) returns contents of b_5_edit as a double
index = 36;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function b_5_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to b_5_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function b_6_edit_Callback(hObject, ~, handles)
% hObject    handle to b_6_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of b_6_edit as text
%        str2double(get(hObject,'String')) returns contents of b_6_edit as a double
index = 41;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function b_6_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to b_6_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function b_7_edit_Callback(hObject, ~, handles)
% hObject    handle to b_7_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of b_7_edit as text
%        str2double(get(hObject,'String')) returns contents of b_7_edit as a double
index = 46;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function b_7_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to b_7_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function b_8_edit_Callback(hObject, ~, handles)
% hObject    handle to b_8_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of b_8_edit as text
%        str2double(get(hObject,'String')) returns contents of b_8_edit as a double
index = 51;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function b_8_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to b_8_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in b_1_checkbox.
function b_1_checkbox_Callback(hObject, ~, handles)
% hObject    handle to b_1_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of b_1_checkbox
index = 16;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in b_2_checkbox.
function b_2_checkbox_Callback(hObject, ~, handles)
% hObject    handle to b_2_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of b_2_checkbox
index = 21;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in b_3_checkbox.
function b_3_checkbox_Callback(hObject, ~, handles)
% hObject    handle to b_3_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of b_3_checkbox
index = 26;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in b_4_checkbox.
function b_4_checkbox_Callback(hObject, ~, handles)
% hObject    handle to b_4_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of b_4_checkbox
index = 31;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in b_5_checkbox.
function b_5_checkbox_Callback(hObject, ~, handles)
% hObject    handle to b_5_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of b_5_checkbox
index = 36;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in b_6_checkbox.
function b_6_checkbox_Callback(hObject, ~, handles)
% hObject    handle to b_6_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of b_6_checkbox
index = 41;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in b_7_checkbox.
function b_7_checkbox_Callback(hObject, ~, handles)
% hObject    handle to b_7_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of b_7_checkbox
index = 46;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in b_8_checkbox.
function b_8_checkbox_Callback(hObject, ~, handles)
% hObject    handle to b_8_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of b_8_checkbox
index = 51;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

function l_1_edit_Callback(hObject, ~, handles)
% hObject    handle to l_1_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of l_1_edit as text
%        str2double(get(hObject,'String')) returns contents of l_1_edit as a double
index = 17;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function l_1_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to l_1_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function l_2_edit_Callback(hObject, ~, handles)
% hObject    handle to l_2_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of l_2_edit as text
%        str2double(get(hObject,'String')) returns contents of l_2_edit as a double
index = 22;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function l_2_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to l_2_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function l_3_edit_Callback(hObject, ~, handles)
% hObject    handle to l_3_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of l_3_edit as text
%        str2double(get(hObject,'String')) returns contents of l_3_edit as a double
index = 27;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function l_3_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to l_3_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function l_4_edit_Callback(hObject, ~, handles)
% hObject    handle to l_4_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of l_4_edit as text
%        str2double(get(hObject,'String')) returns contents of l_4_edit as a double
index = 32;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function l_4_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to l_4_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function l_5_edit_Callback(hObject, ~, handles)
% hObject    handle to l_5_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of l_5_edit as text
%        str2double(get(hObject,'String')) returns contents of l_5_edit as a double
index = 37;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function l_5_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to l_5_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function l_6_edit_Callback(hObject, ~, handles)
% hObject    handle to l_6_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of l_6_edit as text
%        str2double(get(hObject,'String')) returns contents of l_6_edit as a double
index = 42;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function l_6_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to l_6_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function l_7_edit_Callback(hObject, ~, handles)
% hObject    handle to l_7_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of l_7_edit as text
%        str2double(get(hObject,'String')) returns contents of l_7_edit as a double
index = 47;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function l_7_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to l_7_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function l_8_edit_Callback(hObject, ~, handles)
% hObject    handle to l_8_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of l_8_edit as text
%        str2double(get(hObject,'String')) returns contents of l_8_edit as a double
index = 52;
[ handles ] = update_value( hObject, handles, index );
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function l_8_edit_CreateFcn(hObject, ~, ~)
% hObject    handle to l_8_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in l_1_checkbox.
function l_1_checkbox_Callback(hObject, ~, handles)
% hObject    handle to l_1_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of l_1_checkbox
index = 17;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in l_2_checkbox.
function l_2_checkbox_Callback(hObject, ~, handles)
% hObject    handle to l_2_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of l_2_checkbox
index = 22;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in l_3_checkbox.
function l_3_checkbox_Callback(hObject, ~, handles)
% hObject    handle to l_3_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of l_3_checkbox
index = 27;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in l_4_checkbox.
function l_4_checkbox_Callback(hObject, ~, handles)
% hObject    handle to l_4_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of l_4_checkbox
index = 32;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in l_5_checkbox.
function l_5_checkbox_Callback(hObject, ~, handles)
% hObject    handle to l_5_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of l_5_checkbox
index = 37;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in l_6_checkbox.
function l_6_checkbox_Callback(hObject, ~, handles)
% hObject    handle to l_6_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of l_6_checkbox
index = 42;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in l_7_checkbox.
function l_7_checkbox_Callback(hObject, ~, handles)
% hObject    handle to l_7_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of l_7_checkbox
index = 47;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in l_8_checkbox.
function l_8_checkbox_Callback(hObject, ~, handles)
% hObject    handle to l_8_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of l_8_checkbox
index = 52;
handles.ANS.fixed(index) = ~get(hObject,'Value');
%
clear handles.CI.data;
% FINISH
guidata(hObject, handles);

% --- Executes on button press in GSND_checkbox.
function GSND_checkbox_Callback(hObject, ~, handles)
% hObject    handle to GSND_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of GSND_checkbox
temp = get(hObject,'Value');
if temp
    handles.ANS.values(13) = 10;
    set(handles.gaussian_checkbox,'Value',0);
    set(handles.rice_checkbox,'Value',0); 
    set(handles.variable_checkbox,'Value',0);
    set(handles.skewed_checkbox,'Value',0); 
    %
    handles.ANS.fixed(linspace(16,16+(handles.PARAM.ng - 1)*5, ...
        handles.PARAM.ng)) = 0;
    set(handles.b_1_checkbox,'Value',~handles.ANS.fixed(16));
    set(handles.b_2_checkbox,'Value',~handles.ANS.fixed(21));
    set(handles.b_3_checkbox,'Value',~handles.ANS.fixed(26));
    set(handles.b_4_checkbox,'Value',~handles.ANS.fixed(31));
    set(handles.b_5_checkbox,'Value',~handles.ANS.fixed(36));
    set(handles.b_6_checkbox,'Value',~handles.ANS.fixed(41));
    set(handles.b_7_checkbox,'Value',~handles.ANS.fixed(46));
    set(handles.b_8_checkbox,'Value',~handles.ANS.fixed(51));
    if handles.PARAM.ng > 0; set(handles.b_1_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 1; set(handles.b_2_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 2; set(handles.b_3_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 3; set(handles.b_4_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 4; set(handles.b_5_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 5; set(handles.b_6_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 6; set(handles.b_7_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 7; set(handles.b_8_checkbox,'Visible','on'); end
    set(handles.b_1_edit,'Style','edit');
    set(handles.b_2_edit,'Style','edit');
    set(handles.b_3_edit,'Style','edit');
    set(handles.b_4_edit,'Style','edit');
    set(handles.b_5_edit,'Style','edit');
    set(handles.b_6_edit,'Style','edit');
    set(handles.b_7_edit,'Style','edit');
    set(handles.b_8_edit,'Style','edit');
    index = 16;
    handles.ANS.lowerlimit(index) =  0.25;
    handles.ANS.upperlimit(index) = 25.00;
    index = 21;
    handles.ANS.lowerlimit(index) =  0.25;
    handles.ANS.upperlimit(index) = 25.00;
    index = 26;
    handles.ANS.lowerlimit(index) =  0.25;
    handles.ANS.upperlimit(index) = 25.00;
    index = 31;
    handles.ANS.lowerlimit(index) =  0.25;
    handles.ANS.upperlimit(index) = 25.00;
    index = 36;
    handles.ANS.lowerlimit(index) =  0.25;
    handles.ANS.upperlimit(index) = 25.00;
    index = 41;
    handles.ANS.lowerlimit(index) =  0.25;
    handles.ANS.upperlimit(index) = 25.00;
    index = 46;
    handles.ANS.lowerlimit(index) =  0.25;
    handles.ANS.upperlimit(index) = 25.00;
    index = 51;
    handles.ANS.lowerlimit(index) =  0.25;
    handles.ANS.upperlimit(index) = 25.00;
    %
    handles.ANS.fixed(linspace(17,17+(handles.PARAM.ng - 1)*5, ...
        handles.PARAM.ng)) = 0;
    set(handles.l_1_checkbox,'Value',~handles.ANS.fixed(17));
    set(handles.l_2_checkbox,'Value',~handles.ANS.fixed(22));
    set(handles.l_3_checkbox,'Value',~handles.ANS.fixed(27));
    set(handles.l_4_checkbox,'Value',~handles.ANS.fixed(32));
    set(handles.l_5_checkbox,'Value',~handles.ANS.fixed(37));
    set(handles.l_6_checkbox,'Value',~handles.ANS.fixed(42));
    set(handles.l_7_checkbox,'Value',~handles.ANS.fixed(47));
    set(handles.l_8_checkbox,'Value',~handles.ANS.fixed(52));
    if handles.PARAM.ng > 0; set(handles.l_1_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 1; set(handles.l_2_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 2; set(handles.l_3_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 3; set(handles.l_4_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 4; set(handles.l_5_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 5; set(handles.l_6_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 6; set(handles.l_7_checkbox,'Visible','on'); end
    if handles.PARAM.ng > 7; set(handles.l_8_checkbox,'Visible','on'); end
    set(handles.l_1_edit,'Style','edit');
    set(handles.l_2_edit,'Style','edit');
    set(handles.l_3_edit,'Style','edit');
    set(handles.l_4_edit,'Style','edit');
    set(handles.l_5_edit,'Style','edit');
    set(handles.l_6_edit,'Style','edit');
    set(handles.l_7_edit,'Style','edit');
    set(handles.l_8_edit,'Style','edit');
    for i = 17:5:52 
        handles.ANS.lowerlimit(i) = -10.;
        handles.ANS.upperlimit(i) = +10.;
    end
end
% FINISH
guidata(hObject, handles); 

% --- Executes on button press in restrict_r0_checkbox.
function restrict_r0_checkbox_Callback(hObject, ~, handles)
% hObject    handle to restrict_r0_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of restrict_r0_checkbox
if get(hObject,'Value')
  temp = (handles.DATA.deer_t(end)*5.204e10)^(1/3);
  handles.ANS.upperlimit(14) = temp;
  handles.ANS.upperlimit(19) = temp;
  handles.ANS.upperlimit(24) = temp;
  handles.ANS.upperlimit(29) = temp;
  handles.ANS.upperlimit(34) = temp;
  handles.ANS.upperlimit(39) = temp;
  handles.ANS.upperlimit(44) = temp;
  handles.ANS.upperlimit(49) = temp;
else
  temp = 80.;
  handles.ANS.upperlimit(14) = temp;
  handles.ANS.upperlimit(19) = temp;
  handles.ANS.upperlimit(24) = temp;
  handles.ANS.upperlimit(29) = temp;
  handles.ANS.upperlimit(34) = temp;
  handles.ANS.upperlimit(39) = temp;
  handles.ANS.upperlimit(44) = temp;
  handles.ANS.upperlimit(49) = temp;
end 
% FINISH

guidata(hObject, handles); 


function concentrationX_edit_Callback(hObject, eventdata, handles)
% hObject    handle to concentrationX_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of concentrationX_edit as text
%        str2double(get(hObject,'String')) returns contents of concentrationX_edit as a double
% --- Executes during object creation, after setting all properties.

% concX is display only concentration
temp1 = str2double(get(hObject,'String'));
temp2 = log10(1000*temp1*handles.ANS.values(5)); 
if temp2 < handles.ANS.lowerlimit(6)
  set(handles.message_text,'String','VALUE OUTSIDE OF RANGE', ...
    'BackgroundColor',[1 0.65 0.65]);
  lambda = handles.ANS.lowerlimit(6);
  concX = (10^lambda)*1.0e-03/handles.ANS.values(5); 
elseif temp2 > handles.ANS.upperlimit(6) 
  set(handles.message_text,'String','VALUE OUTSIDE OF RANGE', ...
    'BackgroundColor',[1 0.65 0.65]);
  lambda = handles.ANS.upperlimit(6);
  concX = (10^lambda)*1.0e-03/handles.ANS.values(5);
else
  set(handles.message_text,'String','OK', ...
    'BackgroundColor',[1 1 1]); 
  lambda = temp2;
  concX = temp1;
end
set(hObject,'String',num2str(concX));
set(handles.lambda_edit,'String',num2str(lambda));
handles.ANS.values(6) = lambda;
%% Set UP Initial Calculation
[handles] = Initialize(handles);
% FINISH
guidata(hObject, handles);


function concentrationX_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to concentrationX_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over fit_pushbutton.
function fit_pushbutton_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to fit_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in save_statistics_checkbox.
function save_statistics_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to save_statistics_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of save_statistics_checkbox
