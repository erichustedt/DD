function varargout = confidence_bands_B_GUI(varargin)
% CONFIDENCE_BANDS_B_GUI MATLAB code for confidence_bands_B_GUI.fig
%      CONFIDENCE_BANDS_B_GUI, by itself, creates a new CONFIDENCE_BANDS_B_GUI or raises the existing
%      singleton*.
%
%      H = CONFIDENCE_BANDS_B_GUI returns the handle to a new CONFIDENCE_BANDS_B_GUI or the handle to
%      the existing singleton*.
%
%      CONFIDENCE_BANDS_B_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CONFIDENCE_BANDS_B_GUI.M with the given input arguments.
%
%      CONFIDENCE_BANDS_B_GUI('Property','Value',...) creates a new CONFIDENCE_BANDS_B_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before confidence_bands_B_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to confidence_bands_B_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help confidence_bands_B_GUI

% Last Modified by GUIDE v2.5 08-Sep-2016 10:45:33

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @confidence_bands_B_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @confidence_bands_B_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before confidence_bands_B_GUI is made visible.
function confidence_bands_B_GUI_OpeningFcn(hObject, ~, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to confidence_bands_B_GUI (see VARARGIN)

% Choose default command line output for confidence_bands_B_GUI
handles.output = hObject;
CI = varargin{1};
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes confidence_bands_B_GUI wait for user response (see UIRESUME)
% uiwait(handles.figureCBb);


% --- Outputs from this function are returned to the command line.
function varargout = confidence_bands_B_GUI_OutputFcn(hObject, ~, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, ~, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1
cla;
CI = getappdata(0,'CI');
p = plot(CI.bestr,CI.bestp,CI.bestr,CI.matrix_1(1,:), ...
    CI.bestr,CI.matrix_1(2,:));
p(1).LineStyle = '-';
p(2).LineStyle = '--';
p(3).LineStyle = '--';
p(1).Color = 'k';
p(2).Color = 'r';
p(3).Color = 'g';
p(1).LineWidth = 2;
p(2).LineWidth = 1;
p(3).LineWidth = 1;
o = moments(CI.bestr,CI.matrix_1(1,:));
o = num2str(o(1));
textv = strcat('Mean= ',o);
text(0.75,0.875,textv,'Units','normalized','FontSize',10,'Color',[0.75 0 0]);
o = moments(CI.bestr,CI.bestp);
o = num2str(o(1));
textv = strcat('Mean= ',o);
text(0.75,0.925,textv,'Units','normalized','FontSize',10,'Color',[0 0 0]);  
o = moments(CI.bestr,CI.matrix_1(2,:)); 
o = num2str(o(1));
textv = strcat('Mean= ',o);
text(0.75,0.975,textv,'Units','normalized','FontSize',10,'Color',[0 0.5 0]);

% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, ~, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2
cla;
CI = getappdata(0,'CI');
p = plot(CI.bestr,CI.bestp,CI.bestr,CI.matrix_1(3,:), ...
    CI.bestr,CI.matrix_1(4,:));
p(1).LineStyle = '-';
p(2).LineStyle = '--';
p(3).LineStyle = '--';
p(1).Color = 'k';
p(2).Color = 'r';
p(3).Color = 'g';
p(1).LineWidth = 2;
p(2).LineWidth = 1;
p(3).LineWidth = 1;
o = moments(CI.bestr,CI.matrix_1(3,:));
o = num2str(o(2));
textv = strcat('Width= ',o);
text(0.75,0.875,textv,'Units','normalized','FontSize',10,'Color',[0.75 0 0]);
o = moments(CI.bestr,CI.bestp);
o = num2str(o(2));
textv = strcat('Width= ',o);
text(0.75,0.925,textv,'Units','normalized','FontSize',10,'Color',[0 0 0]);  
o = moments(CI.bestr,CI.matrix_1(4,:)); 
o = num2str(o(2));
textv = strcat('Width= ',o);
text(0.75,0.975,textv,'Units','normalized','FontSize',10,'Color',[0 0.5 0]);

% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, ~, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1
cla;
CI = getappdata(0,'CI');
p = plot(CI.bestr,CI.bestp,CI.bestr,CI.matrix_1(5,:), ...
    CI.bestr,CI.matrix_1(6,:));
p(1).LineStyle = '-';
p(2).LineStyle = '--';
p(3).LineStyle = '--';
p(1).Color = 'k';
p(2).Color = 'r';
p(3).Color = 'g';
p(1).LineWidth = 2;
p(2).LineWidth = 1;
p(3).LineWidth = 1;
o = moments(CI.bestr,CI.matrix_1(5,:));
o = num2str(o(3));
textv = strcat('Skewness= ',o);
text(0.75,0.875,textv,'Units','normalized','FontSize',10,'Color',[0.75 0 0]);
o = moments(CI.bestr,CI.bestp);
o = num2str(o(3));
textv = strcat('Skewness= ',o);
text(0.75,0.925,textv,'Units','normalized','FontSize',10,'Color',[0 0 0]);  
o = moments(CI.bestr,CI.matrix_1(6,:)); 
o = num2str(o(3));
textv = strcat('Skewness= ',o);
text(0.75,0.975,textv,'Units','normalized','FontSize',10,'Color',[0 0.5 0]);

% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, ~, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton4
cla;
CI = getappdata(0,'CI');
p = plot(CI.bestr,CI.bestp,CI.bestr,CI.matrix_1(7,:), ...
    CI.bestr,CI.matrix_1(8,:));
p(1).LineStyle = '-';
p(2).LineStyle = '--';
p(3).LineStyle = '--';
p(1).Color = 'k';
p(2).Color = 'r';
p(3).Color = 'g';
p(1).LineWidth = 2;
p(2).LineWidth = 1;
p(3).LineWidth = 1;
o = moments(CI.bestr,CI.matrix_1(7,:));
o = num2str(o(4));
textv = strcat('Kurtosis= ',o);
text(0.75,0.875,textv,'Units','normalized','FontSize',10,'Color',[0.75 0 0]);
o = moments(CI.bestr,CI.bestp);
o = num2str(o(4));
textv = strcat('Kurtosis= ',o);
text(0.75,0.925,textv,'Units','normalized','FontSize',10,'Color',[0 0 0]) 
o = moments(CI.bestr,CI.matrix_1(8,:));
o = num2str(o(4)); 
textv = strcat('Kurtosis= ',o);
text(0.75,0.975,textv,'Units','normalized','FontSize',10,'Color',[0 0.5 0]);

% --- Executes on button press in radiobutton5.
function radiobutton5_Callback(hObject, ~, handles)
% hObject    handle to radiobutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton5
cla;
%
CI = getappdata(0,'CI'); 
p = plot(CI.bestr,CI.bestp);
p(1).LineStyle = '-';
p(1).Color = 'k';
p(1).LineWidth = 2;
patch(CI.bestr,max(CI.matrix_2),'b','LineStyle','none','FaceAlpha',0.25)
patch(CI.bestr,min(CI.matrix_2),'w','LineStyle','none');
%
textv = num2str(trapz(CI.bestr,min(CI.matrix_2)));
textv = strcat('Integral= ',textv);
text(0.75,0.875,textv,'Units','normalized','FontSize',10,'Color',[0.75 0 0]);
textv = num2str(trapz(CI.bestr,CI.bestp));
textv = strcat('Integral= ',textv);
text(0.75,0.925,textv,'Units','normalized','FontSize',10,'Color',[0 0 0]);
textv = num2str(trapz(CI.bestr,max(CI.matrix_2)));
textv = strcat('Integral= ',textv);
text(0.75,0.975,textv,'Units','normalized','FontSize',10,'Color',[0 0.5 0]);

% --- Executes on button press in radiobutton6.
function radiobutton6_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton6
cla;
CI = getappdata(0,'CI');
q = mycorr(CI.matrix_2);
[~,idx] = min(q(:));
[i,j] = ind2sub(size(q),idx);
p = plot(CI.bestr,CI.bestp,CI.bestr,CI.matrix_2(i,:), ...
    CI.bestr,CI.matrix_2(j,:));
p(1).LineStyle = '-';
p(2).LineStyle = '--';
p(3).LineStyle = '--';
p(1).Color = 'k';
p(2).Color = 'r';
p(3).Color = 'g';
p(1).LineWidth = 2;
p(2).LineWidth = 1;
p(3).LineWidth = 1; 
