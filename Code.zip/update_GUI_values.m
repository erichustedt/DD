function [ handles ] = update_GUI_values( handles )
% 11/12/2012
%%
% 07/12/2016 - EJH - Version 6
% Revised to include beta factors for generalized normal distribution

% 08/16/2018 - EJH - Version 7B
% Revised so parameter windows will turn orange if the value is close to
% the upper or lower limit. The window will still turn red if equal to or
% exceed limit.
%%
index = 1;
set(handles.deltaR_edit,'String',num2str(handles.ANS.values(1)));
set(handles.deltaR_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.deltaR_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.deltaR_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 2;
set(handles.Rmax_edit,'String',num2str(handles.ANS.values(index)));
set(handles.Rmax_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.Rmax_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.Rmax_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 3;
set(handles.Rsphere_edit,'String',num2str(handles.ANS.values(index)));
set(handles.Rsphere_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.Rsphere_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.Rsphere_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 4;
set(handles.deltaR_b_edit,'String',num2str(handles.ANS.values(index)));
set(handles.deltaR_b_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.deltaR_b_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.deltaR_b_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 5;
set(handles.depth_edit,'String',num2str(handles.ANS.values(index), ...
  '%6.3f'));
set(handles.depth_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.depth_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.depth_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 6;
set(handles.lambda_edit,'String',num2str(handles.ANS.values(index), ...
  '%6.4f'));
set(handles.lambda_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.lambda_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.lambda_edit,'BackgroundColor',[1 0.6 0.6]);
end
% concX is display only concentration
concX = (10^handles.ANS.values(index))*1.0e-03/handles.ANS.values(5);
set(handles.concentrationX_edit,'String',num2str(concX));
index = 7;
set(handles.d_edit,'String',num2str(handles.ANS.values(index),'%2.1f'));
set(handles.d_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.d_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.d_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 8;
set(handles.b_depth_edit,'String',num2str(handles.ANS.values(index), ...
  '%6.3f'));
set(handles.b_depth_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.b_depth_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.b_depth_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 9;
set(handles.concentration_edit,'String', ...
  num2str(handles.ANS.values(index),'%6.0f'));
set(handles.concentration_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.concentration_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.concentration_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 10;
set(handles.rho_edit,'String',num2str(handles.ANS.values(index),'%5.1f'));
set(handles.rho_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.rho_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.rho_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 11;
set(handles.scale_edit,'String',num2str(handles.ANS.values(index), ...
  '%5.3f'));
set(handles.scale_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.scale_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.scale_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 12;
set(handles.time_shift_edit,'String',num2str(handles.ANS.values(index), ...
  '%6.2f'));
set(handles.time_shift_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.time_shift_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.time_shift_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 14; 
set(handles.r_1_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.r_1_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.r_1_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.r_1_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 15;
set(handles.s_1_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.s_1_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.s_1_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.s_1_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 16;
set(handles.b_1_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.b_1_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.b_1_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.b_1_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 17;
set(handles.l_1_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.l_1_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.l_1_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.l_1_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 19;
set(handles.r_2_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.r_2_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.r_2_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.r_2_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 20;
set(handles.s_2_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.s_2_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.s_2_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.s_2_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 21;
set(handles.b_2_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.b_2_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.b_2_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.b_2_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 22;
set(handles.l_2_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.l_2_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.l_2_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.l_2_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 23;
set(handles.a_2_edit,'String',num2str(handles.ANS.values(index),'%5.3f'));
set(handles.a_2_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.a_2_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.a_2_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 24;
set(handles.r_3_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.r_3_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.r_3_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.r_3_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 25;
set(handles.s_3_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.s_3_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.s_3_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.s_3_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 26;
set(handles.b_3_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.b_3_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.b_3_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.b_3_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 27;
set(handles.l_3_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.l_3_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.l_3_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.l_3_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 28;
set(handles.a_3_edit,'String',num2str(handles.ANS.values(index),'%5.3f'));
set(handles.a_3_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.a_3_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.a_3_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 29;
set(handles.r_4_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.r_4_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.r_4_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.r_4_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 30;
set(handles.s_4_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.s_4_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.s_4_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.s_4_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 31;
set(handles.b_4_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.b_4_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.b_4_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.b_4_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 32;
set(handles.l_4_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.l_4_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.l_4_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.l_4_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 33;
set(handles.a_4_edit,'String',num2str(handles.ANS.values(index),'%5.3f'));
set(handles.a_4_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.a_4_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.a_4_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 34;
set(handles.r_5_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.r_5_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.r_5_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.r_5_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 35;
set(handles.s_5_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.s_5_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.s_5_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.s_5_edit,'BackgroundColor',[1 0.6 0.6]);
end
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.s_5_edit,'BackgroundColor',[1 0.76 0.1]);
end
index = 36;
set(handles.b_5_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.b_5_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.b_5_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.b_5_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 37;
set(handles.l_5_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.l_5_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.l_5_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.l_5_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 38;
set(handles.a_5_edit,'String',num2str(handles.ANS.values(index),'%5.3f'));
set(handles.a_5_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.a_5_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.a_5_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 39;
set(handles.r_6_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.r_6_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.r_6_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.r_6_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 40;
set(handles.s_6_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.s_6_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.s_6_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.s_6_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 41;
set(handles.b_6_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.b_6_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.b_6_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.b_6_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 42;
set(handles.l_6_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.l_6_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.l_6_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.l_6_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 43;
set(handles.a_6_edit,'String',num2str(handles.ANS.values(index),'%5.3f'));
set(handles.a_6_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.a_6_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.a_6_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 44;
set(handles.r_7_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.r_7_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.r_7_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.r_7_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 45;
set(handles.s_7_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.s_7_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.s_7_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.s_7_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 46;
set(handles.b_7_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.b_7_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.b_7_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.b_7_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 47;
set(handles.l_7_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.l_7_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.l_7_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.l_7_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 48;
set(handles.a_7_edit,'String',num2str(handles.ANS.values(index),'%5.3f'));
set(handles.a_7_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.a_7_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.a_7_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 49;
set(handles.r_8_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.r_8_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.r_8_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.r_8_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 50;
set(handles.s_8_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.s_8_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.s_8_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.s_8_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 51;
set(handles.b_8_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.b_8_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.b_8_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.b_8_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 52;
set(handles.l_8_edit,'String',num2str(handles.ANS.values(index),'%6.2f'));
set(handles.l_8_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.l_8_edit,'BackgroundColor',[1 0.76 0.1]);
end
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.l_8_edit,'BackgroundColor',[1 0.6 0.6]);
end
index = 53;
set(handles.a_8_edit,'String',num2str(handles.ANS.values(index),'%5.3f')); 
set(handles.a_8_edit,'BackgroundColor',[1 1 1]);
extr = 0.005*(handles.ANS.upperlimit(index) - ...
               handles.ANS.lowerlimit(index));
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) + extr || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index) - extr
  set(handles.a_8_edit,'BackgroundColor',[1 0.76 0.1]);
end    
if handles.ANS.values(index) <= handles.ANS.lowerlimit(index) || ...
    handles.ANS.values(index) >= handles.ANS.upperlimit(index)
  set(handles.a_8_edit,'BackgroundColor',[1 0.6 0.6]);
end
%
set(handles.a_1_calc_text,'String', ...
  [num2str(100*handles.HOLD.normamp(1),'%4.1f') ...
  '%'],'ForegroundColor', [0 0 0]);
set(handles.a_2_calc_text,'String', ...
  [num2str(100*handles.HOLD.normamp(2),'%4.1f') ...
  '%'],'ForegroundColor', [0 0 0]);
set(handles.a_3_calc_text,'String', ...
  [num2str(100*handles.HOLD.normamp(3),'%4.1f') ...
  '%'],'ForegroundColor', [0 0 0]);
set(handles.a_4_calc_text,'String', ...
  [num2str(100*handles.HOLD.normamp(4),'%4.1f') ...
  '%'],'ForegroundColor', [0 0 0]);
set(handles.a_5_calc_text,'String', ...
  [num2str(100*handles.HOLD.normamp(5),'%4.1f') ...
  '%'],'ForegroundColor', [0 0 0]);
set(handles.a_6_calc_text,'String', ...
  [num2str(100*handles.HOLD.normamp(6),'%4.1f') ...
  '%'],'ForegroundColor', [0 0 0]);
set(handles.a_7_calc_text,'String', ...
  [num2str(100*handles.HOLD.normamp(7),'%4.1f') ...
  '%'],'ForegroundColor', [0 0 0]);
set(handles.a_8_calc_text,'String', ...
  [num2str(100*handles.HOLD.normamp(8),'%4.1f') ...
  '%'],'ForegroundColor', [0 0 0]); 
%
end

