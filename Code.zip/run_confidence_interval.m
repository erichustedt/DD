function [ handles ] = run_confidence_interval( handles )
%% run_confidence_interval
% 11/25/12
% 06/22/16 EJH modified to use MATLAB ActiveX for faster writing to Excel
% xlswrite commands removed
% calculate confidence intervals
% 2/18/18 EJH modified to use fmincon for minimization routine
%% revised 10/1/2015
% revised to guestimate confidence bands by picking out distributions that
% fall below 3 sigma level.
% revised to pick out 1 sigma, 2 sigma, and 3 sigma uncertainties by
% interpolation.
% matrix_1 stores extreme probability distributions
% matrix_2 stores all distributions that fall below 3 sigma
%%
try
    delete(handles.figure2(1:end));
catch
end
%%
if handles.CI.plot
    %
    scrsz = get(0,'Monitor');
    numMonitors = size(scrsz,1);
    if (numMonitors == 1)
        p1 = 0.49*scrsz(3);
        p2 = 50;
        p3 = scrsz(3)/2;
        p4 = scrsz(4)/2;
    end
    if (numMonitors > 1)
        %       if verLessThan('matlab','8.4')
        %         p1 = scrsz(2,1) + (scrsz(2,3) - scrsz(2,1))/3 - 50;
        %         p2 = scrsz(2,4)/3 - 200;
        %         p3 = 2*(scrsz(2,3) - scrsz(2,1))/3;
        %         p4 = 2*scrsz(2,4)/3  - 150;
        %       else
        p1 = scrsz(2,1) + scrsz(2,3)/2;
        p2 = scrsz(2,2);
        p3 = scrsz(2,3)/2;
        p4 = scrsz(2,4)/2;
        %       end
    end
end
%%
set(handles.static_text_22,'String',num2str(0.0));
%%
CI.stats(1,:) = moments(handles.CI.bestr,handles.CI.bestp);
CI.stats(2,:) = moments(handles.CI.bestr,handles.CI.bestp);
handles.CI.matrix_1 = repmat(handles.CI.bestp,8,1);
handles.CI.matrix_2 = handles.CI.bestp;
CI.headings = {'Best'};
%%
if handles.CI.bflag
    handles.figureCBb = confidence_bands_B_GUI(handles.CI, ...
        handles.DATA.name,handles.DATA.name,handles.DATA.AICc);
    cb_temp = guidata(handles.figureCBb);
end
handles.CI.errors = NaN(handles.FLOAT.nfloat,3,2);
%% DETERMINE CHISQUARED VALUES CORRESPONDING TO DIFFERENTCONFIDENCE LEVELS
handles.CI.target1s = (handles.DATA.fitbestunreducedtotalchisquared + ...
    1)/handles.ndegreefreedom;
handles.CI.target2s = (handles.DATA.fitbestunreducedtotalchisquared + ...
    4)/handles.ndegreefreedom;
handles.CI.target3s = (handles.DATA.fitbestunreducedtotalchisquared + ...
    9)/handles.ndegreefreedom;
%
chisquared_min = handles.DATA.fitbestchisquared;
handles.DATA.confbestchisquared = 1.e12*handles.DATA.chisquared;
% STORE INFORMATION FROM INITIAL FIT
fpi = handles.FLOAT.floatparindex(1,:);
opi = handles.OPTIONS.OUTPUT.logical.plotintermediate;
%
handles.OPTIONS.OUTPUT.logical.plotintermediate = 0;
fprintf('%s \n','START CONFIDENCE INTERVAL');
% OF ALL OF THE FLOATED PARAMETERS IN THE INITIAL FIT THESE ARE THE ONES
% FOR WHICH CONFIDENCE INTERVALS HAVE BEEN REQUESTED
handles.CI.cindex = find(cell2mat(handles.CI.data(:,5)));
handles.CI.confnames = handles.ANS.names(fpi(handles.CI.cindex));
handles.CI.nconf = length(handles.CI.cindex);
%
stop_flag = false;
for ic = 1:handles.CI.nconf
    if stop_flag
        break;
    end
    clear confid aplot bplot cplot;
    % fix parameter for which conf. int. is being determined
    handles.ANS.fixed( fpi(handles.CI.cindex(ic)) ) = 1;
    % detemine range over which parameters will be varied
    xvalue = ...
        handles.ANS.finalvalues( fpi(handles.CI.cindex(ic)) );
    xci = xvalue;
    yci = chisquared_min;
    %
    xs = xvalue + cell2mat(handles.CI.data(handles.CI.cindex(ic),2));
    if xs < handles.ANS.lowerlimit( fpi(handles.CI.cindex(ic)) )
        xs = handles.ANS.lowerlimit( fpi(handles.CI.cindex(ic)) );
    end
    xe = xvalue + cell2mat(handles.CI.data(handles.CI.cindex(ic),3));
    if xe >  handles.ANS.upperlimit( fpi(handles.CI.cindex(ic)) )
        xe = handles.ANS.upperlimit( fpi(handles.CI.cindex(ic)) );
    end
    % SETUP FIGURE FOR EACH VARIABLE ----------------------------------------
    if handles.CI.plot
        handles.figure2(ic) = figure('Name',char(handles.CI.confnames(ic)), ...
            'NumberTitle','on','Position',[p1 p2 p3 p4],'Units','normalized');
        tbut = uicontrol(handles.figure2(ic),'Style','togglebutton',...
            'String','Stop!','Units','normalized',...
            'FontSize',11,'FontWeight','bold', ...
            'Callback',@toggle_callback, ...
            'Position',[0.875 0.90 0.1 0.075], ...
            'BackgroundColor',[0 0.75 0]);
        
        axes11 = axes('Parent',handles.figure2(ic));
        plot8 = plot([xs xe],[handles.CI.target1s handles.CI.target1s], ...
            [xs xe],[handles.CI.target2s handles.CI.target2s],[xs xe], ...
            [handles.CI.target3s handles.CI.target3s],xci, yci,'Parent',axes11);
        set(plot8(1),'LineStyle','--','LineWidth',2, ...
            'Color',[1   0 0],'Parent',axes11);
        set(plot8(2),'LineStyle','--','LineWidth',2, ...
            'Color',[0 0.5 0],'Parent',axes11);
        set(plot8(3),'LineStyle','--','LineWidth',2, ...
            'Color',[0 0 1],'Parent',axes11);
        set(plot8(4),'MarkerSize',15,'Marker','o','LineStyle','none', ...
            'Color',[0 0 0],'Parent',axes11);
        axis([xs xe chisquared_min handles.CI.target3s])
        set(datacursormode(handles.figure2(ic)),'SnapToDataVertex','off');
    end
    %
    if strncmp(handles.CI.confnames(ic),'R_',2)
        if handles.reliable_min > xs
            q1 = [xs xs handles.reliable_min handles.reliable_min];
            q2 = [0 handles.CI.target3s handles.CI.target3s 0];
            patch(q1,q2,'y','LineStyle','none','FaceAlpha',0.15);
        end
        if handles.reliable_max < xe
            q1 = [handles.reliable_max handles.reliable_max xe xe];
            q2 = [0 handles.CI.target3s handles.CI.target3s 0];
            patch(q1,q2,'y','LineStyle','none','FaceAlpha',0.15);
        end
    end
    % disp('Values for confidence interval')
    fprintf('%s \n',char(handles.CI.confnames(ic)));
    xlabel(handles.CI.confnames(ic),'Interpreter','none');
    ylabel('\chi_\nu^2');
    drawnow;
    %% CALCULATE CONFIDENCE INTERVALS --------------------------------------
    jc = 0;
    for rc = xs:cell2mat(handles.CI.data(handles.CI.cindex(ic),4)):xe
        if tbut.Value
            stop_flag = true;
            break
        end
        
        jc = jc + 1;
        fprintf('%s %s %s \n',char(handles.CI.confnames(ic)),' = ', ...
            num2str(rc));
        handles.ANS.values = handles.ANS.finalvalues;
        handles.ANS.values(fpi(handles.CI.cindex(ic))) = rc;
        handles = find_float_values( handles );
        %% setup
        [handles.DATA,handles.PARAM,handles.HOLD,handles.PARAM0] = ...
            deer_first(handles.DATA,handles.PARAM);
        floatvalues = handles.FLOAT.float;
        % The values that are fixed and floated have changed so you need to
        % redefine fit function(functionhandle)
        handles.chisquared = 0;
        extra = struct('HOLD',handles.HOLD,'PARAM0',handles.PARAM0);
        functionhandle = ...
            @(floatvalues,extra)fit_DEER_driver_DD(floatvalues, ...
            extra,handles);
        %% Generate inital fit to the data based on starting parameters
        %  initial parameters for Marquardt-Levenberg algorithm;
        %  calculate derivates
        handles = functionhandle(floatvalues, extra);
        handles = determine_chi2(handles);
        if handles.OPTIONS.IP.logical.interiorpoint  || ...
                handles.OPTIONS.GS.logical.globalsearch || ...
                handles.OPTIONS.PS.logical.particleswarm
            floatvalues = handles.FLOAT.float;
            nfloat = handles.FLOAT.nfloat;
            chisquaredhandle = @(floatvalues,extra) ...
                chisquared_DEER_driver_DD(floatvalues,handles);
            % Copy lower and upper limits
            ll = zeros(1,nfloat);
            ul = zeros(1,nfloat);
            for j = 1:nfloat
                ll(j) = handles.ANS.lowerlimit( handles.FLOAT.floatparindex(1,j) );
                ul(j) = handles.ANS.upperlimit( handles.FLOAT.floatparindex(1,j) );
            end
            fmc_options = optimoptions('fmincon','Display','off');
            % in Matlab 2015b and earlier verisions these options have different
            % names, MaxIter MaxFunEvals TolX TolFun. - 4/26/2018 EJH
            if verLessThan('matlab','9.0')
                fmc_options.MaxIter = handles.OPTIONS.IP.numeric.MaxIterations;
                fmc_options.MaxFunEvals = ...
                    handles.OPTIONS.IP.numeric.MaxFunctionEvaluations;
                % TolX terminates if change in parameter values is small
                fmc_options.TolX = handles.OPTIONS.IP.numeric.StepTolerance;
                fmc_options.TolFun = 0.;
            else
                fmc_options.MaxIterations = handles.OPTIONS.IP.numeric.MaxIterations;
                fmc_options.MaxFunctionEvaluations = ...
                    handles.OPTIONS.IP.numeric.MaxFunctionEvaluations;
                % StepTolerance terminates if change in parameter values is small
                fmc_options.StepTolerance = handles.OPTIONS.IP.numeric.StepTolerance;
                fmc_options.ObjectiveLimit = 0.;
            end 
            % This is section for interiorpoint routine
            A = [];
            Aeq = [];
            b = [];
            beq = [];
            nonlcon = [];
            [handles.FLOAT.float,handles.DATA.chisquared] = fmincon(chisquaredhandle, ...
                floatvalues,A,b,Aeq,beq,ll,ul, ...
                nonlcon,fmc_options);
            handles.ANS.values(handles.FLOAT.floatparindex(1:nfloat)) = ...
                handles.FLOAT.float(1:nfloat);
        end
        if handles.OPTIONS.LM.logical.LM
            [handles, ~, ~] = MLroutine_DD(functionhandle, handles);
        end
        if handles.OPTIONS.SP.logical.fminsearch
            chisquaredhandle = @(floatvalues,extra) ...
                chisquared_DEER_driver_DD(floatvalues,handles);
            [handles.FLOAT.float,handles.DATA.chisquared] = ...
                fminsearch(chisquaredhandle,handles.FLOAT.float);
        end
        aplot(jc) = rc;
        bplot(jc) = handles.DATA.chisquared;
        cplot(jc,1:length(handles.FLOAT.floatnames)) = handles.FLOAT.float;
        %% find distance distributions that are within 2 sigma of best
        if handles.CI.bflag || handles.CI.cflag
            if handles.DATA.chisquared < handles.CI.target2s
                [CI.stats,handles.CI.matrix_1,handles.CI.matrix_2] = ...
                    confidence_bands_B(handles.CI.bestr,handles.HOLD.p, ...
                    CI.stats,handles.CI.matrix_1,handles.CI.matrix_2);
                CI.headings(end+1) = {char(handles.CI.confnames(ic))};
                if handles.CI.bflag
                    if size(handles.CI.matrix_2,1) > 1
                        cla(cb_temp.axes21);
                        p = plot(cb_temp.axes21,handles.CI.bestr,handles.CI.bestp);
                        p(1).LineStyle = '-';
                        p(1).Color = 'k';
                        p(1).LineWidth = 2;
                        patch(handles.CI.bestr,max(handles.CI.matrix_2),'b',...
                            'LineStyle','none','FaceAlpha',0.333,'Parent',cb_temp.axes21)
                        patch(handles.CI.bestr,min(handles.CI.matrix_2),'w', ...
                            'LineStyle','none','Parent',cb_temp.axes21);
                        %
                        textv = num2str(trapz(handles.CI.bestr, ...
                            min(handles.CI.matrix_2)));
                        textv = strcat('Integral= ',textv);
                        text(0.75,0.875,textv,'Units','normalized','FontSize',10, ...
                            'Color',[0.75 0 0],'Parent',cb_temp.axes21);
                        textv = num2str(trapz(handles.CI.bestr,handles.CI.bestp));
                        textv = strcat('Integral= ',textv);
                        text(0.75,0.925,textv,'Units','normalized','FontSize',10, ...
                            'Color',[0 0 0],'Parent',cb_temp.axes21);
                        textv = num2str(trapz(handles.CI.bestr, ...
                            max(handles.CI.matrix_2)));
                        textv = strcat('Integral= ',textv);
                        text(0.75,0.975,textv,'Units','normalized','FontSize',10, ...
                            'Color',[0 0.5 0],'Parent',cb_temp.axes21);
                        %% AICc
                        q= horzcat('$ AICc = ',num2str(handles.DATA.AICc,'%10.1f'), ...
                            '$');
                        text(0.01,0.10,q,'Units','normalized', ...
                            'FontSize',10,'Color',[0 0 0.5],'Interpreter','latex', ...
                            'Parent',cb_temp.axes21);
                        q= horzcat('$ BIC = ',num2str(handles.DATA.BIC,'%10.1f'),'$');
                        text(0.01,0.04,q,'Units','normalized', ...
                            'FontSize',10,'Color',[0 0 0.5],'Interpreter','latex', ...
                            'Parent',cb_temp.axes21);
                        %% Data File Name
                        text(0.01,0.95,handles.DATA.name,'Units','normalized', ...
                            'FontSize',10, 'Color',[0 0 0.5],'Parent',cb_temp.axes21, ...
                            'Interpreter','none');
                    end
                end
                setappdata(0,'CI',handles.CI);
            end
        end
        %% find values corresponding to 1, 2, 3 sigm a levels
        xci = xvalue;
        yci = chisquared_min;
        handles.CI.errors(handles.CI.cindex(ic),1,:) = ...
            findconfidence(aplot,bplot,xvalue,handles.CI.target1s);
        handles.CI.errors(handles.CI.cindex(ic),2,:) = ...
            findconfidence(aplot,bplot,xvalue,handles.CI.target2s);
        handles.CI.errors(handles.CI.cindex(ic),3,:) = ...
            findconfidence(aplot,bplot,xvalue,handles.CI.target3s);
        
        if ~isnan(handles.CI.errors(handles.CI.cindex(ic),1,1))
            xci=[xci handles.CI.errors(handles.CI.cindex(ic),1,1)];
            yci=[yci handles.CI.target1s];
        end
        if ~isnan(handles.CI.errors(handles.CI.cindex(ic),1,2))
            xci=[xci handles.CI.errors(handles.CI.cindex(ic),1,2)];
            yci=[yci handles.CI.target1s];
        end
        
        if ~isnan(handles.CI.errors(handles.CI.cindex(ic),2,1))
            xci=[xci handles.CI.errors(handles.CI.cindex(ic),2,1)];
            yci=[yci handles.CI.target2s];
        end
        if ~isnan(handles.CI.errors(handles.CI.cindex(ic),2,2))
            xci=[xci handles.CI.errors(handles.CI.cindex(ic),2,2)];
            yci=[yci handles.CI.target2s];
        end
        
        if ~isnan(handles.CI.errors(handles.CI.cindex(ic),3,1))
            xci=[xci handles.CI.errors(handles.CI.cindex(ic),3,1)];
            yci=[yci handles.CI.target3s];
        end
        if ~isnan(handles.CI.errors(handles.CI.cindex(ic),3,2))
            xci=[xci handles.CI.errors(handles.CI.cindex(ic),3,2)];
            yci=[yci handles.CI.target3s];
        end
        % ---------------------------------------------------------------------
        if handles.CI.plot
            plotll = min(bplot);
            plotll = min(plotll,chisquared_min);
            plotul = max(bplot);
            plotul = max(plotul,handles.CI.target3s);
            figure(handles.figure2(ic));
            plot8 = plot(aplot,bplot,[xs xe], ...
                [handles.CI.target1s handles.CI.target1s], ...
                [xs xe],[handles.CI.target2s handles.CI.target2s], [xs xe], ...
                [handles.CI.target3s handles.CI.target3s], xci, yci, 'Parent', ...
                axes11);
            set(plot8(1),'MarkerSize',10,'Marker','*', ...
                'LineStyle','-','LineWidth',2, ...
                'Color',[0.40 0.0 0.6],'Parent',axes11);
            set(plot8(2),'LineStyle','--','LineWidth',2, ...
                'Color',[1   0 0],'Parent',axes11);
            set(plot8(3),'LineStyle','--','LineWidth',2, ...
                'Color',[0 0.5 0],'Parent',axes11);
            set(plot8(4),'LineStyle','--','LineWidth',2, ...
                'Color',[0 0 1],'Parent',axes11);
            set(plot8(5),'MarkerSize',15,'Marker','o','LineStyle','none', ...
                'Color',[0 0 0],'Parent',axes11);
            set(get(gca,'YLabel'),'Rotation',0.0)
            %             text(0.333,0.95,handles.DATA.name,...
            %                 'Units','normalized',...
            %                 'FontSize',8,'Color',[0 0 0],'Interpreter','none');
            q = sprintf('%s %2.0f %s %s','Parameter #', ...
                handles.CI.cindex(ic), ' = ', char(handles.CI.confnames(ic)) );
            text(0.333,0.89,q, ...
                'Units','normalized','FontSize',12, ...
                'Color',[0 0 0],'Interpreter','none');
            q= horzcat('$1 \sigma \quad$', ...
                num2str(handles.CI.errors(handles.CI.cindex(ic),1,1) - ...
                xvalue,'%8.1e'),'   ', num2str(xvalue,'%4.3f'),'   ', ...
                num2str(handles.CI.errors(handles.CI.cindex(ic),1,2) - ...
                xvalue,'%8.1e'));
            text(0.333,0.83,q,'Units','normalized', ...
                'FontSize',12,'Color',[1 0 0],'Interpreter','latex');
            q= horzcat('$2 \sigma \quad$', ...
                num2str(handles.CI.errors(handles.CI.cindex(ic),2,1) - ...
                xvalue,'%8.1e'),'   ', num2str(xvalue,'%4.3f'),'   ', ...
                num2str(handles.CI.errors(handles.CI.cindex(ic),2,2) - ...
                xvalue,'%8.1e'));
            text(0.333,0.77,q,'Units','normalized', ...
                'FontSize',12,'Color',[0 0.5 0],'Interpreter','latex');
            q= horzcat('$3 \sigma \quad$', ...
                num2str(handles.CI.errors(handles.CI.cindex(ic),3,1) - ...
                xvalue,'%8.1e'),'  ',num2str(xvalue,'%4.3f'),'   ', ...
                num2str(handles.CI.errors(handles.CI.cindex(ic),3,2) - ...
                xvalue,'%8.1e'));
            text(0.333,0.71,q,'Units','normalized', ...
                'FontSize',12,'Color',[0 0 1],'Interpreter','latex');
            axis([xs xe plotll plotul]);  %
            if strncmp(handles.CI.confnames(ic),'R_',2)
                if handles.reliable_min > xs
                    q1 = [xs xs handles.reliable_min handles.reliable_min];
                    q2 = [0 plotul plotul 0];
                    patch(q1,q2,'y','LineStyle','none','FaceAlpha',0.15);
                end
                if handles.reliable_max < xe
                    q1 = [handles.reliable_max handles.reliable_max xe xe];
                    q2 = [0 plotul plotul 0];
                    patch(q1,q2,'y','LineStyle','none','FaceAlpha',0.15);
                end
            end
            xlabel(handles.CI.confnames(ic),'Interpreter','none');
            ylabel('\chi_\nu^2');
            drawnow;
        end
        % if latest fit is best yet -------------------------------------------
        if handles.DATA.chisquared < handles.DATA.confbestchisquared
            handles.DATA.confbestchisquared = handles.DATA.chisquared;
            % fpi are the indices of all floated parameters including the one in
            % the confidence interval
            handles.floatbest = handles.ANS.values(fpi);
            set(handles.static_text_22,'String', ...
                num2str(handles.DATA.confbestchisquared));
            set(handles.static_text_22,'ForegroundColor',[0.5 0 0]);
            handles.ANS.confbestvalues = handles.ANS.values;
            handles.ANS.confbestvalues(fpi) = handles.floatbest;
            disp('update best values');
            if handles.CI.stop
                if handles.DATA.confbestchisquared < ...
                        handles.DATA.fitbestchisquared - ...
                        handles.OPTIONS.LM.numeric.mindifference
                    stop_flag = true;
                    fprintf('%s \n','Confidence Interval Calculation Terminating');
                    set(handles.message_text,'String', ...
                        'Confidence Interval Calculation Terminating', ...
                        'BackgroundColor',[1 1 1]);
                    break;
                end
            end
            
        end
    end
    handles.ANS.fixed(fpi(handles.CI.cindex(ic))) = 0;
    % -----------------------------------------------------------------------
    if handles.CI.plot
        [t1,t2,~] = fileparts(handles.answerfile);
        q = [t1 handles.sep t2 '_' num2str(ic), '.fig'];
        saveas(handles.figure2(ic), q);
    end
    % -----------------------------------------------------------------------
    if handles.OPTIONS.OUTPUT.logical.output2Excel
        %% KILL any existing EXCEL processe
        killExcel
        %%
        ExcelTrue = actxserver ('Excel.Application');
        set(ExcelTrue, 'Visible', 0);
        %% Check Office Version
        %  For Office 2010 or earlier 3 sheets are opened by default, for later
        %  versions only 1 sheet is opened
        office_version = ExcelTrue.Version;
        if office_version >= 15
            open_sheet = 1;
        else
            open_sheet = 3;
        end
        %%
        WorkBook =  ExcelTrue.Workbooks.Open(handles.answerfile);
        Sheets = ExcelTrue.ActiveWorkbook.Sheets;
        %% SHEET - 1 for each CI
        sheetname = char(handles.CI.confnames(ic));
        temp = sheet_names(ExcelTrue,Sheets);
        if ~all(~strcmp(temp,sheetname))
            ClearExcelWorksheet(handles.answerfile,sheetname);
            invoke(ExcelTrue.ActiveWorkbook.Sheets.Item(sheetname),'Activate');
            ActiveSheet = ExcelTrue.Activesheet;  % Make sheet active
        else
            esheet = Sheets.Count;
            esheet = esheet + 1;
            if esheet > open_sheet
                Sheets.Add([], ...
                    ExcelTrue.ActiveWorkbook.Sheets.Item(esheet-1));
            end
            invoke(get(Sheets, 'Item', esheet), 'Activate');
            ActiveSheet = ExcelTrue.Activesheet;  % Make sheet active
            ActiveSheet.Name = strcat(sheetname);
        end
        disp(ActiveSheet.Name);
        %
        q = sheetname;
        set(get(ActiveSheet,'Range', ExcelRange('A1',q)), 'Value', q);
        %
        q = aplot';
        set(get(ActiveSheet,'Range', ExcelRange('A2',q)), 'Value', q);
        %
        q = {'chisquared'};
        set(get(ActiveSheet,'Range', ExcelRange('B1',q)), 'Value', q);
        %
        q = bplot';
        set(get(ActiveSheet,'Range', ExcelRange('B2',q)), 'Value', q);
        %
        q = handles.FLOAT.floatnames';
        set(get(ActiveSheet,'Range', ExcelRange('C1',q)), 'Value', q);
        %
        q = cplot;
        set(get(ActiveSheet,'Range', ExcelRange('C2',q)), 'Value', q);
        %
        initial = strcat(64+handles.FLOAT.nfloat+3,'1');
        q = {'minimum'};
        set(get(ActiveSheet,'Range', ExcelRange(initial,q)), 'Value', q);
        %
        initial = strcat(64+handles.FLOAT.nfloat+3,'2');
        q = chisquared_min*ones(jc,1);
        set(get(ActiveSheet,'Range', ExcelRange(initial,q)), 'Value', q);
        %
        initial = strcat(64+handles.FLOAT.nfloat+3,num2str(jc+2));
        q = xvalue*ones(4,1);
        set(get(ActiveSheet,'Range', ExcelRange(initial,q)), 'Value', q);
        %
        initial = strcat(64+handles.FLOAT.nfloat+4,'1');
        q = {'1 sigma'};
        set(get(ActiveSheet,'Range', ExcelRange(initial,q)), 'Value', q);
        %
        initial = strcat(64+handles.FLOAT.nfloat+4,'2');
        q = handles.CI.target1s*ones(jc,1);
        set(get(ActiveSheet,'Range', ExcelRange(initial,q)), 'Value', q);
        %
        initial = strcat(64+handles.FLOAT.nfloat+4,num2str(jc+2));
        r = squeeze(handles.CI.errors(handles.CI.cindex(ic),1,:));
        set(get(ActiveSheet,'Range', ExcelRange(initial,r)), 'Value', r);
        %
        initial = strcat(64+handles.FLOAT.nfloat+4,num2str(jc+4));
        q = r - xvalue;
        set(get(ActiveSheet,'Range', ExcelRange(initial,q)), 'Value', q);
        %
        initial = strcat(64+handles.FLOAT.nfloat+5,'1');
        q = {'2 sigma'};
        set(get(ActiveSheet,'Range', ExcelRange(initial,q)), 'Value', q);
        %
        initial = strcat(64+handles.FLOAT.nfloat+5,'2');
        q = handles.CI.target2s*ones(jc,1);
        set(get(ActiveSheet,'Range', ExcelRange(initial,q)), 'Value', q);
        %
        initial = strcat(64+handles.FLOAT.nfloat+5,num2str(jc+2));
        r = squeeze(handles.CI.errors(handles.CI.cindex(ic),2,:));
        set(get(ActiveSheet,'Range', ExcelRange(initial,r)), 'Value', r);
        %
        initial = strcat(64+handles.FLOAT.nfloat+5,num2str(jc+4));
        q = r - xvalue;
        set(get(ActiveSheet,'Range', ExcelRange(initial,q)), 'Value', q);
        %
        %
        initial = strcat(64+handles.FLOAT.nfloat+6,'1');
        q = {'3 sigma'};
        set(get(ActiveSheet,'Range', ExcelRange(initial,q)), 'Value', q);
        %
        initial = strcat(64+handles.FLOAT.nfloat+6,'2');
        q = handles.CI.target3s*ones(jc,1);
        set(get(ActiveSheet,'Range', ExcelRange(initial,q)), 'Value', q);
        %
        initial = strcat(64+handles.FLOAT.nfloat+6,num2str(jc+2));
        r = squeeze(handles.CI.errors(handles.CI.cindex(ic),3,:));
        set(get(ActiveSheet,'Range', ExcelRange(initial,r)), 'Value', r);
        %
        initial = strcat(64+handles.FLOAT.nfloat+6,num2str(jc+4));
        q = r - xvalue;
        set(get(ActiveSheet,'Range', ExcelRange(initial,q)), 'Value', q);
        %% Close Excel
        sheet = get(Sheets, 'Item', 1);
        invoke(sheet, 'Activate');
        ExcelTrue.displayalerts = false;
        WorkBook.SaveAs(handles.answerfile);
        DeleteEmptyExcelSheets(handles.answerfile);
        invoke(ExcelTrue, 'Quit');
        delete(ExcelTrue);
    end
    if(handles.OPTIONS.OUTPUT.logical.output2ASCII)
        outfile = ...
            strcat(handles.answerfile(1:strfind(handles.answerfile,'.')-1), ...
            '_',handles.CI.confnames(ic,:),'.dat');
        fid = fopen(char(outfile),'w');
        fprintf(fid,'\t');
        q = char(handles.FLOAT.floatnames);
        fprintf(fid,' %s \t',char(handles.CI.confnames(ic,:)),'chisquared',q');
        fprintf(fid,'\n');
        for n = 1:length(aplot)
            fprintf(fid,' %12.5g \t',aplot(n),bplot(n),cplot(n,:));
            fprintf(fid,'\n');
        end
        fclose(fid);
    end
end
%
handles.ANS.fixed(fpi) = 0;
handles.ANS.values = handles.ANS.finalvalues;
handles = find_float_values( handles );
handles.OPTIONS.OUTPUT.logical.plotintermediate = opi;
%%
handles.CI.matrix_1( 9,:) = min(handles.CI.matrix_2);
handles.CI.matrix_1(10,:) = max(handles.CI.matrix_2);
q = mycorr(handles.CI.matrix_2);
[~,idx] = min(q(:));
[i,j] = ind2sub(size(q),idx);
handles.CI.matrix_1(11,:) = handles.CI.matrix_2(i,:);
handles.CI.matrix_1(12,:) = handles.CI.matrix_2(j,:);
%% Divide by 4 since we are using a 2 sigma cutoff
handles.CI.matrix_1(13,:) = ...
    ((handles.CI.matrix_1(10,:)- handles.CI.matrix_1(9,:))/4)';

%%
for k = 1:handles.CI.nconf
    handles.ANS.confidence(fpi(1,handles.CI.cindex(k))) = 1;
    handles.ANS.start(fpi(1,handles.CI.cindex(k))) = ...
        cell2mat(handles.CI.data(handles.CI.cindex(k),2));
    handles.ANS.end(fpi(1,handles.CI.cindex(k))) = ...
        cell2mat(handles.CI.data(handles.CI.cindex(k),3));
    handles.ANS.increment(fpi(1,handles.CI.cindex(k))) = ...
        cell2mat(handles.CI.data(handles.CI.cindex(k),4));
end
%
%% Write Confidence Bands for Probability Distribution
if handles.OPTIONS.OUTPUT.logical.output2Excel
    % SHEET = 'CB 1' for matrix_1
    ExcelTrue = actxserver ('Excel.Application');
    set(ExcelTrue, 'Visible', 0);
    %%  Check Office Version
    %   For Office 2010 or earlier 3 sheets are opened by default, for later
    %   versions only 1 sheet is opened
    office_version = ExcelTrue.Version;
    if office_version >= 15
        open_sheet = 1;
    else
        open_sheet = 3;
    end
    %%
    WorkBook =  ExcelTrue.Workbooks.Open(handles.answerfile);
    Sheets = ExcelTrue.ActiveWorkbook.Sheets;
    % SHEET - 1 for each CI
    sheetname = 'CB 1';
    temp = sheet_names(ExcelTrue,Sheets);
    if ~all(~strcmp(temp,sheetname))
        ClearExcelWorksheet(handles.answerfile,sheetname);
        invoke(ExcelTrue.ActiveWorkbook.Sheets.Item(sheetname),'Activate');
    else
        esheet = Sheets.Count;
        esheet = esheet + 1;
        if esheet > open_sheet
            Sheets.Add([], ExcelTrue.ActiveWorkbook.Sheets.Item(esheet-1));
        end
        invoke(get(Sheets, 'Item', esheet), 'Activate');
        ActiveSheet = ExcelTrue.Activesheet;  % Make sheet active
        ActiveSheet.Name = strcat(sheetname);
    end
    disp(ActiveSheet.Name);
    %
    q = {'R' 'best' 'mean' 'mean' 'width' 'width' ...
        'skewness' 'skewness' 'kurtosis' 'kurtosis' 'minimum' 'maximum' ...
        'corr.' 'corr.' '(max-min)/4'};
    set(get(ActiveSheet,'Range', ExcelRange('A1',q)), 'Value', q);
    %
    q = handles.CI.bestr';
    set(get(ActiveSheet,'Range', ExcelRange('A2',q)), 'Value', q);
    %
    q = handles.CI.bestp';
    set(get(ActiveSheet,'Range', ExcelRange('B2',q)), 'Value', q);
    %
    q = handles.CI.matrix_1';
    set(get(ActiveSheet,'Range', ExcelRange('C2',q)), 'Value', q);
    %
    sheetname = strcat('UNCERTAINTIES');
    invoke(ExcelTrue.ActiveWorkbook.Sheets.Item(sheetname),'Activate');
    ActiveSheet = ExcelTrue.Activesheet;
    disp(ActiveSheet.Name);
    %
    q = {'1 sigma CI' '1 sigma CI' ...
        '2 sigma CI' '2 sigma CI' '3 sigma CI' '3 sigma CI'};
    set(get(ActiveSheet,'Range', ExcelRange('D1',q)), 'Value', q);
    %
    q = handles.CI.errors(:,1,1) - handles.FLOAT.float(:);
    set(get(ActiveSheet,'Range', ExcelRange('D2',q)), 'Value', q);
    %
    q = handles.CI.errors(:,1,2) - handles.FLOAT.float(:);
    set(get(ActiveSheet,'Range', ExcelRange('E2',q)), 'Value', q);
    %
    q = handles.CI.errors(:,2,1) - handles.FLOAT.float(:);
    set(get(ActiveSheet,'Range', ExcelRange('F2',q)), 'Value', q);
    %
    q = handles.CI.errors(:,2,2) - handles.FLOAT.float(:);
    set(get(ActiveSheet,'Range', ExcelRange('G2',q)), 'Value', q);
    %
    q = handles.CI.errors(:,3,1) - handles.FLOAT.float(:);
    set(get(ActiveSheet,'Range', ExcelRange('H2',q)), 'Value', q);
    %
    q = handles.CI.errors(:,3,2) - handles.FLOAT.float(:);
    set(get(ActiveSheet,'Range', ExcelRange('I2',q)), 'Value', q);
    %
    %% Close Excel
    sheet = get(Sheets, 'Item', 1);
    invoke(sheet, 'Activate');
    ExcelTrue.displayalerts = false;
    WorkBook.SaveAs(handles.answerfile);
    DeleteEmptyExcelSheets(handles.answerfile);
    invoke(ExcelTrue, 'Quit');
    delete(ExcelTrue);
end
%% Save 2nd confidence interval GUI
if handles.CI.bflag
    [t1,~,~] = fileparts(handles.answerfile);
    q = [t1 handles.sep 'B.pdf'];
    saveas(handles.figureCBb, q); 
end
%% 3rd confidence interval GUI
if handles.CI.cflag
    handles.figureCBc = confidence_bands_C_GUI(handles);
    cc_temp = guidata(handles.figureCBc);
end
end

function [] = toggle_callback(hObject,~)
% Callback for Toggle Button
set(hObject,'BackgroundColor','r');
end