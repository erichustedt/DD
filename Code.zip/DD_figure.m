function [ handles ] = DD_figure(handles)
%UNTITLED4 Summary of this function goes here
% Detailed explanation goes here
% Create Figure Window
scrsz = get(0,'Monitor');
numMonitors = size(scrsz,1);
if (numMonitors == 1) 
  p1 = scrsz(3)/3-100;
  p2 = scrsz(4)/3-100;
  p3 = 2*scrsz(3)/3;
  p4 = 2*scrsz(4)/3;
end 
if (numMonitors == 2) 
  if verLessThan('matlab','8.4')
    p1 = scrsz(2,1) + (scrsz(2,3) - scrsz(2,1))/3 - 50;
    p2 = scrsz(2,4)/3 - 200;
    p3 = 2*(scrsz(2,3) - scrsz(2,1))/3;
    p4 = 2*scrsz(2,4)/3  - 150;
  else   
    p1 = scrsz(2,1) + scrsz(2,3)/4;
    p2 = scrsz(2,2) + scrsz(2,4)/10;
    p3 = 2*scrsz(2,3)/3;
    p4 = 2*scrsz(2,4)/3;
  end 
end 
handles.figureA = figure('Name',handles.DATA.name, ...
  'NumberTitle','on','Position',[p1 p2 p3 p4], ...
  'PaperOrientation','landscape');
handles.figureA.WindowStyle = 'normal';
handles.figureA.MenuBar = 'none'; 
handles.figureA.ToolBar = 'none'; 
handles.fAtitle = annotation(handles.figureA,'textbox', ...
  [0.325 0.925 0.35 0.075],'String', ...
  handles.answerfile,'HorizontalAlignment','center',...
  'FontSize',10,'FitBoxToText','off','LineStyle','none',...
  'Interpreter','none','Color',[0 0 0.5]);
handles.fBtitle = annotation(handles.figureA,'textbox', ...
  [0.001 0.025 0.96 0.025],'String',...
  handles.DATA.name,'HorizontalAlignment','left',...
  'FontSize',10,'FitBoxToText','off','LineStyle','none',...
  'Interpreter','none','Color',[0.5 0 0]);
end

% text('Parent',handles.axes2,'Units','normalized','String', ...
%     handles.DATA.name,'Position',[0.01 0.20 0],'FontSize',8, ...
%     'Interpreter','none');
