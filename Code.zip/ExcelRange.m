function range = ExcelRange( initial, data )
% This function determines the range over which data is written in Excel
% 06/21/2016
% EJH
v = textscan(initial,('%c %d'));
a = cellstr(v(1));
s = size(data);
t = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
b = strfind(t,a);
c = t(b + s(2) - 1); 
m = cell2mat(v(2));
n = m + s(1) - 1;
range = strcat(initial,':',c, num2str(n));