function [y,PARAM0,HOLD] = numderiv(functionhandle, handles)
%% Calculating derivatives
% 01/05/2015 modified by EJH
% TEMP_h is a temporary copy of handles that is returned by
% "functionhandle" - i.e. "deercalc". The info in TEMP_h that is needed
% should be copied to handles.
% extra contains additional variables that are changed
% in the fitting function AND need to be used in subsequent calls to the
% fitting function
% -------------------------------------------------------------------------
y = zeros(handles.totalpoints,handles.FLOAT.nfloat);
extra = struct('HOLD',handles.HOLD,'PARAM0',handles.PARAM0);
for jpar = 1:handles.FLOAT.nfloat
  
  deltapar = handles.OPTIONS.LM.numeric.delta*handles.FLOAT.float(jpar);
  if(handles.FLOAT.float(jpar) == 0)
    deltapar = handles.OPTIONS.LM.numeric.delta;
  end
  handles.FLOAT.float(jpar) = handles.FLOAT.float(jpar) + deltapar;
  if(handles.FLOAT.floatexpindex(jpar) == 1)
    q = find(strcmp(handles.FLOAT.floatnames,'time'));
    if(q)
      disp(['TIMESHIFT = ',num2str(handles.FLOAT.float(q))]);
    end
    TEMP_h =  functionhandle(handles.FLOAT.float,extra);
    %     3 items saved from calculation 1) the DEER signal vector 2) the
    %     parameters and 3) all of the subparts of the calculation results
    yder = TEMP_h.DATA.yfit;
    extra.PARAM0 = TEMP_h.PARAM0;
    extra.HOLD = TEMP_h.HOLD;
  else
    yder = handles.DATA.yfit;
  end
  
  y(1:handles.DATA.nfit,jpar) = yder - handles.DATA.yfit;
  y(:,jpar) = y(:,jpar)/deltapar;
  handles.FLOAT.float(jpar) = handles.FLOAT.float(jpar) - deltapar;
  clear TEMP_h;
  
end

PARAM0 = extra.PARAM0;
HOLD = extra.HOLD;
clear extra;
return