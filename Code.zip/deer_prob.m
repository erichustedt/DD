function [ HOLD ] = deer_prob( HOLD, PARAM )
% calculate DEER signal for short distances
% determine probability distribution
% disp('deer_prob');
%
% 07/12/2016 - EJH - Version 6
% Revised to include generalized normal and skewed normal distributions
% 08/05/2016 - EJH - Version 6B
% Revised to include generalized skewed normal distributions - GSND
% 09/19/2016 - EJH - Version 6B
% Fixed problem in calculation of alpha in GND
%%
% 1  = Gaussian   = 'B'
% 5  = Rice       = 'R'
% 8  = GND        = 'B' = variable beta
% 9  = SND        = 'Q' = variable zeta
% 10 = GSND       = 'D' = variable beta and zeta
HOLD.p = zeros(1,size(HOLD.r,2));
%%
if(PARAM.ng > 0) 
    if(PARAM.ng>1)
        ampr = PARAM.amp;
        ampb = zeros(size(ampr));
        ampc = zeros(size(ampr));
        ampb(1)= ampr(1);
        for n= 1:PARAM.ng - 1  
            ampb(n+1) = ampb(n)*ampr(n+1);
            ampc(n) = 1. - ampr(n+1);
        end 
        ampc(PARAM.ng) = 1.;
        ampr = ampb.*ampc;
    else
        ampr= PARAM.amp;
    end 
    HOLD.normamp = ampr;
    if(PARAM.shape == 1) 
        %% Gaussian
        s = ( bsxfun(@minus,HOLD.r,PARAM.r0') ).^2;
        s = bsxfun(@rdivide,s,2*(PARAM.width.^2)');
        s = exp(-s);
        ampr = ampr/(sqrt(2*pi))./PARAM.width;
        HOLD.p = ampr*s;
        HOLD.component = bsxfun(@times,ampr',s);
    end 
%
    if(PARAM.shape == 5) 
        %% Rice
        % below is based on work of M. Richards at G. Tech. "A Numerical 
        % Issue in Computing the Rician and Non-Central Chi-Square 
        % Probability Density Functions"  
        for kz = 1:PARAM.ng
            v = PARAM.r0(kz);
            s = PARAM.width(kz);
            ka = find(2*HOLD.r*v/s^2 < 500.);
            kb = find(2*HOLD.r*v/s^2 >= 500.);
            temp(ka) = (HOLD.r(ka) ./ s.^2) .* ...
              exp(-0.5 * (HOLD.r(ka).^2 + v.^2) ./ s.^2) .* ...
              besseli(0, HOLD.r(ka).* v ./ s.^2);
            temp(kb) = sqrt(HOLD.r(kb)/(2*pi*v*s^2)).* ...
              exp(-(HOLD.r(kb) - v).^2/2/s^2);
            temp(temp<0) = 0.;
            HOLD.p = HOLD.p + ampr(kz)*temp;
        end  
    end 
%
    if(PARAM.shape == 8) 
        %% Generalized Normal Distribution
        % This is a Generalized Normal Distribution
        % https://en.wikipedia.org/wiki/Generalized_normal_distribution
        % with variable beta  
        % Nadarajah, J. Appl. Stat. 32, 685-694 (2005) 
        alpha = sqrt(gamma(1./PARAM.beta)./ ...
                    gamma(3./PARAM.beta)).*PARAM.width;   
        s = ( bsxfun(@minus,HOLD.r,PARAM.r0') );
        s = bsxfun(@rdivide,s,(alpha)');
        s = bsxfun(@power,abs(s'),PARAM.beta);
        s = exp(-s)';
        ampr = PARAM.beta.*ampr./(2.*alpha.*gamma(1./PARAM.beta));
        HOLD.p = ampr*s;
        HOLD.component = bsxfun(@times,ampr',s);
    end 
%   
    if(PARAM.shape == 9) 
        %% Skew Normal Distribution
        % This is a Skewed Normal Distribution  
        temp = bsxfun(@times,PARAM.zeta, ...
               bsxfun(@rdivide, ...
               bsxfun(@minus,HOLD.r',PARAM.r0),PARAM.width)); 
        s = bsxfun(@minus,HOLD.r,PARAM.r0').^2;
        s = bsxfun(@rdivide,s,2*(PARAM.width.^2)');
        s = exp(-s).*(1 + erf(temp'/sqrt(2)));
        ampr = ampr/(sqrt(2*pi))./PARAM.width;
        HOLD.p = ampr*s;
        HOLD.component = bsxfun(@times,ampr',s);
    end
%    
    if(PARAM.shape == 10)
        %% Generalized Skew Normal Distribution
        % This is a Generalized Skewed Normal Distribution
        % Nadarajah and Kotz, Stat. & Prob. Lett. 65, 269-277 (2003)
%         BELOW IS A VERSION THAT USES THE CDF OF THE GND TO CALCULATE THE
%         PDF OF THE GSND. IT USES THE igamma FUNCTION AND IS SLOW.
%         m = 1:find(ampr,1,'last');
%         a = ampr(m);
%         c = PARAM.r0(m);
%         w = PARAM.width(m);
%         b = PARAM.beta(m);
%         z = PARAM.zeta(m);
%         N1 = (b.*gamma(3./b).^0.5)./(2*gamma(1./b).^1.5.*w);
%         T1 = bsxfun(@minus,HOLD.r,c');
%         T2 = ((gamma(1./b)./gamma(3./b)).^0.5).*w;
%         T3 = bsxfun(@rdivide, T1, T2');
%         T4 = bsxfun(@mtimes, N1, exp(-bsxfun(@power,abs(T3),b'))')';
%         M1 = bsxfun(@mtimes,z,T3');
%         M2B = bsxfun(@igamma,1./b,abs(bsxfun(@power,M1,b)));
%         M3B = bsxfun(@rdivide,M2B,2*gamma(1./b));
%         CDF = 0.5 + sign(M1).*(0.5 - M3B);
        alpha = sqrt(gamma(1./PARAM.beta)./ ...
            gamma(3./PARAM.beta)).*PARAM.width;  
        % normalization factor
        N1 = (PARAM.beta.*gamma(3./PARAM.beta).^0.5)./ ...
            (2*gamma(1./PARAM.beta).^1.5.*PARAM.width);
        % pdf of a GND
        T1 = bsxfun(@minus,HOLD.r,PARAM.r0');
        T2 = ((gamma(1./PARAM.beta)./ ...
               gamma(3./PARAM.beta)).^0.5).*PARAM.width;
        T4 = bsxfun(@mtimes,N1, ...
            exp(-bsxfun(@power,bsxfun(@rdivide,abs(T1),T2'), ...
            PARAM.beta'))')';
        % cdf of a Gaussian distribution with zeta
        CDF = 0.5*(1 + erf(bsxfun(@times,PARAM.zeta', ...
                  bsxfun(@rdivide,T1,sqrt(2)*PARAM.width'))));
        s = 2*T4.*CDF;
        HOLD.p = ampr*s;
        HOLD.component = bsxfun(@times,ampr',s);
    end 
end 
HOLD.v = PARAM.delta_R*HOLD.p*HOLD.kernel;
o1 = trapz(HOLD.p);
o2 = dot(HOLD.r,HOLD.p);
HOLD.mean = o2/o1;
o3 = dot((HOLD.r - HOLD.mean).^2,HOLD.p);
HOLD.width = sqrt(o3/o1);
return