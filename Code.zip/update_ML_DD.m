function [ handles ] = update_ML_DD( handles, chisqtest, TESTV, test)
handles.DATA.yfit = TESTV.yfit;
handles.DATA.chisquared = TESTV.chisquared;
handles.DATA.totalchisquared = chisqtest;
handles.FLOAT.float = test;
  handles.DATA.residuals = handles.DATA.deer_r - ...
    handles.DATA.yfit;
handles.HOLD = TESTV.HOLD;
return;
        