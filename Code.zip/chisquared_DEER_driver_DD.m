function [ c2 ] = chisquared_DEER_driver_DD(float, handles)
% 11/29/2012 
% EJH
% Version for fitting DEER data
% This version only calculates Chisquared for use with algorithms that only
% fit based on chisquared ('fminsearch','SIMPSA','fmincon',
% 'globalsearch','particleswarm').
% Globals version - not sure if globals is working correctly.
%%
for k = 1:handles.FLOAT.nfloat
    handles.ANS.values(handles.FLOAT.floatparindex(1,k)) = float(k);
end
%% Set linked parameters 
for k = 1:handles.FLOAT.nlinked
  handles.ANS.values(handles.FLOAT.linkedindex(k )) =...
    handles.ANS.values(handles.FLOAT.linkedtoindex(1,k) );
end
%% Copy all parameters to PARAM
handles.PARAM.ng = get(handles.g_1_checkbox,'Value') + ...
  get(handles.g_2_checkbox,'Value')+get(handles.g_3_checkbox,'Value')+ ...
  get(handles.g_4_checkbox,'Value')+get(handles.g_5_checkbox,'Value')+ ...
  get(handles.g_6_checkbox,'Value')+get(handles.g_7_checkbox,'Value')+ ...
  get(handles.g_8_checkbox,'Value');  
[handles.PARAM,handles.DISTRIBUTION] = copy_param(handles.PARAM, ....
    handles.ANS, handles.ANS.nparam, handles.ANS.namelengths); 
%% calculation
[handles.DATA.yfit, handles.HOLD, handles.PARAM0] = ...
    deer_calc(handles.HOLD,handles.PARAM0,handles.PARAM, ...
    handles.DATA,handles.OPTIONS.MISC.logical.quickversion);
%
handles = determine_chi2(handles);
c2 = handles.DATA.totalchisquared;
%
return;

