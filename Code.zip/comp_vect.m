function [lval]= comp_vect(v1,v2)
lval= 1;
if(size(v1,2) ~= size(v2,2)) 
    lval= 0;
else
    tlog= sum(v1~=v2);
    if(tlog > 0)
        lval= 0;
    end 
end 