function xc = findconfidence(x,y,xvalue,target) 
% values below xvalue
xc(1) = NaN;
xc(2) = NaN;
a = x(x<=xvalue);
b = y(x<=xvalue);
if length(b) > 1 
  try
    c = SplitVec(find(diff(b)<0),'consecutive');
    g = [];
    for i = 1:length(c)
        d = cell2mat(c(i));
        e = [a(d) a(d(end)+1)];
        f = [b(d) b(d(end)+1)];
        if f(1) > target && f(end) < target 
            g = [g interp1(f,e,target)];
        end
    end
    try
        xc(1) = -1*min(xvalue - g) + xvalue;
    end
  end
end
% values above xvalue
a = x(x>=xvalue);
b = y(x>=xvalue); 
if length(b) > 1 
  try
    c = SplitVec(find(diff(b)>0),'consecutive'); 
    g = [];
    for i = 1:length(c)
        d = cell2mat(c(i));
        e = [a(d) a(d(end)+1)];
        f = [b(d) b(d(end)+1)];
        if f(1) < target && f(end) > target 
            g = [g interp1(f,e,target)];
        end
    end
    try
        xc(2) = min(g - xvalue) + xvalue;
    end
  end
end