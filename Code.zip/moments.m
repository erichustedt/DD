function [o] = moments(r,p) 
% function for calculating 4 moments of distance distribution
o0 = sum(p);
o(1) = dot(r,p);
o(1) = o(1)/o0;
o(2) = dot((r - o(1)).^2,p);
o(2) = sqrt(o(2)/o0);
o(3) = dot((r - o(1)).^3,p);
o(3) = o(3)/(o0*(o(2)^3));
o(4) = dot((r - o(1)).^4,p);
o(4) = o(4)/(o0*(o(2)^4));
end

