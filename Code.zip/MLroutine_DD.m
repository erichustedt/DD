% --- November 19th 2012 ---
% --- January 12th 2018 ----
function [ handles, exitflag, endreason ] = ...
  MLroutine_DD( functionhandle, handles )
%% Initialize
exitflag = 0;
endreason = 0;
%% Copy lower and upper limits
ll = zeros(1,handles.FLOAT.nfloat);
ul = zeros(1,handles.FLOAT.nfloat);
for j = 1:handles.FLOAT.nfloat
  ll(j) = handles.ANS.lowerlimit( handles.FLOAT.floatparindex(1,j) );
  ul(j) = handles.ANS.upperlimit( handles.FLOAT.floatparindex(1,j) );
end
handles.iter = 0;
%% Plot
if(handles.OPTIONS.OUTPUT.logical.plotintermediate)
  axes3 = handles.axes3;
  plot3 = plot(handles.DATA.deer_t0,handles.DATA.deer_r, ...
    handles.DATA.deer_t0,handles.DATA.yfit,'Parent',axes3);
  axis(axes3,[handles.DATA.deer_t0(1)*2 ...
    handles.DATA.deer_t0(handles.DATA.nfit)*1.05...
    0.95*handles.DATA.deer_r(handles.DATA.nfit)  1.05]);
  set(plot3(1),'MarkerSize',5,'Marker','.','LineStyle','none',...
    'Color',[0 0 0]);
  set(plot3(2),'LineWidth',2,'Color',[1 0 0]);
  q = strcat('$\chi_{\nu}^2 = ', ...
    num2str(handles.DATA.totalchisquared), ...
    '\;\;iter.= ',num2str(handles.iter),'$');
  text(0.01,0.05,q,'Units','normalized','FontSize',12, ...
    'Parent',axes3,'Interpreter','latex');
  xlabel({'time'},'Parent',axes3);
  hax = handles.hax;
  plot(handles.HOLD.r,handles.HOLD.p,'Parent',hax);
  set(hax,'visible','off');
  drawnow;
end
%% Begin M-L algorithm
lambda = handles.OPTIONS.LM.numeric.lambda;
lambdascaleiter = 0;
s1 = sprintf('\n');
disp(s1);
while (handles.iter < handles.OPTIONS.LM.numeric.maxiter)
  s8 = 8*ones(1,length(s1)+2);
  % char(8) is backspace
  s2  = sprintf(char(s8));
  disp(s2);
  s1 = ['iteration = ' num2str(handles.iter) ...
    '  Chisquared = ' num2str(handles.DATA.totalchisquared) ];
  disp(s1);
  handles.iter = handles.iter + 1;
  jter= handles.iter;
  lambdascaleiter = 0;
  % calculate derivatives
  [derivatives,handles.PARAM0,handles.HOLD] = ...
    numderiv(functionhandle, handles);
  % set up gradient and curvature
  residuals = handles.DATA.residuals;
  gradient = residuals*derivatives;
  curvature = derivatives'*derivatives;
  %
  increment = genincrement(gradient, curvature, handles.FLOAT.nfloat, ...
    lambda,handles.OPTIONS.LM.numeric.threshold);
  %
  test = handles.FLOAT.float + increment;
  
  if ( all(test >= ll) && all(test <= ul ) )
    [ TESTV, chisqtest, difference, handles.PARAM0, handles.HOLD]...
      = compare_DD( functionhandle, test, handles);
  else
    chisqtest = 0.;
    difference = 1.e10;
  end
  
  if(difference > 0)
    % CHISQUARED DID NOT IMPROVE - TRY RESCALING lambda
    while(lambdascaleiter < handles.OPTIONS.LM.numeric.lambdascalemaxiter)
      lambdascaleiter = lambdascaleiter + 1;
      lambda = lambda*10;
      increment = genincrement(gradient, curvature, ...
        handles.FLOAT.nfloat, lambda,handles.OPTIONS.LM.numeric.threshold);
      test = handles.FLOAT.float + increment;
      if ( all(test >= ll) && all(test <= ul ) )
        [ TESTV, chisqtest, difference, handles.PARAM0, handles.HOLD]...
          = compare_DD( functionhandle, test, handles);
      else
        difference = 1.e10;
      end
      
      if(difference < 0)
        % CHISQUARED IMPROVED
        [handles] = update_ML_DD(handles,chisqtest,TESTV,test);
        if(handles.OPTIONS.OUTPUT.logical.plotintermediate)
          axes3 = handles.axes3;
          plot3 = plot(handles.DATA.deer_t0,handles.DATA.deer_r,...
            handles.DATA.deer_t0,handles.DATA.yfit,...
            'Parent',axes3);
          axis(axes3,[handles.DATA.deer_t0(1)*2 ...
            handles.DATA.deer_t0(handles.DATA.nfit)*1.05 ...
            0.95*handles.DATA.deer_r(handles.DATA.nfit) ...
            1.05]);
          set(plot3(1),'MarkerSize',5,'Marker','.', ...
            'LineStyle','none','Color',[0 0 0]);
          set(plot3(2),'LineWidth',2,'Color',[1 0 0]);
          q = strcat('$\chi_{\nu}^2 = ', ...
            num2str(handles.DATA.chisquared), ...
            '\;\;iter.= ',num2str(handles.iter),'$');
          text(0.01,0.05,q,'Units','normalized',...
            'FontSize',12,'Parent',axes3,'Interpreter','latex');
          xlabel({'time'},'Parent',axes3);
          hax = handles.hax;
          plot(handles.HOLD.r,handles.HOLD.p,'Parent',hax);
          set(hax,'visible','off');
          drawnow;
        end
        %
        if(difference > -1*handles.OPTIONS.LM.numeric.mindifference)
          exitflag = 1;
          endreason = 'chisquared change less than minimum';
          handles.iter = handles.OPTIONS.LM.numeric.maxiter;
        end
        break;
      end
      if(lambdascaleiter == handles.OPTIONS.LM.numeric.lambdascalemaxiter)
        exitflag = 3;
        endreason= 'too many attempted rescalings of lambda';
        handles.iter = 100 + handles.OPTIONS.LM.numeric.maxiter;
        break;
      end
    end
  elseif(difference > -1*handles.OPTIONS.LM.numeric.mindifference)
    handles.iter = handles.OPTIONS.LM.numeric.maxiter;
    exitflag = 1;
    endreason= 'chisquared change less than minimum';
    lambda = lambda/10;
    %         disp('CHISQUARED CHANGE LESS THAN MINIMUM');
    [handles] = update_ML_DD(handles,chisqtest,TESTV,test);
  else
    lambda = lambda/10;
    %         disp('EVERYTHING OK - DO ANOTHER ITERATION');
    
    [handles] = update_ML_DD(handles,chisqtest,TESTV,test);
    
    if(handles.OPTIONS.OUTPUT.logical.plotintermediate)
      axes3 = handles.axes3;
      plot3 = plot(handles.DATA.deer_t0,handles.DATA.deer_r,...
        handles.DATA.deer_t0,handles.DATA.yfit, ...
        'Parent',axes3);
      axis(axes3,[handles.DATA.deer_t0(1)*2 ...
        handles.DATA.deer_t0(handles.DATA.nfit)*1.05...
        0.95*handles.DATA.deer_r(handles.DATA.nfit)  1.05]);
      set(plot3(1),'MarkerSize',5,'Marker','.','LineStyle',...
        'none','Color',[0 0 0]);
      set(plot3(2),'LineWidth',2,'Color',[1 0 0]);
      q = strcat('$\chi_{\nu}^2 = ', ...
        num2str(handles.DATA.totalchisquared), ...
        '\;\;iter.= ',num2str(handles.iter),'$');
      text(0.01,0.05,q,'Parent',handles.axes3,'Units','normalized', ...
        'FontSize',12,'Interpreter','latex');
      xlabel({'time'},'Parent',axes3);
      hax = handles.hax;
      plot(handles.HOLD.r,handles.HOLD.p,'Parent',hax);
      set(hax,'visible','off');
      drawnow;
    end
  end
  if(handles.iter == handles.OPTIONS.LM.numeric.maxiter - 1)
    exitflag = 2;
    endreason= 'Maximum number of iterations reached';
  end
end
%
for j = 1:handles.FLOAT.nfloat
  handles.ANS.values(handles.FLOAT.floatparindex(1,j)) = ...
    handles.FLOAT.float(j);
end
%
for n = 1:handles.FLOAT.nlinked
  handles.ANS.values(handles.FLOAT.linkedindex(n)) = ...
    handles.ANS.values(handles.FLOAT.linkedtoindex(1,n));
end
if(handles.OPTIONS.OUTPUT.logical.plotintermediate)
  delete(axes3);
  delete(hax);
end
%
handles.iter= jter;
%
clear residuals gradient curvature;
return