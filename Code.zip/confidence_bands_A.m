function [ handles ] = confidence_bands_A( handles )
% 09/19/2016 - EJH - Version 6B 
warning('off','MATLAB:handle_graphics:exceptions:SceneNode');
temp = zeros(handles.FLOAT.nfloat,length(handles.HOLD.r));
fun = @(R,r0,s,b,z) (b*(gamma(3/b)^0.5))/(s*(gamma(1/b)^1.5))* ...
  exp(-(abs(R-r0)/(s*((gamma(1/b)/gamma(3/b))^0.5))).^b)*0.5.* ...
  (1 + erf( z*(R-r0)/(sqrt(2)*s) ));
%%
for i = 1:handles.FLOAT.nfloat 
  try
    q = strsplit(handles.FLOAT.floatnames{i},'_');
    name = q{1};
    q = str2double(q{2});
    %% amp
    if strcmp(name,'amp')
      A = zeros(1,length(handles.HOLD.r));
      for j = 1:q-1
        A = A + handles.HOLD.component(j,:);
      end 
      B = prod(handles.PARAM.amp(1:q-1))*handles.HOLD.component(q-1,:);
      temp(i,:) = ((handles.HOLD.p - A)/handles.PARAM.amp(q)) - ...
        (B/handles.HOLD.normamp(q-1));
    %% r0
    elseif strcmp(name,'r0')
      delta = handles.PARAM.r0(q)*0.005;
      yh = fun(handles.HOLD.r,handles.PARAM.r0(q) + delta, ...
        handles.PARAM.width(q),handles.PARAM.beta(q), ...
        handles.PARAM.zeta(q));
      yl = fun(handles.HOLD.r,handles.PARAM.r0(q) - delta, ...
        handles.PARAM.width(q),handles.PARAM.beta(q), ...
        handles.PARAM.zeta(q));
      temp(i,:) = handles.HOLD.normamp(q)*0.5*(yh - yl)/delta;
    %% width
    elseif strcmp(name,'width')
      delta = handles.PARAM.width(q)*0.005;
      yh = fun(handles.HOLD.r,handles.PARAM.r0(q), ...
        handles.PARAM.width(q) + delta,handles.PARAM.beta(q), ...
        handles.PARAM.zeta(q));
      yl = fun(handles.HOLD.r,handles.PARAM.r0(q), ...
        handles.PARAM.width(q) - delta,handles.PARAM.beta(q), ...
        handles.PARAM.zeta(q));
      temp(i,:) = handles.HOLD.normamp(q)*0.5*(yh - yl)/delta;  
    %% beta
    elseif strcmp(name,'beta')
      delta = handles.PARAM.beta(q)*0.005;
      yh = fun(handles.HOLD.r,handles.PARAM.r0(q), ...
        handles.PARAM.width(q),handles.PARAM.beta(q) + delta, ...
        handles.PARAM.zeta(q));
      yl = fun(handles.HOLD.r,handles.PARAM.r0(q), ...
        handles.PARAM.width(q),handles.PARAM.beta(q) - delta, ...
        handles.PARAM.zeta(q));
      temp(i,:) = handles.HOLD.normamp(q)*0.5*(yh - yl)/delta; 
    %% zeta
    elseif strcmp(name,'zeta')
      delta = handles.PARAM.zeta(q)*0.005;
      yh = fun(handles.HOLD.r,handles.PARAM.r0(q), ...
        handles.PARAM.width(q),handles.PARAM.beta(q), ...
        handles.PARAM.zeta(q) + delta);
      yl = fun(handles.HOLD.r,handles.PARAM.r0(q), ...
        handles.PARAM.width(q),handles.PARAM.beta(q), ...
        handles.PARAM.zeta(q) - delta);
      temp(i,:) = handles.HOLD.normamp(q)*0.5*(yh - yl)/delta;
    end 
  catch
  end 
end 
%%
% 1 sigma 68.27% 31.73%
% 2 sigma 95.45%  4.55% 1.96
% 3 sigma 99.73%  0.27%
temp = sqrt(diag(temp'*handles.covariance*temp));
%
handles.CI.delta = temp';
handles.CI.upper = handles.HOLD.p + 2.00*handles.CI.delta;
handles.CI.lower = handles.HOLD.p - 2.00*handles.CI.delta;
handles.figureCBa = confidence_bands_A_GUI(handles); 
[t1,~,~] = fileparts(handles.answerfile);
q = [t1 handles.sep 'A.pdf'];
saveas(handles.figureCBa, q); 
warning('on','MATLAB:handle_graphics:exceptions:SceneNode');
end