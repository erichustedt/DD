function [ x,Z,dx ]= read_elexsys(file)
% 03/30/2010 modified EJH 
% Get Bruker Data Set
% file is the file name for the bruker data set
% Use the Bruker  file convention, and do not add extension names
% "file" . dsc and .dta are assumed
% Z contains the x and y values in a 2 column matrix
%  plot(Z(:,1),Z(:,2))  to  visualize results

dx= [];
rdata= [];
idata= [];
x=[];
y=[];
Z =[];
N=1; 

% spc
% disp('file');disp(file);
fid = fopen( [ file '.DTA'], 'r','ieee-be.l64'); 
if(fid == -1) return; end 
[Z,N]= fread(fid,inf,'float64');
fclose(fid);
fid = fopen( [ file '.DSC'], 'r');
[info,ns] = textscan(fid,'%s');
fclose(fid);
%
temp = find(ismember(info{:,1},'XMIN')==1);
XMIN = str2num(info{1,1}{temp(1)+1,1});
temp = find(ismember(info{:,1},'XWID')==1);
XWID = str2num(info{1,1}{temp(1)+1,1});
temp = find(ismember(info{:,1},'XPTS')==1);
XPTS = str2num(info{1,1}{temp(1)+1,1});
%
dx = XWID/(XPTS-1);
disp(dx);
x = XMIN + dx*[0:(XPTS-1)];
%%
if length(Z)==2*XPTS 
    z0=Z;
    Z=zeros(XPTS,1);
    for k=1:XPTS 
        Z(k)=z0(2*k-1)+1i*z0(2*k);
    end
end

% Z=reshape(Z,N,1);
Z=permute(Z,[2,1]);
%
return