function [ss,sss,rnoise,phase,c]= phase_deer(s,ist,ind)
% 03/30/2010 EJH
% determine phase on truncated data, but apply phase to all data
% 10/30/13 ----------------------------------------------------------------
% MODIFIED: split off some of calculations into 2nd function. add check to 
%           make sure result is in the correct quadrant.
% -------------------------------------------------------------------------
npts = length(s);
y = real(s(ist:ind));
z = imag(s(ist:ind));
npt2 = ind - ist + 1;
%
d = sum(y); 
e = sum(z);
f = sum(y.*y) - sum(z.*z) ;
g = sum(y.*z) ;
a = -2*d*e + 2*g*npt2;
b = d^2 - e^2 - f*npt2 ;
t2p = a/b;
phi = atan(t2p)/2;
% This phi value will be between -45 and +45 degrees or -pi/4 to pi/4
if abs(d/e) > 1
  % if d/e is greater than 1 then phi is either in the correct quadrant or
  % need to add pi
  if d < 0
    phi = phi + pi;
  end
else
  % if d/e is less than 1 then either need to add pi/2 or subtract pi/2
  if e < 0 
    phi = phi + pi/2;
  else
    phi = phi - pi/2;
  end
end
%
c = (sin(phi)*d + cos(phi)*e)/npt2; 
%
phase = phi*180/pi;
fprintf('%s %5.2f \n  ', ' Phase= ', phase );
% these are the new signals - here return all points
% deer_r = cos(phi)*real(s) - sin(phi)*imag(s);
% deer_i = cos(phi)*imag(s) + sin(phi)*real(s);
% these are the new signals - here return truncated data
deer_r = cos(phi)*y - sin(phi)*z;
deer_i = cos(phi)*z + sin(phi)*y;
ss = deer_r + 1i*deer_i;
deer_r = cos(phi)*real(s) - sin(phi)*imag(s);
deer_i = cos(phi)*imag(s) + sin(phi)*real(s);
sss = deer_r + 1i*deer_i; 
% always use truncated signal to calculate noise level
temp = (cos(phi)*z + sin(phi)*y - c).^2;
tlength = length(temp);
% only use mid 1/2 of data to determine noise level
temp = temp(ceil(tlength/4):floor(3*tlength/4));
rnoise = sum( temp );
rnoise = rnoise/length(temp);
rnoise = sqrt(rnoise);
% In some cases phi may actually maximize the imaginary component
% in that case phi is off by 90 degrees. Check to see if the sum 
% of the Real signal is less than the sum of the Imaginary.
d = sum(deer_r); 
e = sum(deer_i);
if abs(d) < abs(e)
  % phase if off so need to adjust. Try 90 degrees.
  phi = phi - pi/2;
  phase = phi*180/pi;
  % these are the new signals - here return all points
  % deer_r = cos(phi)*real(s) - sin(phi)*imag(s);
  % deer_i = cos(phi)*imag(s) + sin(phi)*real(s);
  % these are the new signals - here return truncated data
  deer_r = cos(phi)*y - sin(phi)*z;
  deer_i = cos(phi)*z + sin(phi)*y;
  ss = deer_r + 1i*deer_i;
  deer_r = cos(phi)*real(s) - sin(phi)*imag(s);
  deer_i = cos(phi)*imag(s) + sin(phi)*real(s);
  sss = deer_r + 1i*deer_i; 
  % now need to recompute noise level and imaginary constant
  z = deer_i(1+ist:npts-ind);
  %
  c = sum(z)/npt2;
  % always use truncated signal to calculate noise level
  temp = (z - c).^2;
  tlength = length(temp);
  % only use mid 1/2 of data to determine noise level
  temp = temp(ceil(tlength/4):floor(3*tlength/4));
  rnoise = sum( temp );
  rnoise = rnoise/length(temp);
  rnoise = sqrt(rnoise);
end
fprintf('%s %5.2f \n  ', ' Phase= ', phase );
%
fprintf('%s %5.2f \n  ', ' Noise= ', rnoise );
fprintf('%s %5.2f \n  ', ' Imaginary Constant Value= ', c );
return


