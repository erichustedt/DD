function [handles] = fit_DEER_driver_DD(floatvalues, extra, handles)
% 11/07/2012
% GLOBALS VERSION
% this function drives the actual function that is used to fit.
% The purpose is to allow additional information beyond the
% floating parameters to be passed to deer_calc.
% first link parameters then pass all paramteres to PARAM then use float
% parameters 
% -------------------------------------------------------------------------
% 01/06/2015 - modified EJH
% 01/12/2018 - removed kexp
% Modified to now include 4 input variables 
% floatvalues - floating point array - the values of all the fitting 
%               parameters being varied in the NLLS analysis
% extra (NEW) - structure - contains additional variables that are changed
%               in the fitting function AND need to be used in subsequent
%               calls to the fitting function
% handles     - stucture - all other variables can be included here.
%               Specifically, handles can contain variables that are used
%               in the fitting function but are not changed.
% -------------------------------------------------------------------------
%% Copy all values in float to ANS
for k = 1:handles.FLOAT.nfloat
  handles.ANS.values( handles.FLOAT.floatparindex(1,k) ) = floatvalues(k);
end
%
%% Set linked parameters
for k = 1:handles.FLOAT.nlinked
  handles.ANS.values(handles.FLOAT.linkedindex(k)) =...
    handles.ANS.values(handles.FLOAT.linkedtoindex(1,k));
end
%% Copy all parameters to PARAM
[handles.PARAM, handles.DISTRIBUTION] = copy_param(handles.PARAM, ....
    handles.ANS, handles.ANS.nparam, handles.ANS.namelengths);
%% 
[handles.DATA.yfit, handles.HOLD, handles.PARAM0 ] = ...
  deer_calc(extra.HOLD,extra.PARAM0,handles.PARAM,handles.DATA,...
              handles.OPTIONS.MISC.logical.quickversion); 
%%
return 
