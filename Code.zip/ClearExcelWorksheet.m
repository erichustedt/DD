function  ClearExcelWorksheet(filename,sheetname) 
Excel = actxserver('Excel.Application'); 
Workbook = Excel.Workbooks.Open(filename);
Excel.ActiveWorkbook.Sheets.Item(sheetname).Cells.Clear;
Excel.displayalerts = false;
Workbook.Save;
Excel.Workbook.Close;
invoke(Excel,'Quit') 
delete(Excel)