function [ handles ] = set_initial_answer_values( handles )
%%
% 08/02/2016 - EJH - Version 6B
% Revised to include beta factors for generalized normal distribution
%%
index = 1;
handles.ANS.lowerlimit(index) = 0.01;
handles.ANS.upperlimit(index) = 1.00;
handles.ANS.values(index) = .1;
set(handles.deltaR_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
%
index = 2;
handles.ANS.lowerlimit(index) = 50.00;
handles.ANS.upperlimit(index) = 1000.;
% line below is the Rmax values. You can edit to a larger number if you are
% measuring longer distances. - EJH 8/16/2018
handles.ANS.values(index) = 100;
set(handles.Rmax_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
%
index = 3;
handles.ANS.lowerlimit(index) = 100.0;
handles.ANS.upperlimit(index) = 1000.;
handles.ANS.values(index) = 500;
set(handles.Rsphere_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
%
index = 4;
handles.ANS.lowerlimit(index) = 0.01;
handles.ANS.upperlimit(index) = 1.00;
handles.ANS.values(index) = 1;
set(handles.deltaR_b_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
%
index = 5;
handles.ANS.lowerlimit(index) = 0;
handles.ANS.upperlimit(index) = 0.5;
handles.ANS.values(index) = 0.3;
set(handles.depth_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 0;
set(handles.depth_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 6;
handles.ANS.lowerlimit(index) = +3.5;
handles.ANS.upperlimit(index) = +6.0;
handles.ANS.values(index) = 5;
set(handles.lambda_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 0;
set(handles.lambda_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 7;
handles.ANS.lowerlimit(index) = 0.;
handles.ANS.upperlimit(index) = 4.;
handles.ANS.values(index) = 3;
set(handles.d_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.d_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 8;
handles.ANS.lowerlimit(index) = 0;
handles.ANS.upperlimit(index) = 1;
handles.ANS.values(index) = 0;
set(handles.b_depth_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.b_depth_checkbox,'Value',~handles.ANS.fixed(index));
set(handles.link_depth_checkbox,'Value',0);
%
index = 9;
handles.ANS.lowerlimit(index) = 0;
handles.ANS.upperlimit(index) = 1000.;
handles.ANS.values(index) = 0;
set(handles.concentration_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.concentration_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 10;
handles.ANS.lowerlimit(index) = 000.;
handles.ANS.upperlimit(index) = 100.;
handles.ANS.values(index) = 0;
set(handles.rho_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.rho_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 11;
handles.ANS.lowerlimit(index) = 0.8;
handles.ANS.upperlimit(index) = 1.2;
handles.ANS.values(index) = 1;
set(handles.scale_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 0;
set(handles.scale_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 12;
handles.ANS.lowerlimit(index) = 0;
handles.ANS.upperlimit(index) = +200;
handles.ANS.values(index) = 0;
set(handles.time_shift_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.time_shift_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 13;
handles.ANS.lowerlimit(index) = 1;
handles.ANS.upperlimit(index) = 8;
handles.ANS.values(index) = 1;
handles.ANS.fixed(index) = 1;
set(handles.gaussian_checkbox,'Value',1);
set(handles.variable_checkbox,'Value',0);
%
index = 14;
handles.ANS.lowerlimit(index) = 15.0;
% line below is the upper limit for the r0_1 value. You can edit to a 
% larger number if you are measuring longer distances. - EJH 8/16/2018
handles.ANS.upperlimit(index) = 100.;
handles.ANS.values(index) = 35;
set(handles.r_1_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 0;
set(handles.r_1_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 15;
handles.ANS.lowerlimit(index) = 0.5;
handles.ANS.upperlimit(index) = 25.0;
handles.ANS.values(index) = 2;
set(handles.s_1_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 0;
set(handles.s_1_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 16;
handles.ANS.lowerlimit(index) =  0.25;
handles.ANS.upperlimit(index) = 40.00;
handles.ANS.values(index) = 2;
set(handles.b_1_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.b_1_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 17;
handles.ANS.lowerlimit(index) = -40.;
handles.ANS.upperlimit(index) = +40.;
handles.ANS.values(index) = 0;
set(handles.l_1_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.l_1_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 18;
handles.ANS.lowerlimit(index) = 1;
handles.ANS.upperlimit(index) = 1;
handles.ANS.values(index) = 1;
handles.ANS.fixed(index) = 1;
%
index = 19;
handles.ANS.lowerlimit(index) = 15.0;
% line below is the upper limit for the r0_2 value. You can edit to a 
% larger number if you are measuring longer distances. - EJH 8/16/2018
handles.ANS.upperlimit(index) = 100.;
handles.ANS.values(index) = 45;
set(handles.r_2_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.r_2_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 20;
handles.ANS.lowerlimit(index) = 0.5;
handles.ANS.upperlimit(index) = 25.0;
handles.ANS.values(index) = 2;
set(handles.s_2_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.s_2_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 21;
handles.ANS.lowerlimit(index) =  0.25;
handles.ANS.upperlimit(index) = 40.00;
handles.ANS.values(index) = 2;
set(handles.b_2_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.b_2_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 22;
handles.ANS.lowerlimit(index) = -40.;
handles.ANS.upperlimit(index) = +40.;
handles.ANS.values(index) = 0;
set(handles.l_2_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.l_2_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 23;
handles.ANS.lowerlimit(index) = 0;
handles.ANS.upperlimit(index) = 1;
handles.ANS.values(index) = 0;
set(handles.a_2_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.a_2_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 24;
handles.ANS.lowerlimit(index) = 15.0;
% line below is the upper limit for the r0_3 value. You can edit to a 
% larger number if you are measuring longer distances. - EJH 8/16/2018
handles.ANS.upperlimit(index) = 100.;
handles.ANS.values(index) = 25;
set(handles.r_3_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.r_3_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 25;
handles.ANS.lowerlimit(index) = 0.5;
handles.ANS.upperlimit(index) = 25.0;
handles.ANS.values(index) = 2;
set(handles.s_3_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.s_3_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 26;
handles.ANS.lowerlimit(index) =  0.25;
handles.ANS.upperlimit(index) = 50.00;
handles.ANS.values(index) = 2;
set(handles.b_3_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.b_3_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 27;
handles.ANS.lowerlimit(index) = -40.;
handles.ANS.upperlimit(index) = +40.;
handles.ANS.values(index) = 0;
set(handles.l_3_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.l_3_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 28;
handles.ANS.lowerlimit(index) = 0;
handles.ANS.upperlimit(index) = 1;
handles.ANS.values(index) = 0;
set(handles.a_3_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
%
index = 29;
handles.ANS.lowerlimit(index) = 15.0;
% line below is the upper limit for the r0_4 value. You can edit to a 
% larger number if you are measuring longer distances. - EJH 8/16/2018
handles.ANS.upperlimit(index) = 100.;
handles.ANS.values(index) = 49;
set(handles.r_4_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.r_4_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 30;
handles.ANS.lowerlimit(index) = 0.5;
handles.ANS.upperlimit(index) = 25.0;
handles.ANS.values(index) = 2;
set(handles.s_4_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.s_4_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 31;
handles.ANS.lowerlimit(index) =  0.25;
handles.ANS.upperlimit(index) = 25.00;
handles.ANS.values(index) = 2;
set(handles.b_4_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.b_4_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 32;
handles.ANS.lowerlimit(index) = -2.;
handles.ANS.upperlimit(index) = +2.;
handles.ANS.values(index) = 0;
set(handles.l_4_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.l_4_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 33;
handles.ANS.lowerlimit(index) = 0;
handles.ANS.upperlimit(index) = 1;
handles.ANS.values(index) = 0;
set(handles.a_4_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.a_4_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 34;
handles.ANS.lowerlimit(index) = 15.0;
% line below is the upper limit for the r0_5 value. You can edit to a 
% larger number if you are measuring longer distances. - EJH 8/16/2018
handles.ANS.upperlimit(index) = 100.;
handles.ANS.values(index) = 20;
set(handles.r_5_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.r_5_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 35;
handles.ANS.lowerlimit(index) = 0.5;
handles.ANS.upperlimit(index) = 25.0;
handles.ANS.values(index) = 2;
set(handles.s_5_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.s_5_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 36;
handles.ANS.lowerlimit(index) =  0.25;
handles.ANS.upperlimit(index) = 25.00;
handles.ANS.values(index) = 2;
set(handles.b_5_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.b_5_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 37;
handles.ANS.lowerlimit(index) = -2.;
handles.ANS.upperlimit(index) = +2.;
handles.ANS.values(index) = 0;
set(handles.l_5_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.l_5_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 38;
handles.ANS.lowerlimit(index) = 0;
handles.ANS.upperlimit(index) = 1;
handles.ANS.values(index) = 0;
set(handles.a_5_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.a_5_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 39;
handles.ANS.lowerlimit(index) = 15.0;
% line below is the upper limit for the r0_6 value. You can edit to a 
% larger number if you are measuring longer distances. - EJH 8/16/2018
handles.ANS.upperlimit(index) = 100.;
handles.ANS.values(index) = 30;
set(handles.r_6_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.r_6_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 40;
handles.ANS.lowerlimit(index) = 0.5;
handles.ANS.upperlimit(index) = 25.0;
handles.ANS.values(index) = 2;
set(handles.s_6_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.s_6_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 41;
handles.ANS.lowerlimit(index) =  0.25;
handles.ANS.upperlimit(index) = 25.00;
handles.ANS.values(index) = 2;
set(handles.b_6_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.b_6_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 42;
handles.ANS.lowerlimit(index) = -2.;
handles.ANS.upperlimit(index) = +2.;
handles.ANS.values(index) = 0;
set(handles.l_6_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.l_6_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 43;
handles.ANS.lowerlimit(index) = 0;
handles.ANS.upperlimit(index) = 1;
handles.ANS.values(index) = 0;
set(handles.a_6_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.a_6_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 44;
handles.ANS.lowerlimit(index) = 15.0;
% line below is the upper limit for the r0_7 value. You can edit to a 
% larger number if you are measuring longer distances. - EJH 8/16/2018
handles.ANS.upperlimit(index) = 100.;
handles.ANS.values(index) = 40;
set(handles.r_7_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.r_7_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 45;
handles.ANS.lowerlimit(index) = 0.5;
handles.ANS.upperlimit(index) = 25.0;
handles.ANS.values(index) = 2;
set(handles.s_7_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.s_7_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 46;
handles.ANS.lowerlimit(index) =  0.25;
handles.ANS.upperlimit(index) = 25.00;
handles.ANS.values(index) = 2;
set(handles.b_7_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.b_7_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 47;
handles.ANS.lowerlimit(index) = -2.;
handles.ANS.upperlimit(index) = +2.;
handles.ANS.values(index) = 0;
set(handles.l_7_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.l_6_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 48;
handles.ANS.lowerlimit(index) = 0;
handles.ANS.upperlimit(index) = 1;
handles.ANS.values(index) = 0;
set(handles.a_7_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.a_7_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 49;
handles.ANS.lowerlimit(index) = 15.0;
% line below is the upper limit for the r0_8 value. You can edit to a 
% larger number if you are measuring longer distances. - EJH 8/16/2018
handles.ANS.upperlimit(index) = 100.;
handles.ANS.values(index) = 50;
set(handles.r_8_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.r_8_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 50;
handles.ANS.lowerlimit(index) = 0.5;
handles.ANS.upperlimit(index) = 25.0;
handles.ANS.values(index) = 2;
set(handles.s_8_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.s_8_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 51;
handles.ANS.lowerlimit(index) =  0.25;
handles.ANS.upperlimit(index) = 25.00;
handles.ANS.values(index) = 2;
set(handles.b_8_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.b_8_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 52;
handles.ANS.lowerlimit(index) = -2.;
handles.ANS.upperlimit(index) = +2.;
handles.ANS.values(index) = 0;
set(handles.l_8_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.l_8_checkbox,'Value',~handles.ANS.fixed(index));
%
index = 53;
handles.ANS.lowerlimit(index) = 0;
handles.ANS.upperlimit(index) = 1;
handles.ANS.values(index) = 0;
set(handles.a_8_edit,'String',num2str(handles.ANS.values(index)));
handles.ANS.fixed(index) = 1;
set(handles.a_8_checkbox,'Value',~handles.ANS.fixed(index));
%% Set up variable names
handles.ANS.names = {'delta_R';'R_max';'R_sphere';'delta_R_background'; ...
    'depth';'lambda';'dimension';'background_depth';'concentration'; ...
    'rho';'scale';'time_shift';'shape';'r0_1';'width_1';'beta_1'; ...
    'zeta_1';'amp_1';'r0_2';'width_2';'beta_2';'zeta_2';'amp_2'; ...
    'r0_3';'width_3';'beta_3';'zeta_3';'amp_3';'r0_4';'width_4'; ...
    'beta_4';'zeta_4';'amp_4';'r0_5';'width_5';'beta_5';'zeta_5'; ...
    'amp_5';'r0_6';'width_6';'beta_6';'zeta_6';'amp_6';'r0_7'; ...
    'width_7';'beta_7';'zeta_7';'amp_7';'r0_8';'width_8';'beta_8'; ...
    'zeta_8';'amp_8'};
%% Miscellaneous
handles.ANS.nparam = 53;
handles.ANS.namelengths = sum(~isspace(char(handles.ANS.names))');
handles.ANS.lowerlimit = handles.ANS.lowerlimit';
handles.ANS.upperlimit = handles.ANS.upperlimit';
handles.ANS.values = handles.ANS.values';
handles.ANS.fixed = handles.ANS.fixed';
handles.ANS.namelengths = handles.ANS.namelengths';
%% set values for output to Excel file
handles.ANS.experiment = ones(handles.ANS.nparam,1);
handles.ANS.links = zeros(handles.ANS.nparam,1);
handles.ANS.confidence = zeros(handles.ANS.nparam,1);
handles.ANS.start = zeros(handles.ANS.nparam,1);
handles.ANS.end = zeros(handles.ANS.nparam,1);
handles.ANS.increment = zeros(handles.ANS.nparam,1);
handles.ANS.nexp = 1;
%% 2 parameter values
handles.PARAM.shape = 1;
handles.PARAM.ng = 1;
end

